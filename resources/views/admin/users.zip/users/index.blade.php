@extends('layouts.app')

@section('title', 'User Management')

@section('content')

<div class="space-y-6">

    {{-- Toolbar --}}
    @include('admin.users.partials.toolbar')

    {{-- Filter --}}
    @include('admin.users.partials.filter')

    {{-- Bulk Action --}}
    @include('admin.users.partials.bulk-action')

    {{-- Table --}}
    @include('admin.users.partials.table')

    {{-- Pagination --}}
    @include('admin.users.partials.pagination')

    @include('admin.users.modals.bulk-deleted')
    @include('admin.users.modals.create')
    @include('admin.users.modals.delete')
    @include('admin.users.modals.edit')
    @include('admin.users.modals.reset-password')
    @include('admin.users.modals.reset-profile')

</div>

@endsection

@push('templates')
    @include('admin.users.templates.create-row')
@endpush