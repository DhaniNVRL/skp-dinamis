<div class="bg-white rounded-lg shadow-sm border border-gray-200 overflow-visible">
    <div class="overflow-x-auto">
        <table id="userTable" class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100">
                <tr>
                    <th class="w-12 px-4 py-3 text-center">
                        <input
                            type="checkbox"
                            class="bulk-select-all"
                            id="selectAllTable">
                    </th>
                    <th class="w-16 px-4 py-3 text-center">
                        No
                    </th>
                    <th class="w-16 px-4 py-3">
                        ID USER
                    </th>
                    <th class="px-4 py-3">
                        Username
                    </th>
                    <th class="px-4 py-3">
                        Full Name
                    </th>
                    <th class="px-4 py-3">
                        Role
                    </th>
                    <th class="px-4 py-3">
                        Activity
                    </th>
                    <th class="px-4 py-3">
                        Group
                    </th>
                    <th class="px-4 py-3">
                        Unit
                    </th>
                    <th class="w-48 px-4 py-3 text-center">
                        Action
                    </th>
                </tr>
            </thead>

            <tbody class="divide-y divide-gray-100">
                @forelse($userProfiles as $profile)
                    <tr
                        class="hover:bg-gray-50"
                        data-search="{{ strtolower($profile->user->id . ' ' . $profile->user->username) }}"
                        data-role="{{ $profile->user->role_id }}"
                        data-activity="{{ $profile->activity_id }}">
                        <td  class="hover:bg-gray-50">
                            <input
                                type="checkbox"
                                class="bulk-checkbox"
                                value="{{ $profile->user->id }}"
                                data-username="{{ $profile->user->username }}">
                        </td>
                        <td class="text-center">
                            {{ $loop->iteration }}
                        </td>
                        <td>
                            {{ $profile->user->id }}
                        </td>
                        <td>
                            {{ $profile->user->username }}
                        </td>
                        <td>
                            {{ $profile->fullname }}
                        </td>
                        <td>
                            <span class="px-2 py-1 rounded bg-blue-100 text-blue-700">
                                {{ $profile->user->role->name }}
                            </span>
                        </td>
                        <td>
                            {{ $profile->activity?->name }}
                        </td>
                        <td>
                            {{ $profile->group?->name }}
                        </td>
                        <td>
                            {{ $profile->unit?->name }}
                        </td>
                        <td class="text-center">
                            @include('admin.users.partials.row-action')
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="9" class="text-center py-10 text-gray-500">
                            Tidak ada data user.
                        </td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
</div>