<div class="flex justify-center gap-2">

    
    {{-- <a
        href="{{ route('admin.datauser.show',$profile->user->id) }}"
        class="text-sky-600 hover:text-sky-800">
        <i class="fa fa-eye"></i>
    </a> --}}
    <button
        type="button"

        data-modal-open="editUserModal"

        data-id="{{ $profile->user->id }}"
        data-username="{{ $profile->user->username }}"
        data-role="{{ $profile->user->role_id }}"
        data-activity="{{ $profile->activity_id }}"
        data-action="{{ route('admin.datauser.update', $profile->user->id) }}"

        class="text-amber-500 hover:text-amber-700"

        title="Edit User"
    >
        <i class="fa-solid fa-pen"></i>
    </button>
    <a
        href="{{ route('admin.datauser.editpassword',$profile->user->id) }}"
        class="text-indigo-600 hover:text-indigo-800">
        <i class="fa fa-key"></i>
    </a>
    
    <button
        id="bulkDeleteButton"
        type="button"
        class="text-red-600 hover:text-red-800"
        data-modal-open="deleteModal"
        data-id="{{ $profile->user->id }}"
        data-name="{{ $profile->fullname }}">
        <i class="fa fa-trash"></i>
    </button>
</div>