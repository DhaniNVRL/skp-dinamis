<div>
    {{ $userProfiles->links() }}
</div>