<div class="bg-white rounded-lg shadow-sm border border-gray-200 p-4 mb-4">
    <div class="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">

        {{-- Judul --}}
        <div>
            <h2 class="text-xl font-semibold text-gray-800">
                <span class="indoensia">Pengelolaan Akun</span>
            </h2>
            <p class="text-sm text-gray-500">
                Kelola seluruh data pengguna aplikasi.
            </p>
        </div>

        {{-- Action Button --}}
        <div class="flex flex-wrap gap-2">
            <button
                {{-- id="btnCreateUser" --}}
                data-modal-open="createUserModal"
                type="button"
                class="inline-flex items-center gap-2 px-4 py-2
                        bg-green-600 text-white rounded-lg
                        hover:bg-green-700 transition">
                <i class="fa fa-plus mr-1"></i>
                <span class="indoensia">Tambah Akun</span> 
            </button>
            <form action="{{ route('admin.import.datauser') }}"
                method="POST"
                enctype="multipart/form-data">
                @csrf
                <input type="file"
                    name="file"
                    accept=".xlsx,.xls"
                    required>
                <button type="submit"
                    class="inline-flex items-center gap-2 px-4 py-2
                            bg-green-600 text-white rounded-lg
                            hover:bg-green-700 transition">
                    <i class="fa fa-file-import mr-1"></i>
                    Import
                </button>
            </form>
            <a href="{{ route('admin.export.usertemplate') }}"
                class="inline-flex items-center gap-2 px-4 py-2
                        bg-indigo-600 text-white rounded-lg
                        hover:bg-indigo-700 transition">
                <i class="fa fa-download mr-1"></i>
                Export Template
            </a>
            <button id="btnDeleteSelected"
                type="button"
                class="inline-flex items-center gap-2 px-4 py-2
                        bg-red-600 text-white rounded-lg
                        hover:bg-red-700 transition">
                <i class="fa fa-trash mr-1"></i>
                Hapus yang Dipilih
            </button>
        </div>
    </div>
</div>