<div class="flex flex-wrap items-center justify-between gap-3">
    <div>
        <input
            type="checkbox"
            id="selectAllTable"
            class="bulk-select-all">

        <label for="selectAllTop">
            Pilih Semua
        </label>
    </div>

    <div class="flex flex-wrap gap-2">
        <button class="border rounded-lg px-3 py-2 hover:bg-gray-300">
            Reset Profile
        </button>
        <button class="border rounded-lg px-3 py-2 hover:bg-gray-300">
            Unlock Submit
        </button>
        <button class="border rounded-lg px-3 py-2 hover:bg-gray-300">
            Delete Answer
        </button>
    </div>
</div>