<div class="rounded-lg bg-white shadow-sm border border-gray-200 p-4">
    <form method="GET" action="{{ route('admin.datauser') }}">
        <div class="grid grid-cols-1 md:grid-cols-5 gap-4">
            {{-- Search --}}
            <div class="md:col-span-2">
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Cari Data .....
                </label>
                <input
                    id="searchInput"
                    type="text"
                    name="search"
                    value="{{ request('search') }}"
                    placeholder="Nama / Username"
                    class="w-full px-3 rounded-lg border h-10 border-gray-300 focus:ring-blue-500 focus:border-blue-500">
            </div>
            
            {{-- Activity --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Activity
                </label>
                <select
                    name="activity"
                    id="activityFilter"
                    class="w-full px-3 rounded-lg h-10 border border-gray-300">
                    <option value="">Semua</option>
                    @foreach($activities as $activity)
                        <option
                            value="{{ $activity->id }}"
                            @selected(request('activity') == $activity->id)>
                            {{ $activity->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            {{-- Role --}}
            <div>
                <label class="block text-sm font-medium text-gray-700 mb-1">
                    Role
                </label>
                <select
                    name="role"
                    id="roleFilter"
                    class="w-full px-3 rounded-lg h-10 border border-gray-300">
                    <option value="">Semua</option>
                    @foreach($roles as $role)
                        <option
                            value="{{ $role->id }}"
                            @selected(request('role') == $role->id)>
                            {{ $role->name }}
                        </option>
                    @endforeach
                </select>
            </div>

            {{-- Button --}}
            <div class="flex items-end gap-2">
                <button
                    class="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700">
                    Cari
                </button>
                <a
                    href="{{ route('admin.datauser') }}"
                    class="border px-4 py-2 rounded-lg hover:bg-gray-100">
                    Reset
                </a>
            </div>
        </div>
    </form>
</div>