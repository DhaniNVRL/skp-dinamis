<template id="suggestionTypeOptions">

    <option
        value="1"
        data-description="Judul atau pemisah kelompok pertanyaan."
    >
        Judul Pertanyaan
    </option>

    <option
        value="2"
        data-description="Pertanyaan dengan jawaban berupa saran atau masukan."
    >
        Saran
    </option>

</template><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/templates/forms/suggestion.blade.php ENDPATH**/ ?>