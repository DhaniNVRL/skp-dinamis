<?php echo $__env->make(
    'user.survey.forms.partials.engagement-assessment',
    [
        'maximumScale' => 5,
        'minimumLabel' => 'Sangat tidak setuju',
        'maximumLabel' => 'Sangat setuju',
    ]
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/engagement-assessment-1-5.blade.php ENDPATH**/ ?>