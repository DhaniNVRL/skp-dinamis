<?php switch((int) $question->questiontype_id):

    case (1): ?>
        <?php echo $__env->make(
            'admin.units.question.partials.forms.engagement-assessment-1-5.options.title',
            compact('question')
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (2): ?>
        <?php echo $__env->make(
            'admin.units.question.partials.forms.engagement-assessment-1-5.options.single-indicator',
            compact('question')
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php default: ?>

        <div
            class="rounded-xl border border-amber-200
                   bg-amber-50 px-4 py-3"
        >
            <div class="flex items-center gap-2 text-sm text-amber-700">

                <i class="fa-solid fa-triangle-exclamation"></i>

                <span>
                    Tampilan untuk tipe pertanyaan
                    <strong>#<?php echo e($question->questiontype_id); ?></strong>
                    belum tersedia.
                </span>

            </div>
        </div>

<?php endswitch; ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/engagement-assessment-1-5/question-body.blade.php ENDPATH**/ ?>