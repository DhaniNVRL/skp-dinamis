

<?php $__env->startSection('title', 'Edit Profil Responden'); ?>

<?php $__env->startSection('content'); ?>
<div
    id="respondentProfileEditPage"
    data-units-url="<?php echo e(url('/user/profile/groups')); ?>"
    class="mx-auto max-w-3xl space-y-6"
>
    
    <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div class="flex items-center gap-4">
            <a
                href="<?php echo e(route('profile.show')); ?>"
                class="flex h-10 w-10 items-center justify-center rounded-lg border border-gray-200 text-gray-500 transition hover:bg-gray-50"
            >
                <i class="fa-solid fa-arrow-left"></i>
            </a>

            <div>
                <h1 class="text-2xl font-bold text-gray-800">
                    Edit Profil Responden
                </h1>

                <p class="mt-1 text-sm text-gray-500">
                    Perbarui bidang kerja dan unit Anda.
                </p>
            </div>
        </div>
    </div>

    
    <?php if($errors->any()): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 p-5">
            <div class="font-semibold text-red-700">
                Data belum dapat diproses:
            </div>

            <ul class="mt-2 list-disc space-y-1 pl-5 text-sm text-red-600">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form
        action="<?php echo e(route('profile.update')); ?>"
        method="POST"
        class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm"
    >
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="space-y-6 p-6">
            
            <div>
                <label
                    class="mb-2 block text-sm font-semibold text-gray-700"
                >
                    Aktivitas
                </label>

                <div class="flex items-center gap-3 rounded-lg border border-gray-200 bg-gray-50 px-4 py-3">
                    <div class="flex h-9 w-9 items-center justify-center rounded-lg bg-purple-100 text-purple-600">
                        <i class="fa-solid fa-briefcase"></i>
                    </div>

                    <div>
                        <div class="font-medium text-gray-800">
                            <?php echo e($profile->activity?->name ?? '-'); ?>

                        </div>

                        <div class="text-xs text-gray-500">
                            Aktivitas tidak dapat diubah.
                        </div>
                    </div>
                </div>
            </div>

            
            <div>
                <label
                    id="groupLabel"
                    for="group_id"
                    class="mb-2 block text-sm font-semibold text-gray-700"
                >
                    <?php echo e($completeProfile?->group_question
                        ?? 'Bidang Kerja / Group'); ?>

                </label>

                <select
                    id="group_id"
                    name="group_id"
                    required
                    class="w-full rounded-lg border border-gray-300 bg-white px-3 py-3 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200"
                >
                    <option value="">
                        Pilih bidang kerja
                    </option>

                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($group->id); ?>"
                            <?php if(
                                (string) old(
                                    'group_id',
                                    $profile->group_id
                                ) === (string) $group->id
                            ): echo 'selected'; endif; ?>
                        >
                            <?php echo e($group->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <?php $__errorArgs = ['group_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600">
                        <?php echo e($message); ?>

                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div>
                <label
                    id="unitLabel"
                    for="unit_id"
                    class="mb-2 block text-sm font-semibold text-gray-700"
                >
                    <?php echo e($completeProfile?->unit_question
                        ?? 'Unit / Jabatan'); ?>

                </label>

                <select
                    id="unit_id"
                    name="unit_id"
                    required
                    class="w-full rounded-lg border border-gray-300 bg-white px-3 py-3 outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-200 disabled:cursor-not-allowed disabled:bg-gray-100"
                >
                    <option value="">
                        Pilih unit atau jabatan
                    </option>

                    <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option
                            value="<?php echo e($unit->id); ?>"
                            <?php if(
                                (string) old(
                                    'unit_id',
                                    $profile->unit_id
                                ) === (string) $unit->id
                            ): echo 'selected'; endif; ?>
                        >
                            <?php echo e($unit->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <p
                    id="unitLoadingMessage"
                    class="mt-2 hidden text-sm text-blue-500"
                >
                    <i class="fa-solid fa-spinner fa-spin mr-1"></i>
                    Memuat data unit...
                </p>

                <p
                    id="unitErrorMessage"
                    class="mt-2 hidden text-sm text-red-600"
                ></p>

                <?php $__errorArgs = ['unit_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="mt-2 text-sm text-red-600">
                        <?php echo e($message); ?>

                    </p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="rounded-lg border border-blue-200 bg-blue-50 p-4 text-sm text-blue-700">
                <i class="fa-solid fa-circle-info mr-2"></i>
                Bidang kerja hanya menampilkan data dari aktivitas Anda. Unit akan mengikuti bidang kerja yang dipilih.
            </div>
        </div>

        <div class="flex justify-end gap-3 border-t border-gray-200 bg-gray-50 px-6 py-4">
            <a
                href="<?php echo e(route('profile.show')); ?>"
                class="rounded-lg border border-gray-300 px-5 py-2.5 text-sm font-medium text-gray-600 transition hover:bg-gray-100"
            >
                Batal
            </a>

            <button
                id="saveProfileButton"
                type="submit"
                class="inline-flex items-center gap-2 rounded-lg bg-blue-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
                <i class="fa-solid fa-floppy-disk"></i>
                Simpan Profil
            </button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/profile/edit.blade.php ENDPATH**/ ?>