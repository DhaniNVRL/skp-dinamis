<div class="space-y-5">
    <?php $__empty_1 = true; $__currentLoopData = $questions->sortBy([
        ['no_header', 'asc'],
        ['no', 'asc'],
    ]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php
            $questionTypeId = (int) $question->questiontype_id;

            $storedAnswer = data_get(
                $answerMap,
                "{$question->id}.0.0",
                []
            );

            $storedValue = old(
                "answers.{$question->id}.value",
                data_get($storedAnswer, 'value')
            );

            $storedChildren = old(
                "answers.{$question->id}.child",
                data_get($storedAnswer, 'child', [])
            );

            $questionNumber = trim(
                ($question->no_header ?? '') .
                ($question->no ?? '')
            );
        ?>

        <div
            data-question-container
            data-question-id="<?php echo e($question->id); ?>"
            data-question-type="<?php echo e($questionTypeId); ?>"
            class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
        >
            
            <div class="mb-5 flex items-start gap-3">
                <span
                    class="inline-flex h-9 min-w-9 shrink-0 items-center
                           justify-center rounded-lg bg-indigo-100 px-2
                           text-sm font-semibold text-indigo-700"
                >
                    <?php echo e($questionNumber); ?>

                </span>

                <div class="min-w-0 flex-1">
                    <label class="font-semibold text-gray-900">
                        <?php echo e($question->name); ?>

                    </label>

                    <?php if($questionTypeId === 1): ?>
                        <p class="mt-1 text-xs uppercase tracking-wide text-gray-400">
                            Jawaban singkat
                        </p>
                    <?php elseif($questionTypeId === 2): ?>
                        <p class="mt-1 text-xs uppercase tracking-wide text-gray-400">
                            Jawaban panjang
                        </p>
                    <?php elseif($questionTypeId === 3): ?>
                        <p class="mt-1 text-xs uppercase tracking-wide text-gray-400">
                            Pilih satu jawaban
                        </p>
                    <?php elseif($questionTypeId === 4): ?>
                        <p class="mt-1 text-xs uppercase tracking-wide text-gray-400">
                            Pilih satu atau beberapa jawaban
                        </p>
                    <?php elseif(in_array($questionTypeId, [6, 9], true)): ?>
                        <p class="mt-1 text-xs uppercase tracking-wide text-gray-400">
                            Jawaban angka
                        </p>
                    <?php elseif($questionTypeId === 7): ?>
                        <p class="mt-1 text-xs uppercase tracking-wide text-gray-400">
                            Pilih tanggal
                        </p>
                    <?php elseif($questionTypeId === 8): ?>
                        <p class="mt-1 text-xs uppercase tracking-wide text-gray-400">
                            Alamat email
                        </p>
                    <?php endif; ?>
                </div>
            </div>

            
            <?php if($questionTypeId === 1): ?>
                <div class="relative">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400">
                        <i class="fa-regular fa-pen-to-square"></i>
                    </div>

                    <input
                        id="answer-<?php echo e($question->id); ?>"
                        type="text"
                        name="answers[<?php echo e($question->id); ?>][value]"
                        value="<?php echo e($storedValue); ?>"
                        required
                        maxlength="500"
                        autocomplete="off"
                        placeholder="Tulis jawaban singkat..."
                        class="w-full rounded-lg border border-gray-300
                               py-3 pl-11 pr-4 text-sm outline-none transition
                               focus:border-indigo-500 focus:ring-2
                               focus:ring-indigo-100"
                    >
                </div>

            
            <?php elseif($questionTypeId === 2): ?>
                <textarea
                    id="answer-<?php echo e($question->id); ?>"
                    name="answers[<?php echo e($question->id); ?>][value]"
                    rows="4"
                    required
                    maxlength="5000"
                    placeholder="Tulis jawaban..."
                    class="w-full rounded-lg border border-gray-300
                           px-4 py-3 text-sm outline-none transition
                           focus:border-indigo-500 focus:ring-2
                           focus:ring-indigo-100"
                ><?php echo e($storedValue); ?></textarea>

            
            <?php elseif($questionTypeId === 3): ?>
                <div
                    data-option-group
                    data-option-type="radio"
                    class="space-y-3"
                >
                    <?php $__empty_2 = true; $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php
                            $hasChild = (int) $option->has_child === 1;

                            $isChecked = (string) $storedValue ===
                                (string) $option->id;

                            $childValue = data_get(
                                $storedChildren,
                                $option->id,
                                ''
                            );
                        ?>

                        <div
                            data-option-item
                            class="rounded-lg border border-gray-200
                                   bg-white transition hover:border-indigo-300
                                   hover:bg-indigo-50/40"
                        >
                            <label
                                for="option-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                class="flex cursor-pointer items-start gap-3 p-4"
                            >
                                <input
                                    id="option-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                    type="radio"
                                    name="answers[<?php echo e($question->id); ?>][value]"
                                    value="<?php echo e($option->id); ?>"
                                    data-option-input
                                    data-has-child="<?php echo e($hasChild ? '1' : '0'); ?>"
                                    data-child-target="child-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                    <?php if($isChecked): echo 'checked'; endif; ?>
                                    required
                                    class="mt-0.5 h-4 w-4 border-gray-300
                                           text-indigo-600 focus:ring-indigo-500"
                                >

                                <span class="text-sm font-medium text-gray-700">
                                    <?php echo e($option->answer_text); ?>

                                </span>
                            </label>

                            <?php if($hasChild): ?>
                                <div
                                    id="child-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                    data-child-container
                                    class="<?php echo e($isChecked ? '' : 'hidden'); ?>

                                           border-t border-gray-200 px-4 py-4"
                                >
                                    <?php if(filled($option->answer_text2)): ?>
                                        <label
                                            for="child-answer-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                            class="mb-2 block text-sm font-medium text-gray-700"
                                        >
                                            <?php echo e($option->answer_text2); ?>

                                        </label>
                                    <?php endif; ?>

                                    <textarea
                                        id="child-answer-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                        name="answers[<?php echo e($question->id); ?>][child][<?php echo e($option->id); ?>]"
                                        rows="3"
                                        data-child-input
                                        <?php if($isChecked): echo 'required'; endif; ?>
                                        placeholder="Tulis jawaban tambahan..."
                                        class="w-full rounded-lg border border-gray-300
                                               px-4 py-3 text-sm outline-none transition
                                               focus:border-indigo-500 focus:ring-2
                                               focus:ring-indigo-100"
                                    ><?php echo e($childValue); ?></textarea>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <div class="rounded-lg border border-dashed border-gray-300 p-5 text-center text-sm text-gray-500">
                            Pilihan jawaban belum tersedia.
                        </div>
                    <?php endif; ?>
                </div>

            
            <?php elseif($questionTypeId === 4): ?>
                <?php
                    $checkedValues = is_array($storedValue)
                        ? array_map('strval', $storedValue)
                        : [];
                ?>

                <div
                    data-option-group
                    data-option-type="checkbox"
                    data-required-group
                    class="space-y-3"
                >
                    <?php $__empty_2 = true; $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php
                            $hasChild = (int) $option->has_child === 1;

                            $isChecked = in_array(
                                (string) $option->id,
                                $checkedValues,
                                true
                            );

                            $childValue = data_get(
                                $storedChildren,
                                $option->id,
                                ''
                            );
                        ?>

                        <div
                            data-option-item
                            class="rounded-lg border border-gray-200
                                   bg-white transition hover:border-indigo-300
                                   hover:bg-indigo-50/40"
                        >
                            <label
                                for="option-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                class="flex cursor-pointer items-start gap-3 p-4"
                            >
                                <input
                                    id="option-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                    type="checkbox"
                                    name="answers[<?php echo e($question->id); ?>][value][]"
                                    value="<?php echo e($option->id); ?>"
                                    data-option-input
                                    data-has-child="<?php echo e($hasChild ? '1' : '0'); ?>"
                                    data-child-target="child-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                    <?php if($isChecked): echo 'checked'; endif; ?>
                                    class="mt-0.5 h-4 w-4 rounded border-gray-300
                                           text-indigo-600 focus:ring-indigo-500"
                                >

                                <span class="text-sm font-medium text-gray-700">
                                    <?php echo e($option->answer_text); ?>

                                </span>
                            </label>

                            <?php if($hasChild): ?>
                                <div
                                    id="child-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                    data-child-container
                                    class="<?php echo e($isChecked ? '' : 'hidden'); ?>

                                           border-t border-gray-200 px-4 py-4"
                                >
                                    <?php if(filled($option->answer_text2)): ?>
                                        <label
                                            for="child-answer-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                            class="mb-2 block text-sm font-medium text-gray-700"
                                        >
                                            <?php echo e($option->answer_text2); ?>

                                        </label>
                                    <?php endif; ?>

                                    <textarea
                                        id="child-answer-<?php echo e($question->id); ?>-<?php echo e($option->id); ?>"
                                        name="answers[<?php echo e($question->id); ?>][child][<?php echo e($option->id); ?>]"
                                        rows="3"
                                        data-child-input
                                        <?php if($isChecked): echo 'required'; endif; ?>
                                        placeholder="Tulis jawaban tambahan..."
                                        class="w-full rounded-lg border border-gray-300
                                               px-4 py-3 text-sm outline-none transition
                                               focus:border-indigo-500 focus:ring-2
                                               focus:ring-indigo-100"
                                    ><?php echo e($childValue); ?></textarea>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <div class="rounded-lg border border-dashed border-gray-300 p-5 text-center text-sm text-gray-500">
                            Pilihan jawaban belum tersedia.
                        </div>
                    <?php endif; ?>
                </div>

            
            <?php elseif(in_array($questionTypeId, [6, 9], true)): ?>
                <div class="relative">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400">
                        <i class="fa-solid fa-hashtag"></i>
                    </div>

                    <input
                        id="answer-<?php echo e($question->id); ?>"
                        type="number"
                        name="answers[<?php echo e($question->id); ?>][value]"
                        value="<?php echo e($storedValue); ?>"
                        required
                        inputmode="numeric"
                        placeholder="Masukkan nilai angka..."
                        class="w-full rounded-lg border border-gray-300
                               py-3 pl-11 pr-4 text-sm outline-none transition
                               focus:border-indigo-500 focus:ring-2
                               focus:ring-indigo-100"
                    >
                </div>

            
            <?php elseif($questionTypeId === 7): ?>
                <input
                    id="answer-<?php echo e($question->id); ?>"
                    type="date"
                    name="answers[<?php echo e($question->id); ?>][value]"
                    value="<?php echo e($storedValue); ?>"
                    required
                    class="w-full rounded-lg border border-gray-300
                           px-4 py-3 text-sm outline-none transition
                           focus:border-indigo-500 focus:ring-2
                           focus:ring-indigo-100"
                >

            
            <?php elseif($questionTypeId === 8): ?>
                <div class="relative">
                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-4 text-gray-400">
                        <i class="fa-regular fa-envelope"></i>
                    </div>

                    <input
                        id="answer-<?php echo e($question->id); ?>"
                        type="email"
                        name="answers[<?php echo e($question->id); ?>][value]"
                        value="<?php echo e($storedValue); ?>"
                        required
                        autocomplete="email"
                        placeholder="nama@email.com"
                        class="w-full rounded-lg border border-gray-300
                               py-3 pl-11 pr-4 text-sm outline-none transition
                               focus:border-indigo-500 focus:ring-2
                               focus:ring-indigo-100"
                    >
                </div>

            
            <?php else: ?>
                <div class="rounded-lg border border-red-200 bg-red-50 p-4 text-sm text-red-600">
                    Tipe pertanyaan <?php echo e($questionTypeId); ?> belum didukung.
                </div>
            <?php endif; ?>

            <p
                data-question-error
                class="mt-3 hidden text-sm font-medium text-red-600"
            >
                Pertanyaan ini wajib diisi.
            </p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make('user.survey.partials.empty', [
            'message' => 'Form ini belum memiliki pertanyaan aktif.',
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/general-questionnaire.blade.php ENDPATH**/ ?>