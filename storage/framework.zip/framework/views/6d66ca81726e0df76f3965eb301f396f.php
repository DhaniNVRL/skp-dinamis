<div id="groupBulkAction" class="hidden rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
    <i class="fa-solid fa-circle-check mr-2"></i>
    <span id="selectedGroupCount">0</span> Group dipilih.
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/groups/groups/partials/bulk-action.blade.php ENDPATH**/ ?>