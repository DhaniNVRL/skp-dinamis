<div class="flex shrink-0 items-center gap-2">

     <button
        type="button"
        data-modal-open="editQuestionModal"

        data-id="<?php echo e($question->id); ?>"
        data-group-id="<?php echo e($question->group_id); ?>"
        data-form-id="<?php echo e($question->form_id); ?>"
        data-form-type-id="<?php echo e($form->formtype_id); ?>"

        data-header="<?php echo e($question->no_header); ?>"
        data-no="<?php echo e($question->no); ?>"
        data-name="<?php echo e($question->name); ?>"

        data-question-type-id="<?php echo e($question->questiontype_id
            ?? $question->id_questiontypes); ?>"

        data-action="<?php echo e(route('question.update', $question->id)); ?>"

        class="inline-flex h-9 w-9 items-center justify-center
               rounded-lg bg-amber-100 text-amber-600
               transition hover:bg-amber-200"
        title="Edit pertanyaan"
    >
        <i class="fa-solid fa-pen"></i>
    </button>

    <button
        type="button"
        data-modal-open="deleteQuestionModal"
        data-id="<?php echo e($question->id); ?>"
        data-name="<?php echo e($question->name); ?>"
        data-option-count="<?php echo e($question->options?->count() ?? 0); ?>"
        data-action="<?php echo e(route('question.destroy', [
            'id' => $question->id,
        ])); ?>"

        onclick="
            const deleteForm = document.getElementById('deleteQuestionForm');

            if (deleteForm) {
                deleteForm.action = this.dataset.action;
            }
        "

        class="flex h-8 w-8 items-center justify-center
            rounded-lg bg-red-50 text-red-600
            transition hover:bg-red-100"
        title="Hapus pertanyaan"
    >
        <i class="fa-solid fa-trash text-xs"></i>
    </button>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/question-action.blade.php ENDPATH**/ ?>