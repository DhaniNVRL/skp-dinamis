<div
    id="createActivityModal"
    data-modal
    class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 p-6"
>
    <div class="max-h-[90vh] w-full max-w-4xl overflow-y-auto rounded-xl bg-white shadow-xl">

        
        <div class="flex items-center justify-between border-b border-gray-200 px-6 py-4">

            <div>
                <h2 class="text-xl font-semibold text-gray-800">
                    Tambah Activity
                </h2>

                <p class="mt-1 text-sm text-gray-500">
                    Tambahkan satu atau beberapa activity sekaligus.
                </p>
            </div>

            <button
                type="button"
                data-modal-close="createActivityModal"
                class="text-gray-400 transition hover:text-red-600"
            >
                <i class="fa-solid fa-xmark text-xl"></i>
            </button>

        </div>


        
        <form
            action="<?php echo e(route('admin.storeactivity')); ?>"
            method="POST"
        >
            <?php echo csrf_field(); ?>


            
            <div class="overflow-x-auto p-6">

                <div class="overflow-hidden rounded-lg border border-gray-200">

                    <table
                        id="activityCreateTable"
                        data-dynamic-table
                        data-template="createActivityRowTemplate"
                        class="w-full border-collapse"
                    >

                        <thead class="bg-gray-100">

                            <tr>

                                <th
                                    class="w-20 border-b border-r border-gray-200 px-4 py-3 text-center text-xs font-semibold uppercase text-gray-600"
                                >
                                    No
                                </th>

                                <th
                                    class="border-b border-r border-gray-200 px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600"
                                >
                                    Nama Activity
                                </th>

                                <th
                                    class="border-b border-r border-gray-200 px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600"
                                >
                                    Deskripsi
                                </th>

                                <th
                                    class="w-20 border-b border-gray-200 px-4 py-3 text-center text-xs font-semibold uppercase text-gray-600"
                                >
                                    Aksi
                                </th>

                            </tr>

                        </thead>


                        <tbody
                            id="activityCreateBody"
                            class="divide-y divide-gray-200"
                        >
                        </tbody>

                    </table>

                </div>

            </div>


            
            <div class="flex items-center justify-between border-t border-gray-200 bg-gray-50 px-6 py-4">

                <button
                    type="button"
                    data-add-row="activityCreateBody"
                    class="inline-flex items-center gap-2 rounded-lg border border-green-600 px-4 py-2 text-green-600 transition hover:bg-green-50"
                >
                    <i class="fa-solid fa-plus"></i>

                    Tambah Baris
                </button>


                <div class="flex items-center gap-2">

                    <button
                        type="button"
                        data-modal-close="createActivityModal"
                        class="rounded-lg border border-gray-300 px-4 py-2 text-gray-700 transition hover:bg-gray-100"
                    >
                        Batal
                    </button>

                    <button
                        type="submit"
                        class="rounded-lg bg-blue-600 px-5 py-2 text-white transition hover:bg-blue-700"
                    >
                        <i class="fa-solid fa-floppy-disk mr-1"></i>

                        Simpan
                    </button>

                </div>

            </div>

        </form>

    </div>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/activities/modals/create.blade.php ENDPATH**/ ?>