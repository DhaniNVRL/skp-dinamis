<div class="rounded-lg border border-dashed border-gray-300 bg-gray-50 px-6 py-12 text-center">
    <div class="text-4xl text-gray-300">
        <i class="fa-solid fa-eye"></i>
    </div>

    <h2 class="mt-4 text-lg font-semibold text-gray-700">
        Hide and Show Pertanyaan
    </h2>

    <p class="mt-2 text-sm text-gray-500">
        Bagian ini akan digunakan untuk mengatur pertanyaan yang tampil pada setiap sub-unit.
    </p>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/tabs/hide-show.blade.php ENDPATH**/ ?>