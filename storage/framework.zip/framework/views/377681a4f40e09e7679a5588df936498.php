<div class="flex items-center gap-3 shrink-0">

    
    <button
        type="button"
        data-modal-open="editFormModal"
        data-id="<?php echo e($form->id); ?>"
        data-group-id="<?php echo e($form->group_id); ?>"
        data-no-urut="<?php echo e($form->no_urut); ?>"
        data-name="<?php echo e($form->name); ?>"
        data-formtype-id="<?php echo e($form->formtype_id); ?>"
        data-action="<?php echo e(route('forms.update', ['id' => $form->id])); ?>"
        class="flex h-8 w-8 items-center justify-center
            rounded-lg bg-amber-50 text-amber-600
            transition hover:bg-amber-100"
        title="Edit form"
    >
        <i class="fa-solid fa-pen text-xs"></i>
    </button>


    
    <button
        type="button"
        data-modal-open="deleteFormModal"
        data-id="<?php echo e($form->id); ?>"
        data-name="<?php echo e($form->name); ?>"
        data-question-count="<?php echo e($form->questions->count()); ?>"
        data-option-count="<?php echo e($form->questions->sum(fn ($question) => $question->options->count())); ?>"
        data-action="<?php echo e(route('forms.destroy', ['id' => $form->id])); ?>"
        class="flex h-8 w-8 items-center justify-center
            rounded-lg bg-red-50 text-red-600
            transition hover:bg-red-100"
        title="Hapus form"
    >
        <i class="fa-solid fa-trash text-xs"></i>
    </button>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/form-action.blade.php ENDPATH**/ ?>