<form
    action="<?php echo e(route('survey.finish')); ?>"
    method="POST"
>
    <?php echo csrf_field(); ?>

    <button
        type="submit"
        class="inline-flex items-center gap-2 rounded-xl bg-green-600 px-6 py-3 font-semibold text-white hover:bg-green-700"
    >
        <i class="fa-solid fa-flag-checkered"></i>
        Akhiri Survei
    </button>
</form><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/finish.blade.php ENDPATH**/ ?>