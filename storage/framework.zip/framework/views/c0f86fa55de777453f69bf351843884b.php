<div class="space-y-5">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noHeader => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $group->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionTypeId = (int) (
                    $question->questiontype_id
                    ?? $question->id_questiontypes
                    ?? 0
                );
            ?>

            
            <?php if($questionTypeId === 1): ?>
                <div class="rounded-xl border border-indigo-200 bg-indigo-50 p-5">
                    <div class="flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Judul Pertanyaan
                            </p>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                
                <div class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <div class="mb-6 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Penilaian Keterikatan Skala 1–5
                            </p>
                        </div>
                    </div>

                    
                    <div class="flex w-full justify-center">
                        <div class="w-fit">
                            <?php echo $__env->make(
                                'admin.subunit.show-question.forms.partials.scale',
                                [
                                    'question' => $question,
                                    'maximum' => 5,
                                    'includeZero' => false,
                                    'name' => "engagement_{$question->id}",
                                    'leftLabel' => 'Sangat tidak setuju',
                                    'rightLabel' => 'Sangat setuju',
                                ]
                            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.partials.empty'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/forms/engagement-assessment-1-5.blade.php ENDPATH**/ ?>