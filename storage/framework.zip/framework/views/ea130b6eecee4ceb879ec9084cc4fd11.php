

<?php $__env->startSection('content'); ?>
<div class="w-full px-6 py-6">
    <div class="max-w-[1600px] mx-auto">
        <div class="bg-white rounded-xl shadow">
            <div class="border-b p-6">
                <h2 class="text-2xl font-bold">
                    <?php echo e($form->name); ?>

                </h2>
                <p class="text-gray-500">
                    <?php echo e($form->formtype->name); ?>

                    -
                    <?php echo e($form->formtype->description); ?>

                </p>
            </div>

            <div class="p-6">
                <form
                    id="surveyForm"
                    action="<?php echo e(route('survey.update',$form)); ?>"
                    method="POST">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <?php switch($form->id_formtype):

                        case (1): ?>
                            <?php echo $__env->make('user.survey.show.kuesioner_umum', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (2): ?>
                            <?php echo $__env->make('user.survey.show.penilaian_pelanggan_1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (3): ?>
                            <?php echo $__env->make('user.survey.show.penilaian_pelanggan_1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (4): ?>
                            <?php echo $__env->make('user.survey.show.penilaian_keterikatan_1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (5): ?>
                            <?php echo $__env->make('user.survey.show.penilaian_keterikatan_1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (8): ?>
                            <?php echo $__env->make('user.survey.show.keunggulan_keluhan_saran', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                        <?php case (6): ?>
                            <?php echo $__env->make('user.survey.show.rangking_1-3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (7): ?>
                            <?php echo $__env->make('user.survey.show.rangking_1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (9): ?>
                            <?php echo $__env->make('user.survey.show.keluhan_saran', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (10): ?>
                            <?php echo $__env->make('user.survey.show.saran', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (11): ?>
                            <?php echo $__env->make('user.survey.show.kompetitor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                        <?php case (12): ?>
                            <?php echo $__env->make('user.survey.show.description', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                            
                        <?php break; ?>

                    <?php endswitch; ?>

                    <?php if($form->id_formtype != 12): ?>
                        <div class="flex justify-between mt-8">
                            <?php
                                $prevForm = \App\Models\Form::where('group_id', $form->group_id)
                                    ->where('no_urut','<',$form->no_urut)
                                    ->orderByDesc('no_urut')
                                    ->first();
                            ?>
                            <div>
                                <?php if($prevForm): ?>
                                    <a
                                        href="<?php echo e(route('survey.show',$prevForm)); ?>"
                                        class="px-6 py-3 rounded-lg bg-gray-600 text-white hover:bg-gray-700">
                                        ← Kembali
                                    </a>
                                <?php endif; ?>
                            </div>
                            <button
                                type="submit"
                                class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-lg">
                                Simpan & Lanjut →
                            </button>
                        </div>
                    <?php endif; ?>

                </form>
                
                <form id="startSurveyForm"
                    action="<?php echo e(route('survey.start',$form)); ?>"
                    method="POST"
                    class="hidden">
                    <?php echo csrf_field(); ?>
                </form>

                
                <form id="finishSurveyForm"
                    action="<?php echo e(route('survey.finish')); ?>"
                    method="POST"
                    class="hidden">
                    <?php echo csrf_field(); ?>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<script>
document.addEventListener("DOMContentLoaded", function () {

    //====================================================
    // VALIDASI FORM SURVEY
    //====================================================

    const surveyForm = document.getElementById("surveyForm");

    if (surveyForm) {

        surveyForm.addEventListener("submit", function (e) {

            // Form Description tidak perlu validasi
            if (<?php echo e($form->id_formtype); ?> == 12) {
                return;
            }

            let firstInvalid = null;

            //==========================
            // RADIO
            //==========================
            const radioGroups = {};

            surveyForm.querySelectorAll("input[type='radio']").forEach(radio => {

                if (!radioGroups[radio.name]) {
                    radioGroups[radio.name] = false;
                }

                if (radio.checked) {
                    radioGroups[radio.name] = true;
                }

            });

            Object.keys(radioGroups).forEach(name => {

                if (!radioGroups[name]) {

                    if (!firstInvalid) {
                        firstInvalid = surveyForm.querySelector(`[name="${CSS.escape(name)}"]`);
                    }

                }

            });

            //==========================
            // SELECT
            //==========================
            surveyForm.querySelectorAll("select").forEach(select => {

                if (select.value === "" && !firstInvalid) {
                    firstInvalid = select;
                }

            });

            //==========================
            // TEXTAREA
            //==========================
            surveyForm.querySelectorAll("textarea").forEach(textarea => {

                if (textarea.offsetParent === null) {
                    return;
                }

                if (textarea.value.trim() === "" && !firstInvalid) {
                    firstInvalid = textarea;
                }

            });

            //==========================
            // ADA YANG BELUM DIISI
            //==========================

            if (firstInvalid) {

                e.preventDefault();

                alert("Masih ada pertanyaan yang belum diisi.");

                firstInvalid.scrollIntoView({
                    behavior: "smooth",
                    block: "center"
                });

                firstInvalid.focus();

            }

        });

    }

    //====================================================
    // MULAI SURVEY
    //====================================================

    const startButton = document.getElementById("btnStartSurvey");

    if (startButton) {

        startButton.addEventListener("click", function () {

            console.log("Start Survey");

            document.getElementById("startSurveyForm").submit();

        });

    }

    //====================================================
    // AKHIRI SURVEY
    //====================================================

    const finishButton = document.getElementById("btnFinishSurvey");

    if (finishButton) {

        finishButton.addEventListener("click", function () {

            if (confirm("Yakin ingin mengakhiri survey?")) {

                document.getElementById("finishSurveyForm").submit();

            }

        });

    }

});
</script>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/show.blade.php ENDPATH**/ ?>