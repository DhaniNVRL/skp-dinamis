<?php
    $scopeId = isset($subunit)
        ? $subunit->id
        : 'global';
?>

<div
    data-general-questionnaire
    class="space-y-5"
>
    <?php $__empty_1 = true; $__currentLoopData = $questions->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php
            $questionTypeId = (int) (
                $question->questiontype_id
                ?? $question->id_questiontypes
                ?? 0
            );

            $questionContainerId =
                'general_question_'
                . $question->id
                . '_'
                . $scopeId;
        ?>

        
        <?php if($questionTypeId === 1): ?>
            <div class="rounded-xl border border-indigo-200 bg-indigo-50 p-5">
                <div class="flex items-start gap-3">
                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.question-number',
                        [
                            'question' => $question,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div>
                        <h3 class="font-semibold text-gray-800">
                            <?php echo e($question->name); ?>

                        </h3>

                        <p class="mt-1 text-xs text-gray-500">
                            Judul Pertanyaan
                        </p>
                    </div>
                </div>
            </div>

        
        <?php elseif($questionTypeId === 2): ?>
            <div class="rounded-xl border border-gray-200 bg-white p-5">
                <div class="mb-4 flex items-start gap-3">
                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.question-number',
                        [
                            'question' => $question,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <h3 class="font-semibold text-gray-800">
                        <?php echo e($question->name); ?>

                    </h3>
                </div>

                <textarea
                    name="general_answers[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>]"
                    rows="4"
                    class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
                    placeholder="Tulis jawaban Anda..."
                ></textarea>
            </div>

        
        <?php elseif($questionTypeId === 3): ?>
            <div
                id="<?php echo e($questionContainerId); ?>"
                data-general-question
                data-general-question-type="radio"
                class="rounded-xl border border-gray-200 bg-white p-5"
            >
                <div class="mb-4 flex items-start gap-3">
                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.question-number',
                        [
                            'question' => $question,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <h3 class="font-semibold text-gray-800">
                        <?php echo e($question->name); ?>

                    </h3>
                </div>

                <div class="space-y-3">
                    <?php $__empty_2 = true; $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php
                            $hasChild =
                                (int) $option->has_child === 1;

                            $optionInputId =
                                'general_radio_'
                                . $question->id
                                . '_'
                                . $scopeId
                                . '_'
                                . $option->id;
                        ?>

                        <div
                            data-general-option
                            class="rounded-lg border border-gray-200 bg-white p-4 transition hover:bg-gray-50"
                        >
                            <div class="flex items-start gap-3">
                                <input
                                    id="<?php echo e($optionInputId); ?>"
                                    type="radio"
                                    name="general_answers[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>]"
                                    value="<?php echo e($option->id); ?>"
                                    data-general-option-input
                                    data-has-child="<?php echo e($hasChild ? '1' : '0'); ?>"
                                    class="mt-1 h-4 w-4 border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                >

                                <label
                                    for="<?php echo e($optionInputId); ?>"
                                    class="min-w-0 flex-1 cursor-pointer text-sm font-medium text-gray-700"
                                >
                                    <?php echo e($option->answer_text); ?>

                                </label>
                            </div>

                            <?php if($hasChild): ?>
                                <div
                                    data-general-child
                                    class="mt-3 hidden pl-7"
                                >
                                    <?php if(!empty($option->child_label)): ?>
                                        <label
                                            for="child_<?php echo e($optionInputId); ?>"
                                            class="mb-2 block text-xs font-medium text-gray-600"
                                        >
                                            <?php echo e($option->child_label); ?>

                                        </label>
                                    <?php endif; ?>

                                    <textarea
                                        id="child_<?php echo e($optionInputId); ?>"
                                        name="general_child_answers[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>][<?php echo e($option->id); ?>]"
                                        rows="3"
                                        disabled
                                        data-general-child-input
                                        class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
                                        placeholder="<?php echo e($option->child_placeholder ?? 'Jawaban tambahan...'); ?>"
                                    ></textarea>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <div class="rounded-lg border border-dashed border-gray-300 px-4 py-8 text-center text-sm text-gray-500">
                            Pilihan jawaban belum tersedia.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        
        <?php elseif($questionTypeId === 4): ?>
            <div
                id="<?php echo e($questionContainerId); ?>"
                data-general-question
                data-general-question-type="checkbox"
                class="rounded-xl border border-gray-200 bg-white p-5"
            >
                <div class="mb-4 flex items-start gap-3">
                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.question-number',
                        [
                            'question' => $question,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div>
                        <h3 class="font-semibold text-gray-800">
                            <?php echo e($question->name); ?>

                        </h3>

                        <p class="mt-1 text-xs text-gray-500">
                            Anda dapat memilih lebih dari satu jawaban.
                        </p>
                    </div>
                </div>

                <div class="space-y-3">
                    <?php $__empty_2 = true; $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                        <?php
                            $hasChild =
                                (int) $option->has_child === 1;

                            $optionInputId =
                                'general_checkbox_'
                                . $question->id
                                . '_'
                                . $scopeId
                                . '_'
                                . $option->id;
                        ?>

                        <div
                            data-general-option
                            class="rounded-lg border border-gray-200 bg-white p-4 transition hover:bg-gray-50"
                        >
                            <div class="flex items-start gap-3">
                                <input
                                    id="<?php echo e($optionInputId); ?>"
                                    type="checkbox"
                                    name="general_answers[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>][]"
                                    value="<?php echo e($option->id); ?>"
                                    data-general-option-input
                                    data-has-child="<?php echo e($hasChild ? '1' : '0'); ?>"
                                    class="mt-1 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                >

                                <label
                                    for="<?php echo e($optionInputId); ?>"
                                    class="min-w-0 flex-1 cursor-pointer text-sm font-medium text-gray-700"
                                >
                                    <?php echo e($option->answer_text); ?>

                                </label>
                            </div>

                            <?php if($hasChild): ?>
                                <div
                                    data-general-child
                                    class="mt-3 hidden pl-7"
                                >
                                    <?php if(!empty($option->child_label)): ?>
                                        <label
                                            for="child_<?php echo e($optionInputId); ?>"
                                            class="mb-2 block text-xs font-medium text-gray-600"
                                        >
                                            <?php echo e($option->child_label); ?>

                                        </label>
                                    <?php endif; ?>

                                    <textarea
                                        id="child_<?php echo e($optionInputId); ?>"
                                        name="general_child_answers[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>][<?php echo e($option->id); ?>]"
                                        rows="3"
                                        disabled
                                        data-general-child-input
                                        class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
                                        placeholder="<?php echo e($option->child_placeholder ?? 'Jawaban tambahan...'); ?>"
                                    ></textarea>
                                </div>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                        <div class="rounded-lg border border-dashed border-gray-300 px-4 py-8 text-center text-sm text-gray-500">
                            Pilihan jawaban belum tersedia.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

        
        <?php else: ?>
            <div class="rounded-lg border border-yellow-200 bg-yellow-50 p-4">
                <div class="flex items-start gap-3">
                    <i class="fa-solid fa-triangle-exclamation mt-1 text-yellow-500"></i>

                    <div>
                        <div class="font-medium text-gray-800">
                            <?php echo e($question->name); ?>

                        </div>

                        <p class="mt-1 text-sm text-yellow-700">
                            Question Type <?php echo e($questionTypeId); ?> belum didukung.
                        </p>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.partials.empty'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/forms/general-questionnaire.blade.php ENDPATH**/ ?>