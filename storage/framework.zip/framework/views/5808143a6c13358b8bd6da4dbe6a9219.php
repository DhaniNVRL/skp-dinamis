<div class="space-y-6">
    <?php $__empty_1 = true; $__currentLoopData = $forms->sortBy('no_urut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div
            class="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
            
            <div class="flex items-start justify-between gap-4 px-6 py-5 border-b border-gray-200">
                <div class="min-w-0">
                    <div class="flex items-center gap-3">
                        
                        <span
                            class="flex items-center justify-center
                                   min-w-8 h-8 px-2
                                   bg-indigo-100 text-indigo-700
                                   text-sm font-semibold rounded-lg">
                            <?php echo e($form->no_urut); ?>

                        </span>
                        
                        <h3 class="text-lg font-semibold text-gray-800">
                            <?php echo e($form->name); ?>

                        </h3>
                    </div>
                    
                    <?php if($form->formtype): ?>

                        <div class="mt-3">

                            <span
                                class="inline-flex items-center
                                       px-3 py-1
                                       text-xs font-medium
                                       bg-indigo-50 text-indigo-700
                                       rounded-full">

                                <?php echo e($form->formtype->name); ?>


                                <?php if($form->formtype->description): ?>
                                    <span class="mx-1">
                                        —
                                    </span>

                                    <?php echo e($form->formtype->description); ?>

                                <?php endif; ?>

                            </span>

                        </div>

                    <?php endif; ?>

                </div>


                
                <?php echo $__env->make(
                    'admin.units.question.partials.form-action',
                    ['form' => $form]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>


            
            <div class="p-6 bg-gray-50">

                <?php switch($form->formtype_id):

                    case (1): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.general-questionnaire.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <?php break; ?>


                    <?php case (2): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.customer-assessment-1-5.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (3): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.customer-assessment-1-7.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (4): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.engagement-assessment-1-5.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (5): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.engagement-assessment-1-7.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (6): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.ranking-1-3.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (7): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.ranking-1-5.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (8): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.strength-complaint-suggestion.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (9): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.complaint-suggestion.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (10): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.suggestion.index',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (11): ?>

                        <?php echo $__env->make(
                            'admin.units.question.partials.forms.general-questionnaire.index',
                            // 'admin.units.question.partials.forms.competitor',
                            [
                                'form' => $form,
                                'questions' => $form->questions
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php case (12): ?>

                        <?php echo $__env->make(
                                'admin.units.question.partials.forms.toolbar',
                                ['form' => $form]
                            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                            <?php echo $__env->make(
                                'admin.units.question.partials.forms.description',
                                ['form' => $form]
                            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <?php break; ?>


                    <?php default: ?>

                        <div
                            class="p-4 text-sm text-red-600
                                   bg-red-50 border border-red-200 rounded-lg">

                            Form type tidak ditemukan.

                        </div>

                <?php endswitch; ?>

            </div>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <div
            class="bg-white border border-gray-200
                   rounded-xl py-16 text-center">

            <div class="text-gray-300 text-4xl mb-3">
                <i class="fa-regular fa-file-lines"></i>
            </div>

            <h3 class="text-gray-700 font-medium">
                Belum ada form
            </h3>

            <p class="text-sm text-gray-500 mt-1">
                Klik "Tambah Form" untuk membuat form pertama.
            </p>

        </div>

    <?php endif; ?>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/form-card.blade.php ENDPATH**/ ?>