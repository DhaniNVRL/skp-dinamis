<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

    
    <script src="https://cdn.tailwindcss.com"></script>

    
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    
    <script defer src="https://unpkg.com/alpinejs@3.x.x/dist/cdn.min.js"></script>

    
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>

    
    <link rel="stylesheet"
          href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">


    <style>
        [x-cloak]{
            display:none !important;
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>

</head>

<body class="h-screen overflow-hidden bg-gray-100">

    
    <?php echo $__env->make('admin.layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="flex flex-1 overflow-hidden">

        
        <?php echo $__env->make('admin.layouts.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <main
            class="fixed
                   top-16 bottom-12
                   left-64 right-0
                   px-6 py-6
                   overflow-y-auto
                   bg-gray-100">

            <?php echo $__env->yieldContent('content'); ?>

        </main>

    </div>

    
    <?php echo $__env->make('admin.layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <script src="<?php echo e(asset('js/global-modal.js')); ?>"></script>
    <script src="<?php echo e(asset('js/global-modal-tab.js')); ?>"></script>
    <script src="<?php echo e(asset('js/global-form.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>