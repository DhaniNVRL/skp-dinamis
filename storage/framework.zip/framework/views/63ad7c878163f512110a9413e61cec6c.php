



<div class="w-full">

    <?php echo $__env->make(
        'admin.units.question.partials.toolbar'
    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make(
        'admin.units.question.partials.form-card'
    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div>






<?php echo $__env->make('admin.units.question.templates.create-form-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/pages/question.blade.php ENDPATH**/ ?>