<template id="generalQuestionnaireTypeOptions">

    <?php $__currentLoopData = $questionTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $questionType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option
            value="<?php echo e($questionType->id); ?>"
            data-description="<?php echo e($questionType->description ?? ''); ?>"
        >
            <?php echo e($questionType->name); ?>

        </option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</template><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/templates/forms/general-questionnaire.blade.php ENDPATH**/ ?>