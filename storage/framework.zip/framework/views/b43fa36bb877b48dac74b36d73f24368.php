<?php
    $subunitList = $subunitIds->toArray();

    $answerMap = [];

    foreach ($answers as $row) {

        $decoded = json_decode($row->answer, true);

        $answerMap[$row->question_id] =
            json_last_error() === JSON_ERROR_NONE
                ? $decoded
                : $row->answer;
    }
?>
    
    
    
    <?php $__currentLoopData = $form->questions->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php

            $current = $answerMap[$question->id] ?? null;

                if (!is_array($current)) {

                    $current = [
                        'value' => $current
                    ];

                }
                // kalau hasil decode berupa array biasa (checkbox lama)
                elseif (array_keys($current) === range(0, count($current) - 1)) {

                    $current = [
                        'value' => $current
                    ];

                }

            $key = $form->id.'-'.$question->id;

            $hasRelation =
                isset($activeMapSubUnit[$key]) &&
                count(array_intersect(
                    $activeMapSubUnit[$key],
                    $subunitList
                )) > 0;

        ?>

        <?php if($hasRelation): ?>

        <div class="question-card mb-6 p-5 border rounded-lg shadow-sm bg-white">

            <div class="mb-4">

                <label class="font-semibold text-gray-800">

                    <?php echo e($question->no_header); ?><?php echo e($question->no); ?>.
                    <?php echo e($question->name); ?>


                </label>

            </div>

            
            <?php if($question->questiontype_id==1): ?>
                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">
                    <input
                        type="text"
                        class="border rounded p-2 w-full"
                        name="answers[<?php echo e($question->id); ?>]"
                        value="<?php echo e(is_array($current) ? ($current['value'] ?? '') : $current); ?>">
                </div>

            
            <?php elseif($question->questiontype_id==2): ?>

                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">
                    <textarea
                        class="border rounded p-2 w-full"
                        name="answers[<?php echo e($question->id); ?>]"><?php echo e(is_array($current) ? ($current['value'] ?? '') : $current); ?></textarea>
                </div>

            
            <?php elseif($question->questiontype_id==3): ?>

                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">

                    <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <div class="option-item border rounded-lg p-3">

                            <label class="flex items-center gap-3">

                                <input
                                    type="radio"
                                    class="option-radio"
                                    name="answers[<?php echo e($question->id); ?>]"
                                    value="<?php echo e($opsion->id); ?>"
                                    data-has-child="<?php echo e($opsion->has_child); ?>"
                                    <?php echo e(($current['value'] ?? null) == $opsion->id ? 'checked' : ''); ?>>

                                <span>

                                    <?php echo e($opsion->answer_text); ?>


                                </span>

                            </label>

                            <div class="child-textarea hidden mt-3">

                                <?php if($opsion->answer_text2): ?>

                                    <div class="text-red-600 mb-2">

                                        <?php echo e($opsion->answer_text2); ?>


                                    </div>

                                <?php endif; ?>

                                <textarea
                                    class="border rounded p-2 w-full"
                                    name="child_answers[<?php echo e($question->id); ?>][<?php echo e($opsion->id); ?>]"><?php echo e($current['child'][$opsion->id] ?? ''); ?></textarea>

                            </div>

                        </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            
            <?php elseif($question->questiontype_id==4): ?>
                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">
                        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $opsion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="option-item border rounded-lg p-3">

                                <label class="flex items-center gap-3">

                                    <input
                                        type="checkbox"
                                        class="option-checkbox"
                                        name="answers[<?php echo e($question->id); ?>][]"
                                        value="<?php echo e($opsion->id); ?>"
                                        data-has-child="<?php echo e($opsion->has_child); ?>"
                                        <?php echo e(in_array($opsion->id, $current['value'] ?? []) ? 'checked' : ''); ?>>

                                    <span>

                                        <?php echo e($opsion->answer_text); ?>


                                    </span>

                                </label>

                                <div class="child-textarea hidden mt-3">

                                    <?php if($opsion->answer_text2): ?>

                                        <div class="text-red-600 mb-2">

                                            <?php echo e($opsion->answer_text2); ?>


                                        </div>

                                    <?php endif; ?>

                                    <textarea
                                        class="border rounded p-2 w-full"
                                        name="child_answers[<?php echo e($question->id); ?>][<?php echo e($opsion->id); ?>]"><?php echo e($current['child'][$opsion->id] ?? ''); ?></textarea>

                                </div>

                            </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            
            <?php elseif($question->questiontype_id==6): ?>
                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">
                    <input
                        type="number"
                        class="border rounded p-2 w-full"
                        name="answers[<?php echo e($question->id); ?>]"
                        value="<?php echo e($current['value'] ?? ''); ?>">
                </div>

            
            <?php elseif($question->questiontype_id==7): ?>
                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">
                    <input
                        type="date"
                        class="border rounded p-2 w-full"
                        name="answers[<?php echo e($question->id); ?>]"
                        value="<?php echo e($current['value'] ?? ''); ?>">
                </div>

            
            <?php elseif($question->questiontype_id==8): ?>
                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">
                    <input
                        type="email"
                        class="border rounded p-2 w-full"
                        name="answers[<?php echo e($question->id); ?>]"
                        value="<?php echo e($current['value'] ?? ''); ?>">
                </div>

            
            <?php elseif($question->questiontype_id==9): ?>
                <div class="question-block space-y-3 border border-transparent rounded-lg p-2">
                    <input
                        type="number"
                        class="border rounded p-2 w-full"
                        name="answers[<?php echo e($question->id); ?>]"
                        value="<?php echo e($current['value'] ?? ''); ?>">
                </div>

            <?php endif; ?>

        </div>

    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        // =========================
        // GUARD (ANTI DOUBLE INIT)
        // =========================
        if (window.__question_ui_initialized) return;
        window.__question_ui_initialized = true;

        // =========================
        // TAB SWITCH
        // =========================
        document.addEventListener('click', function (e) {

            const tabBtn = e.target.closest('[data-tab]');
            if (!tabBtn) return;

            const tab = tabBtn.dataset.tab;

            document.querySelectorAll('[data-content]').forEach(el => {
                el.classList.add('hidden');
            });

            const target = document.querySelector(`[data-content="${tab}"]`);
            if (target) target.classList.remove('hidden');
        });

        // =========================
        // ADD ROW (SAFE)
        // =========================
        document.addEventListener('click', function (e) {

            const btn = e.target.closest('.add-row-btn');
            if (!btn) return;

            const section = btn.closest('[data-section="manual-form"]');
            if (!section) return;

            const container = section.querySelector('.manual-rows');
            const firstRow = container?.querySelector('.row-item');

            if (!firstRow) return;

            const clone = firstRow.cloneNode(true);

            // reset value
            clone.querySelectorAll('input, textarea, select').forEach(el => {
                el.value = '';
            });

            container.appendChild(clone);
        });

        // =========================
        // REMOVE ROW (FIX INI YANG KAMU BUTUH)
        // =========================
        document.addEventListener('click', function (e) {

            const btn = e.target.closest('.remove-row');
            if (!btn) return;

            const section = btn.closest('[data-section="manual-form"]');
            if (!section) return;

            const container = section.querySelector('.manual-rows');
            const rows = container.querySelectorAll('.row-item');

            // minimal 1 row
            if (rows.length <= 1) {
                alert('Minimal harus ada 1 row');
                return;
            }

            const row = btn.closest('.row-item');
            if (row) row.remove();

            document.addEventListener('click', function (e) {

                if (e.target.id === 'addRow') {

                    const container = document.querySelector('#rows .question-wrapper');
                    if (!container) return;

                    const clone = container.cloneNode(true);

                    clone.querySelectorAll('input').forEach(el => el.value = '');

                    document.querySelector('#rows').appendChild(clone);
                }

            });
        });

        // =========================
        // RADIO + CHECKBOX CHILD
        // =========================
        document.addEventListener('change', function (e) {

            const block = e.target.closest('.question-block');
            if (!block) return;

            // =========================
            // RADIO
            // =========================
            if (e.target.classList.contains('option-radio')) {

                const all = block.querySelectorAll('.option-radio');

                all.forEach(r => {
                    const item = r.closest('.option-item');
                    const child = item?.querySelector('.child-textarea');

                    if (child) {
                        child.classList.add('hidden');

                        const textarea = child.querySelector("textarea");
                        if (textarea) {
                            textarea.value = "";
                        }
                    }
                });

                const current = e.target.closest('.option-item');
                const child = current?.querySelector('.child-textarea');

                if (e.target.checked && e.target.dataset.hasChild === "1") {
                    child?.classList.remove('hidden');
                }
            }

            if (e.target.classList.contains('option-checkbox')) {

                const item = e.target.closest('.option-item');
                const child = item?.querySelector('.child-textarea');

                if (!child) return;

                if (e.target.checked && e.target.dataset.hasChild === "1") {
                    child.classList.remove('hidden');
                } else {
                    child.classList.add('hidden');
                    const ta = child.querySelector('textarea');
                    if (ta) ta.value = '';
                }
            }

            if (e.target.classList.contains('has-child-select')) {

                const item = e.target.closest('.question-item');
                if (!item) return;

                const container = item.querySelector('.child-input-container');
                if (!container) return;

                if (e.target.value === "1") {
                    container.classList.remove('hidden');
                } else {
                    container.classList.add('hidden');

                    const input = container.querySelector('input');
                    if (input) input.value = '';
                }
            }

        });
        
        function initHasChildSelect(context = document) {
            context.querySelectorAll('.has-child-select').forEach(select => {
                const wrapper = select.closest('.question-item');
                if (!wrapper) return;

                const container = wrapper.querySelector('.child-input-container');
                if (!container) return;

                if (select.value === "1") {
                    container.classList.remove('hidden');
                } else {
                    container.classList.add('hidden');
                }
            });
        }

        // =========================
        // MODAL EVENT
        // =========================
        document.addEventListener('open-modal-tab', function (e) {

            setTimeout(() => {
                const input = document.querySelector('#form_id_input');
                if (input && e.detail.form) {
                    input.value = e.detail.form;
                }
            }, 100);

        });

        function toggleChild(select) {
            const wrapper = select.closest('.question-item');
            const container = wrapper.querySelector('.child-input-container');

            if (select.value === "1") {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        }
    });
    // ==========================
    // VALIDASI SEBELUM SUBMIT
    // ==========================
    const form = document.getElementById("surveyForm");
    console.log(form);

    if(form){
        form.addEventListener("submit", function(e){

            let valid = true;
            let firstError = null;
            // =====================
            // TEXT, NUMBER, DATE, EMAIL
            // =====================
            form.querySelectorAll(
                'input[type="text"],input[type="number"],input[type="date"],input[type="email"]'
            ).forEach(input=>{
                if(input.value.trim()===""){
                    valid=false;
                    input.classList.add("border-red-500");
                        setQuestionError(input);
                    if(!firstError){
                        firstError=input;
                    }
                }else{
                    input.classList.remove("border-red-500");
                        clearQuestionError(input);
                }
            });
            // =====================
            // TEXTAREA BIASA
            // =====================
            form.querySelectorAll("textarea").forEach(textarea=>{
                // textarea child dicek terpisah
                if(textarea.closest(".child-textarea")){
                    return;
                }
                if(textarea.value.trim()===""){
                    valid=false;
                    textarea.classList.add("border-red-500");
                        setQuestionError(textarea);
                    if(!firstError){
                        firstError=textarea;
                    }
                }else{
                    textarea.classList.remove("border-red-500");
                }
            });
            // =====================
            // RADIO
            // =====================
            const radios={};
            form.querySelectorAll(".option-radio").forEach(r=>{
                if(!(r.name in radios)){
                    radios[r.name]=false;
                }
                if(r.checked){
                    radios[r.name]=true;
                }
            });
            Object.keys(radios).forEach(name=>{

                const radio = form.querySelector(`[name="${CSS.escape(name)}"]`);

                if(!radios[name]){

                    valid = false;

                    setQuestionError(radio);

                    if(!firstError){
                        firstError = radio;
                    }

                }else{

                    clearQuestionError(radio);

                }

            });
            // =====================
            // CHECKBOX
            // =====================
            const checkboxGroup={};
            form.querySelectorAll(".question-block").forEach(block => {
                const checkboxes = block.querySelectorAll(".option-checkbox");

                if (!checkboxes.length) {
                    return;
                }

                const checked = [...checkboxes].some(c => c.checked);

                if (!checked) {

                    valid = false;

                    setQuestionError(checkboxes[0]);

                    if (!firstError) {
                        firstError = checkboxes[0];
                    }

                } else {

                    clearQuestionError(checkboxes[0]);

                }

            });
            Object.keys(checkboxGroup).forEach(name=>{
                const checkbox = form.querySelector(`[name="${CSS.escape(name)}"]`);
                if(!checkboxGroup[name]){
                    valid = false;
                    setQuestionError(checkbox);
                    if(!firstError){
                        firstError = checkbox;
                    }
                }else{
                    clearQuestionError(checkbox);
                }
            });
            // Child Text Area
            form.querySelectorAll(".option-radio:checked").forEach(radio => {
                    const child = radio
                        .closest(".option-item")
                        .querySelector(".child-textarea");
                    // Kalau child tidak tampil, abaikan
                    if (!child || child.classList.contains("hidden")) {
                        return;
                    }
                    const textarea = child.querySelector("textarea");
                    if (textarea && textarea.value.trim() === "") {
                        valid = false;
                        textarea.classList.add("border-red-500");
                        setQuestionError(textarea);
                        if (!firstError) {
                            firstError = textarea;
                        }
                    }
                });
            form.querySelectorAll(".option-checkbox:checked").forEach(check => {

                    const child = check
                        .closest(".option-item")
                        .querySelector(".child-textarea");

                    if (!child || child.classList.contains("hidden")) {
                        return;
                    }

                    const textarea = child.querySelector("textarea");

                    if (textarea && textarea.value.trim() === "") {

                        valid = false;

                        textarea.classList.add("border-red-500");
                        setQuestionError(textarea);

                        if (!firstError) {
                            firstError = textarea;
                        }
                    }

                });
            // Validasi Data Belum Terisi
            if(!valid){

             e.preventDefault();
                alert("Masih ada pertanyaan yang belum diisi.");
                firstError.scrollIntoView({
                    behavior:"smooth",
                    block:"center"
                });
                firstError.focus();
            }
        });
    }

    document.querySelectorAll('.option-radio:checked').forEach(radio => {
        if (radio.dataset.hasChild === "1") {
            radio.closest('.option-item')
                .querySelector('.child-textarea')
                ?.classList.remove('hidden');
        }
    });

    document.querySelectorAll('.option-checkbox:checked').forEach(check => {
        if (check.dataset.hasChild === "1") {
            check.closest('.option-item')
            .querySelector('.child-textarea')
            ?.classList.remove('hidden');
        }
    });

    function setQuestionError(element, error = true) {

        const card = element.closest(".question-card");
        const block = element.closest(".question-block");

        if (card) {
            card.classList.toggle("border-red-500", error);
            card.classList.toggle("bg-red-50", error);
        }

        if (block) {
            block.classList.toggle("border-red-500", error);
            block.classList.toggle("bg-red-50", error);
        }
    }

    function clearQuestionError(element) {
        setQuestionError(element, false);
    }

    document.addEventListener("input", function(e){
        if(
            e.target.matches("input") ||
            e.target.matches("textarea")
        ){
            if(e.target.value.trim() !== ""){
                e.target.classList.remove("border-red-500");
                clearQuestionError(e.target);
            }
        }
    });

    document.addEventListener("change", function(e){

        if (!e.target.classList.contains("option-checkbox")) {
            return;
        }

        const block = e.target.closest(".question-block");

        const checked = [...block.querySelectorAll(".option-checkbox")]
            .some(c => c.checked);

        if (checked) {
            clearQuestionError(e.target);
        } else {
            setQuestionError(e.target);
        }

    });
</script>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/show/kuesioner_umum.blade.php ENDPATH**/ ?>