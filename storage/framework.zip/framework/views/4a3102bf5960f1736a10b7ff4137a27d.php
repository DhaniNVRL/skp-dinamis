<div class="flex flex-col gap-3 rounded-lg border border-gray-200 bg-white px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
    <p class="text-sm text-gray-500">Total <?php echo e($activities->count()); ?> Activity</p>

    <?php if($activities instanceof \Illuminate\Pagination\AbstractPaginator): ?>
        <div><?php echo e($activities->links()); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/activities/partials/pagination.blade.php ENDPATH**/ ?>