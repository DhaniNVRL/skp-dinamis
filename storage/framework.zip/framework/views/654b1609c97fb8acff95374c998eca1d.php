<?php $__env->startSection('title', $form->name ?? 'Survei'); ?>

<?php $__env->startSection('content'); ?>
<div id="surveyPage" class="mx-auto max-w-[1600px] space-y-6">
    <?php echo $__env->make('user.survey.partials.form-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if($errors->any()): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 p-4 text-sm text-red-700">
            <p class="font-semibold">Semua pertanyaan wajib diisi.</p>
            <ul class="mt-2 list-disc space-y-1 pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form
        id="surveyAnswerForm"
        action="<?php echo e(route('survey.save', $form)); ?>"
        method="POST"
        novalidate
        class="space-y-6"
    >
        <?php echo csrf_field(); ?>

        <div class="space-y-6">

    
    <?php if(
        (int) $form->formtype_id !== 12 &&
        $form->description
    ): ?>
        <?php
            $descriptionContent =
                $form->description->content
                ?? $form->description->description
                ?? $form->description->text
                ?? null;
        ?>

        <?php if($descriptionContent): ?>
            <div
                class="overflow-hidden rounded-xl border
                       border-indigo-200 bg-white shadow-sm"
            >
                <div
                    class="flex items-center gap-3 border-b
                           border-indigo-200 bg-indigo-50 px-6 py-4"
                >
                    <span
                        class="inline-flex h-10 w-10 items-center
                               justify-center rounded-lg bg-indigo-100
                               text-indigo-600"
                    >
                        <i class="fa-solid fa-circle-info"></i>
                    </span>

                    <div>
                        <h2 class="font-semibold text-gray-900">
                            Petunjuk Pengisian
                        </h2>

                        <p class="text-sm text-gray-500">
                            Bacalah petunjuk sebelum mengisi pertanyaan.
                        </p>
                    </div>
                </div>

                <article
                    class="prose max-w-none px-6 py-5 text-gray-700"
                >
                    <?php echo $descriptionContent; ?>

                </article>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    
    <div
        class="rounded-xl border border-gray-200
               bg-white p-5 shadow-sm md:p-7"
            >
                <?php switch((int) $form->formtype_id):

                    case (1): ?>
                        <?php echo $__env->make('user.survey.forms.general-questionnaire', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (2): ?>
                        <?php echo $__env->make('user.survey.forms.customer-assessment-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (3): ?>
                        <?php echo $__env->make('user.survey.forms.customer-assessment-1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (4): ?>
                        <?php echo $__env->make('user.survey.forms.engagement-assessment-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (5): ?>
                        <?php echo $__env->make('user.survey.forms.engagement-assessment-1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (6): ?>
                        <?php echo $__env->make('user.survey.forms.ranking-1-3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (7): ?>
                        <?php echo $__env->make('user.survey.forms.ranking-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (8): ?>
                        <?php echo $__env->make('user.survey.forms.strength-complaint-suggestion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (9): ?>
                        <?php echo $__env->make('user.survey.forms.complaint-suggestion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (10): ?>
                        <?php echo $__env->make('user.survey.forms.suggestion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (11): ?>
                        <?php echo $__env->make('user.survey.forms.competitor-assessment-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (12): ?>
                        <?php echo $__env->make('user.survey.forms.description', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php case (13): ?>
                        <?php echo $__env->make('user.survey.forms.competitor-assessment-1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php break; ?>

                    <?php default: ?>
                        <?php echo $__env->make('user.survey.partials.empty', [
                            'message' => 'Jenis form belum didukung.',
                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                <?php endswitch; ?>
            </div>
        </div>

        <?php echo $__env->make('user.survey.partials.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo app('Illuminate\Foundation\Vite')('resources/js/user/survey.js'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/index.blade.php ENDPATH**/ ?>