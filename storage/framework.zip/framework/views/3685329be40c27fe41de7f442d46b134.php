<?php switch((int) $question->questiontype_id):

    case (1): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.text',
            ['question' => $question]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>


    <?php case (2): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.textarea',
            ['question' => $question]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>


    <?php case (3): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.radio',
            ['question' => $question]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>


    <?php case (4): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.checkbox',
            ['question' => $question]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>

    <?php case (5): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.dropdown',
            [
                'question' => $question
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>

    <?php case (6): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.number',
            ['question' => $question]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>
    
    <?php case (7): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.date',
            [
                'question' => $question
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>


    <?php case (8): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.email',
            [
                'question' => $question
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>


    <?php case (9): ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.phone',
            ['question' => $question]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php break; ?>


    <?php default: ?>

        <div
            class="rounded-xl border border-amber-200
                   bg-amber-50 px-4 py-3"
        >
            <div class="flex items-center gap-2 text-sm text-amber-700">

                <i class="fa-solid fa-triangle-exclamation"></i>

                <span>
                    Tampilan untuk tipe pertanyaan
                    <strong>#<?php echo e($question->questiontype_id); ?></strong>
                    belum tersedia.
                </span>

            </div>
        </div>

<?php endswitch; ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/general-questionnaire/question-body.blade.php ENDPATH**/ ?>