<div class="rounded-lg border border-gray-200 bg-white p-6 shadow-sm">
    <div class="flex flex-col justify-between gap-4 lg:flex-row lg:items-center">
        <div>
            <a
                href="<?php echo e(url()->previous()); ?>"
                class="mb-3 inline-flex items-center gap-2 text-sm font-medium text-blue-600 transition hover:text-blue-800"
            >
                <i class="fa-solid fa-arrow-left"></i>
                Kembali
            </a>

            <h1 class="text-2xl font-bold text-gray-800">
                Sub Unit
            </h1>

            <p class="mt-1 text-sm text-gray-500">
                Pengaturan Sub Unit dari Unit
                <span class="font-semibold text-gray-700">
                    <?php echo e($units->name); ?>

                </span>
            </p>
        </div>

        <div class="flex flex-wrap items-center gap-3">
            <?php if($units->group ?? null): ?>
                <div class="rounded-lg bg-indigo-50 px-4 py-3">
                    <div class="text-xs font-semibold uppercase tracking-wide text-indigo-500">
                        Group
                    </div>

                    <div class="mt-1 font-semibold text-indigo-700">
                        <?php echo e($units->group->name); ?>

                    </div>
                </div>
            <?php endif; ?>

            <div class="rounded-lg bg-blue-50 px-4 py-3">
                <div class="text-xs font-semibold uppercase tracking-wide text-blue-500">
                    Jumlah Sub Unit
                </div>

                <div class="mt-1 text-xl font-bold text-blue-700">
                    <?php echo e($subunits->total()); ?>

                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/page-header.blade.php ENDPATH**/ ?>