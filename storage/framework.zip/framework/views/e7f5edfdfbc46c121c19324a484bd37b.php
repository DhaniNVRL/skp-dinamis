<footer class="fixed bottom-0 left-0 right-0 h-12 bg-blue-700 text-white flex items-center justify-center text-sm z-50">
    &copy; <?php echo e(date('Y')); ?> PT Sucofindo - SBU Sertifikasi dan Eco-Framework. All Rights Reserved.
</footer><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>