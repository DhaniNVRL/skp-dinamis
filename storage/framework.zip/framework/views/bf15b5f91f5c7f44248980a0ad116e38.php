<header class="fixed top-0 left-0 right-0 h-16 bg-blue-700 text-white px-6 flex justify-between items-center z-50">
    <div class="flex items-center space-x-3 h-20">
        <img src="<?php echo e(asset('images/logo4.png')); ?>" style="height: 70%;" class="object-contain" alt="">
    </div>

    <!-- User -->
    <div x-data="{ open: false }" class="relative">
        <button @click="open = !open" class="flex items-center space-x-2 focus:outline-none">
            <span><?php echo e(Auth::user()->name ?? 'User'); ?></span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
            </svg>
        </button>

        <div
            x-show="open"
            @click.away="open = false"
            x-transition
            class="absolute right-0 mt-2 w-40 bg-white text-gray-800 rounded shadow-lg z-50"
            style="display: none;">
            <a href="" class="block px-4 py-2 hover:bg-gray-100">Edit Profile</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="w-full text-left px-4 py-2 hover:bg-gray-100">Logout</button>
            </form>
        </div>
    </div>

</header><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>