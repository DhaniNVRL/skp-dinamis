<div class="flex items-center justify-center gap-3">
    
    <button
        type="button"
        data-modal-open="editSubUnitModal"
        data-id="<?php echo e($subunit->id); ?>"
        data-name="<?php echo e($subunit->name); ?>"
        data-action="<?php echo e(route('subunits.update', [
            'id' => $subunit->id,
        ])); ?>"
        class="text-amber-500 transition hover:text-amber-700"
        title="Edit Sub Unit"
    >
        <i class="fa-solid fa-pen"></i>
    </button>

    
    <button
        type="button"
        data-modal-open="deleteSubUnitModal"
        data-id="<?php echo e($subunit->id); ?>"
        data-name="<?php echo e($subunit->name); ?>"
        data-action="<?php echo e(route('subunits.destroy', [
            'id' => $subunit->id,
        ])); ?>"
        class="text-red-500 transition hover:text-red-700"
        title="Hapus Sub Unit"
    >
        <i class="fa-solid fa-trash"></i>
    </button>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/partials/row-action.blade.php ENDPATH**/ ?>