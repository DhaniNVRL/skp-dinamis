

<?php $__env->startSection('title', 'Monitoring Survey'); ?>

<?php $__env->startSection('content'); ?>
<div id="monitoringDashboard" class="mx-auto max-w-[1600px] space-y-6">
    <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div class="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
            <div>
                <h1 class="text-2xl font-bold text-gray-900">Monitoring Kegiatan Survey</h1>
                <p class="mt-1 text-sm text-gray-500">Pantau status pengisian survey seluruh responden.</p>
            </div>

            <div class="flex items-center gap-3 rounded-xl bg-indigo-50 px-5 py-4">
                <div class="flex h-10 w-10 items-center justify-center rounded-lg bg-indigo-100 text-indigo-600">
                    <i class="fa-solid fa-user-shield"></i>
                </div>
                <div>
                    <p class="text-xs font-medium uppercase tracking-wide text-indigo-500">Login Sebagai</p>
                    <p class="font-semibold text-indigo-700"><?php echo e(auth()->user()->role?->name ?? 'Administrator'); ?></p>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.dashboard.partials.filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.dashboard.partials.cards', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="flex flex-col gap-2 border-b border-gray-200 bg-gray-50 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="font-semibold text-gray-900">Daftar Responden</h2>
                <p class="text-sm text-gray-500">Klik detail untuk melihat profil dan jawaban responden.</p>
            </div>
            <span class="text-sm text-gray-500"><?php echo e($respondents->total()); ?> responden ditemukan</span>
        </div>

        <?php echo $__env->make('admin.dashboard.partials.respondent-table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="border-t border-gray-200 px-5 py-4">
            <?php echo e($respondents->links()); ?>

        </div>
    </div>
</div>

<?php echo $__env->make('admin.dashboard.modals.respondent-detail', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>