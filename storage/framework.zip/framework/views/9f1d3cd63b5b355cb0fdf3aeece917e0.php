<?php ($progress = $totalForms > 0 ? min(100, ($currentPosition / $totalForms) * 100) : 0); ?>
<div class="px-6 py-4">
    <div class="mb-2 flex justify-between text-xs text-gray-600">
        <span>Progress survei</span>
        <span><?php echo e($currentPosition); ?> dari <?php echo e($totalForms); ?></span>
    </div>
    <div class="h-2 overflow-hidden rounded-full bg-gray-200">
        <div class="h-full rounded-full bg-indigo-600 transition-all" style="width: <?php echo e($progress); ?>%"></div>
    </div>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/partials/progress.blade.php ENDPATH**/ ?>