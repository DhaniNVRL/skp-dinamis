<?php $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noHeader => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    
    <?php $__currentLoopData = $group->where('questiontype_id', 1)->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="mb-6 p-4 border rounded-lg shadow-sm bg-blue-100">
            <div class="flex items-center justify-between">

                <div class="flex-1 text-center font-bold text-lg text-gray-800">
                    <?php echo e($question->name); ?>

                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    
    <?php
        $tableQuestions = $group->where('questiontype_id', 2)->sortBy('no');
    ?>

    <?php if($tableQuestions->count()): ?>
        <table class="table table-bordered w-full mb-6 border-collapse">
            <thead>
                <tr class="bg-gray-100">

                    <th class="text-left p-2 w-1/3">
                        Pertanyaan
                    </th>

                    <?php $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="text-center p-2">
                            <label class="font-semibold text-gray-700">
                                    <?php echo e($competitor->name); ?>

                            </label>
                        </th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tr>
            </thead>

            <tbody>

                <?php $__currentLoopData = $tableQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-t">

                        
                        <td class="question-card p-2 align-top border-l-4 border-transparent">
                            <div class="flex justify-between items-start gap-2">
                                <label class="font-semibold text-gray-700">
                                    <?php echo e($question->no_header); ?><?php echo e($question->no); ?>. <?php echo e($question->name); ?>

                                </label>
                            </div>
                        </td>

                        
                        <?php $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $answerKey = $question->id.'-0-'.$competitor->id;
                                $current = $answerMap->get($answerKey, []);
                            ?>
                            <td class="question-card p-2 align-top border-l-4 border-transparent">
                                <div class="flex justify-center gap-1 flex-wrap">
                                    <?php $__currentLoopData = ((int) $form->formtype_id === 13 ? [1,2,3,4,5,6,7,0] : [1,2,3,4,5,0]); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label class="cursor-pointer">

                                            <input type="radio"
                                                name="answers[<?php echo e($question->id); ?>][<?php echo e($competitor->id); ?>]"
                                                value="<?php echo e($value); ?>"
                                                class="score-radio peer hidden">

                                            <div class="w-8 h-8 flex items-center justify-center rounded-full
                                                        border border-gray-300 text-xs
                                                        peer-checked:bg-blue-600 peer-checked:text-white
                                                        peer-checked:border-blue-600
                                                        hover:bg-blue-100 transition">
                                                <?php echo e($value); ?>

                                            </div>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("surveyForm");

    if (!form) return;

    //---------------------------------------------------
    // VALIDASI 1 BARIS
    //---------------------------------------------------

    function validateCard(card){

        let hasError = false;

        const groups = {};

        card.querySelectorAll(".score-radio").forEach(radio=>{

            if(!(radio.name in groups)){
                groups[radio.name] = false;
            }

            if(radio.checked){
                groups[radio.name] = true;
            }

        });

        Object.values(groups).forEach(value=>{

            if(!value){
                hasError = true;
            }

        });

        card.classList.toggle("border-red-500", hasError);
        card.classList.toggle("bg-red-50", hasError);

    }

    //---------------------------------------------------
    // SUBMIT
    //---------------------------------------------------

    form.addEventListener("submit",function(e){

        let valid = true;

        let firstError = null;

        document.querySelectorAll(".question-card").forEach(card=>{

            validateCard(card);

            const groups = {};

            card.querySelectorAll(".score-radio").forEach(radio=>{

                if(!(radio.name in groups)){
                    groups[radio.name]=false;
                }

                if(radio.checked){
                    groups[radio.name]=true;
                }

            });

            Object.keys(groups).forEach(name=>{

                if(!groups[name]){

                    valid=false;

                    const radio = card.querySelector(`[name="${CSS.escape(name)}"]`);

                    if(!firstError){
                        firstError = radio;
                    }

                }

            });

        });

        if(!valid){

            e.preventDefault();

            alert("Masih ada data yang belum diisi.");

            firstError.scrollIntoView({

                behavior:"smooth",

                block:"center"

            });

            firstError.focus();

        }

    });

    //---------------------------------------------------
    // RADIO CHANGE
    //---------------------------------------------------

    document.addEventListener("change",function(e){

        if(!e.target.classList.contains("score-radio")) return;

        validateCard(

            e.target.closest(".question-card")

        );

    });

});
</script>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/show/kompetitor.blade.php ENDPATH**/ ?>