<div
    id="unitPage"
    class="space-y-4"
    data-group-id="<?php echo e($groups->id); ?>"
>
    
    <?php if(session('success')): ?>
        <div
            class="rounded-lg border border-green-200
                bg-green-50 px-4 py-3 text-sm text-green-700"
        >
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('successdelete')): ?>
        <div
            class="rounded-lg border border-green-200
                bg-green-50 px-4 py-3 text-sm text-green-700"
        >
            <?php echo e(session('successdelete')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div
            class="rounded-lg border border-red-200
                bg-red-50 px-4 py-3 text-sm text-red-700"
        >
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div
            class="rounded-lg border border-red-200
                bg-red-50 px-4 py-3 text-sm text-red-700"
        >
            <ul class="list-disc space-y-1 pl-5">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php echo $__env->make('admin.units.units.partials.toolbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.units.partials.filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.units.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/pages/units-data.blade.php ENDPATH**/ ?>