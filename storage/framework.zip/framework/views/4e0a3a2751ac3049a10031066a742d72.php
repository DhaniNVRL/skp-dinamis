<div class="mb-5">
    <div class="flex items-start gap-3">
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.partials.question-number',
            [
                'question' => $question,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="min-w-0">
            <h3 class="font-semibold text-gray-800">
                <?php echo e($question->name); ?>

            </h3>

            <?php if(!empty($typeLabel)): ?>
                <p class="mt-1 text-xs text-gray-500">
                    <?php echo e($typeLabel); ?>

                </p>
            <?php endif; ?>
        </div>
    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/forms/partials/customer-question-header.blade.php ENDPATH**/ ?>