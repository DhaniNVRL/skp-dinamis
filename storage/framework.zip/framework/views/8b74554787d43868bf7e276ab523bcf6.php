<div class="mb-6 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">

    <div class="flex items-start justify-between gap-4 border-b border-gray-200 px-5 py-4">

        <div class="flex min-w-0 items-start gap-3">
            <span
                class="inline-flex min-w-10 shrink-0 items-center justify-center
                       rounded-lg bg-violet-100 px-2.5 py-1
                       text-sm font-semibold text-violet-700"
            >
                <?php echo e($question->no_header); ?><?php echo e($question->no); ?>

            </span>

            <div>
                <h4 class="font-semibold leading-6 text-gray-800">
                    <?php echo e($question->name); ?>

                </h4>

                <p class="mt-1 text-xs text-gray-500">
                    Penilaian satu indikator
                </p>
            </div>
        </div>

        <div class="flex shrink-0 items-center gap-2">
            <?php echo $__env->make(
                'admin.units.question.partials.forms.question-action',
                [
                    'question' => $question,
                    'form' => $form,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>

    </div>

    <div class="p-5">

        <div class="rounded-xl border border-violet-200 bg-violet-50/50 p-4">
            <div class="flex flex-wrap justify-center gap-3">

                <?php $__currentLoopData = [1, 2, 3, 4, 5]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label
                        class="inline-flex h-10 w-10 items-center justify-center
                               rounded-full border border-violet-300 bg-white
                               text-sm font-semibold text-violet-700"
                    >
                        <input
                            type="radio"
                            name="preview_indikator_<?php echo e($question->id); ?>"
                            value="<?php echo e($value); ?>"
                            class="sr-only"
                            disabled
                        >

                        <?php echo e($value); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>

    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/engagement-assessment-1-5/options/single-indicator.blade.php ENDPATH**/ ?>