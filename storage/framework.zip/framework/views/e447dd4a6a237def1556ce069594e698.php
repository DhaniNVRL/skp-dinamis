<button
    type="button"
    data-hide-show-toggle
    data-form-id="<?php echo e($formId); ?>"
    data-question-id="<?php echo e($questionId); ?>"
    data-subunit-ids='<?php echo json_encode(array_values($subunitIds), 15, 512) ?>'
    data-active="<?php echo e($isActive ? '1' : '0'); ?>"
    aria-pressed="<?php echo e($isActive ? 'true' : 'false'); ?>"
    class="relative inline-flex h-7 w-12 shrink-0 items-center rounded-full transition
        <?php echo e($isActive ? 'bg-green-500' : 'bg-gray-300'); ?>"
>
    <span
        data-toggle-knob
        class="inline-block h-5 w-5 rounded-full bg-white shadow transition-transform
            <?php echo e($isActive ? 'translate-x-6' : 'translate-x-1'); ?>"
    ></span>

    <span class="sr-only">
        Ubah status pertanyaan
    </span>
</button><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/hide-and-show/partials/toggle-button.blade.php ENDPATH**/ ?>