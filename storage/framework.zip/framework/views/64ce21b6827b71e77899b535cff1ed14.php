<div class="flex items-center justify-center gap-3">
    <button
        type="button"
        data-modal-open="editUserModal"
        data-id="<?php echo e($profile->user->id); ?>"
        data-username="<?php echo e($profile->user->username); ?>"
        data-role="<?php echo e($profile->user->role_id); ?>"
        data-activity="<?php echo e($profile->activity_id); ?>"
        data-action="<?php echo e(route('admin.datauser.update', $profile->user->id)); ?>"
        class="text-amber-500 transition hover:text-amber-700"
        title="Edit User"
    >
        <i class="fa-solid fa-pen-to-square"></i>
    </button>

    <a href="<?php echo e(route('admin.datauser.editpassword', $profile->user->id)); ?>" class="text-indigo-600 transition hover:text-indigo-800" title="Ubah Password">
        <i class="fa-solid fa-key"></i>
    </a>

    <button
        type="button"
        data-modal-open="deleteModal"
        data-id="<?php echo e($profile->user->id); ?>"
        data-name="<?php echo e($profile->fullname ?: $profile->user->username); ?>"
        class="text-red-600 transition hover:text-red-800"
        title="Hapus User"
    >
        <i class="fa-solid fa-trash"></i>
    </button>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/users/partials/row-action.blade.php ENDPATH**/ ?>