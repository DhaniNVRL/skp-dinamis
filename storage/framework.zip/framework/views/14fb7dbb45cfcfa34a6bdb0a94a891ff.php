<div
    class="group rounded-xl border border-gray-200
           bg-white px-4 py-3
           transition hover:border-indigo-200 hover:shadow-sm"
>

    <div class="flex items-center gap-3">

        
        <div class="flex shrink-0 items-center">

            <?php if($inputType === 'radio'): ?>

                <span
                    class="flex h-5 w-5 items-center justify-center
                           rounded-full border-2 border-gray-300
                           bg-white"
                >
                    <span class="h-2 w-2 rounded-full bg-transparent"></span>
                </span>

            <?php elseif($inputType === 'checkbox'): ?>

                <span
                    class="flex h-5 w-5 items-center justify-center
                        rounded-md border-2 border-gray-300 bg-white"
                ></span>

            <?php elseif($inputType === 'dropdown'): ?>

                <span
                    class="flex h-6 min-w-6 items-center justify-center
                        rounded-md bg-cyan-50 px-1.5
                        text-xs font-semibold text-cyan-700"
                >
                    <?php echo e($loop->iteration ?? $option->no); ?>

                </span>

            <?php endif; ?>

        </div>


        
        <div class="min-w-0 flex-1">

            <div class="flex items-center gap-2">

                <?php if(!empty($option->no)): ?>

                    <span
                        class="inline-flex h-6 min-w-6 items-center
                               justify-center rounded-md bg-gray-100
                               px-1.5 text-xs font-semibold text-gray-600"
                    >
                        <?php echo e($option->no); ?>

                    </span>

                <?php endif; ?>

                <p class="break-words text-sm font-medium text-gray-700">
                    <?php echo e($option->answer_text); ?>

                </p>

            </div>


            <?php if(!empty($option->answer_text2)): ?>

                <p class="mt-1 text-xs text-gray-500">
                    <?php echo e($option->answer_text2); ?>

                </p>

            <?php endif; ?>

        </div>


        
        <?php if((int) ($option->has_child ?? 0) === 1): ?>

            <span
                class="hidden shrink-0 items-center gap-1
                       rounded-full bg-emerald-50 px-2.5 py-1
                       text-xs font-medium text-emerald-700
                       sm:inline-flex"
            >
                <i class="fa-solid fa-turn-down text-[10px]"></i>
                Jawaban lanjutan
            </span>

        <?php endif; ?>


        
        <div
            class="flex shrink-0 items-center gap-1
                   opacity-100 transition sm:opacity-0
                   sm:group-hover:opacity-100"
        >

            <button
                type="button"
                data-modal-open="editOptionModal"
                data-id="<?php echo e($option->id); ?>"
                data-question-id="<?php echo e($question->id); ?>"
                data-no="<?php echo e($option->no); ?>"
                data-answer-text="<?php echo e($option->answer_text); ?>"
                data-answer-text2="<?php echo e($option->answer_text2 ?? ''); ?>"
                data-has-child="<?php echo e((int) $option->has_child); ?>"
                data-action="<?php echo e(route('options.update', ['id' => $option->id])); ?>"
                class="flex h-8 w-8 items-center justify-center
                    rounded-lg bg-amber-50 text-amber-600
                    transition hover:bg-amber-100"
                title="Edit option"
            >
                <i class="fa-solid fa-pen text-xs"></i>
            </button>

            <button
                type="button"
                data-modal-open="deleteOptionModal"
                data-id="<?php echo e($option->id); ?>"
                data-name="<?php echo e($option->answer_text); ?>"
                data-action="<?php echo e(route('options.destroy', ['id' => $option->id])); ?>"
                class="flex h-8 w-8 items-center justify-center
                       rounded-lg bg-red-50 text-red-600
                       transition hover:bg-red-100"
                title="Hapus option"
            >
                <i class="fa-solid fa-trash text-xs"></i>
            </button>

        </div>

    </div>


    
    <?php if((int) ($option->has_child ?? 0) === 1): ?>

        <div class="ml-8 mt-3 border-t border-gray-100 pt-3">

            <div class="relative">

                <div
                    class="pointer-events-none absolute inset-y-0 left-0
                           flex items-center pl-3.5 text-gray-400"
                >
                    <i class="fa-regular fa-message text-xs"></i>
                </div>

                <input
                    type="text"
                    disabled
                    placeholder="<?php echo e($option->answer_text2 ?: 'Jawaban tambahan responden...'); ?>"
                    class="w-full rounded-lg border border-gray-200
                           bg-gray-50 py-2.5 pl-9 pr-3
                           text-sm text-gray-500
                           placeholder:text-gray-400"
                >

            </div>

        </div>

    <?php endif; ?>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/general-questionnaire/options/option-item.blade.php ENDPATH**/ ?>