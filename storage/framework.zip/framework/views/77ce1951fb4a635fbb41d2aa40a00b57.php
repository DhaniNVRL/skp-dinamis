<div class="flex shrink-0 items-center gap-2">

    
    <button
        type="button"
        data-modal-open="editCompetitorModal"
        data-id="<?php echo e($competitor->id); ?>"
        data-name="<?php echo e($competitor->name); ?>"
        data-group-id="<?php echo e($competitor->group_id); ?>"
        data-form-id="<?php echo e($competitor->form_id); ?>"
        data-action="<?php echo e(route('competitor.update', [
            'id' => $competitor->id,
        ])); ?>"
        class="inline-flex h-8 w-8 items-center justify-center
               rounded-lg bg-amber-100 text-amber-600
               transition hover:bg-amber-200"
        title="Edit kompetitor"
    >
        <i class="fa-solid fa-pen text-xs"></i>
    </button>

    
    <button
        type="button"
        data-modal-open="deleteCompetitorModal"
        data-id="<?php echo e($competitor->id); ?>"
        data-name="<?php echo e($competitor->name); ?>"
        data-group-id="<?php echo e($competitor->group_id); ?>"
        data-form-id="<?php echo e($competitor->form_id); ?>"
        data-action="<?php echo e(route('competitor.destroy', [
            'id' => $competitor->id,
        ])); ?>"
        class="inline-flex h-8 w-8 items-center justify-center
               rounded-lg bg-red-100 text-red-600
               transition hover:bg-red-200"
        title="Hapus kompetitor"
    >
        <i class="fa-solid fa-trash text-xs"></i>
    </button>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/competitor-1-7/options/competitor-action.blade.php ENDPATH**/ ?>