<div class="space-y-5">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $group->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionTypeId = (int) (
                    $question->questiontype_id
                    ?? $question->id_questiontypes
                    ?? 0
                );
            ?>

            
            <?php if($questionTypeId === 1): ?>
                <div class="rounded-lg border border-indigo-200 bg-indigo-50 p-4">
                    <div class="flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Judul Pertanyaan
                            </p>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                
                <div
                    data-ranking-question
                    data-question-id="<?php echo e($question->id); ?>"
                    class="rounded-lg border border-gray-200 bg-white p-5"
                >
                    <div class="mb-5 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-medium text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Pilih urutan ranking 1 sampai 5.
                            </p>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-5">
                        <?php for($rank = 1; $rank <= 5; $rank++): ?>
                            <?php echo $__env->make(
                                'admin.subunit.show-question.partials.ranking-select',
                                [
                                    'question' => $question,
                                    'label' => 'Ranking ' . $rank,
                                    'name' => "ranking_{$question->id}_{$rank}",
                                    'rank' => $rank,
                                ]
                            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        <?php endfor; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.partials.empty'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/forms/ranking-1-5.blade.php ENDPATH**/ ?>