<template id="strengthComplaintSuggestionTypeOptions">

    <option
        value="1"
        data-description="Judul atau pemisah kelompok pertanyaan."
    >
        Judul Pertanyaan
    </option>

    <option
        value="2"
        data-description="Pertanyaan dengan tiga jawaban: Keunggulan, Keluhan, dan Saran."
    >
        Keunggulan, Keluhan, dan Saran
    </option>

</template><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/templates/forms/strength-complaint-suggestion.blade.php ENDPATH**/ ?>