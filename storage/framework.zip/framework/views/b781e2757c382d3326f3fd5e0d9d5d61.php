<div class="space-y-5">
    <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php if((int) $question->questiontype_id === 1): ?>
            <div class="rounded-xl border border-indigo-200 bg-indigo-50 p-4 font-semibold text-indigo-900">
                <?php echo e($question->name); ?>

            </div>
        <?php else: ?>
            <div class="rounded-xl border border-gray-200 bg-white p-5">
                <div class="mb-4 flex items-start gap-3">
                    <?php echo $__env->make('user.survey.partials.question-number', compact('question'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    <label for="answer-<?php echo e($question->id); ?>" class="font-semibold text-gray-800"><?php echo e($question->name); ?></label>
                </div>
                <textarea id="answer-<?php echo e($question->id); ?>" name="answers[<?php echo e($question->id); ?>][value]" rows="3" required class="w-full rounded-lg border border-gray-300 px-4 py-3 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100" placeholder="Tulis jawaban..."><?php echo e(old("answers.{$question->id}.value", data_get($answerMap, $question->id.'.0.0.value'))); ?></textarea>
                <p data-field-error class="mt-2 hidden text-sm text-red-600">Pertanyaan ini wajib diisi.</p>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make('user.survey.partials.empty', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/partials/global-fields.blade.php ENDPATH**/ ?>