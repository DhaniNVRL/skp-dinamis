<span class="inline-flex h-8 min-w-8 shrink-0 items-center justify-center rounded-lg bg-indigo-100 px-2 text-sm font-semibold text-indigo-700">
    <?php echo e($question->no_header); ?><?php echo e($question->no); ?>

</span>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/partials/question-number.blade.php ENDPATH**/ ?>