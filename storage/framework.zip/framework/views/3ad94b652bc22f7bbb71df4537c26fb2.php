<div class="space-y-5">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $group->filter(function ($question) {
                return (int) (
                    $question->questiontype_id
                    ?? $question->id_questiontypes
                    ?? 0
                ) === 1;
            })->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="rounded-lg border border-indigo-200 bg-indigo-50 p-4">
                <div class="flex items-start gap-3">
                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.question-number',
                        compact('question')
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <h3 class="font-semibold text-gray-800">
                        <?php echo e($question->name); ?>

                    </h3>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php
            $tableQuestions = $group
                ->filter(function ($question) {
                    return (int) (
                        $question->questiontype_id
                        ?? $question->id_questiontypes
                        ?? 0
                    ) === 2;
                })
                ->sortBy('no');
        ?>

        <?php if($tableQuestions->isNotEmpty()): ?>
            <div class="overflow-x-auto rounded-lg border border-gray-200 bg-white">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="min-w-72 px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">
                                Pertanyaan
                            </th>

                            <?php $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="min-w-64 px-4 py-3 text-center text-xs font-semibold uppercase text-gray-600">
                                    <?php echo e($competitor->name); ?>

                                </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    </thead>

                    <tbody class="divide-y divide-gray-200">
                        <?php $__currentLoopData = $tableQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="px-4 py-4 align-top">
                                    <div class="flex items-start gap-3">
                                        <?php echo $__env->make(
                                            'admin.subunit.show-question.forms.partials.question-number',
                                            compact('question')
                                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                                        <span class="text-sm font-medium text-gray-700">
                                            <?php echo e($question->name); ?>

                                        </span>
                                    </div>
                                </td>

                                <?php $__currentLoopData = $competitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="px-4 py-4 text-center align-middle">
                                        <?php echo $__env->make(
                                            'admin.subunit.show-question.forms.partials.scale',
                                            [
                                                'question' => $question,
                                                'maximum' => 5,
                                                'name' => "competitor_{$question->id}_{$competitor->id}",
                                            ]
                                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make('admin.subunit.show-question.partials.empty', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/forms/description.blade.php ENDPATH**/ ?>