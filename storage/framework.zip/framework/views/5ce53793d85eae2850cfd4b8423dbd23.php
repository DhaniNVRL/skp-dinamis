<?php
    $scaleValues = array_merge(
        range(1, $maximumScale),
        [0]
    );
?>

<div class="space-y-6">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $questionGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $questionGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionTypeId =
                    (int) $question->questiontype_id;

                $questionNumber = trim(
                    ($question->no_header ?? '') .
                    ($question->no ?? '')
                );

                $activeSubunitIds = collect(
                    $activeMapSubUnit[
                        $form->id . '-' . $question->id
                    ] ?? []
                )
                    ->map(fn ($id) => (int) $id)
                    ->unique()
                    ->values();
            ?>

            
            <?php if($questionTypeId === 1): ?>
                <div
                    class="rounded-xl border border-blue-200
                           bg-blue-50 px-5 py-4"
                >
                    <h2
                        class="text-center text-lg
                               font-bold text-gray-800"
                    >
                        <?php echo e($question->name); ?>

                    </h2>
                </div>

                <?php continue; ?>
            <?php endif; ?>

            <?php if($activeSubunitIds->isEmpty()) continue; ?>

            <section
                class="overflow-hidden rounded-xl
                       border border-gray-200
                       bg-white shadow-sm"
            >
                
                <header
                    class="border-b border-gray-200
                           px-5 py-4"
                >
                    <div class="flex items-start gap-3">
                        <span
                            class="inline-flex h-9 min-w-9
                                   shrink-0 items-center
                                   justify-center rounded-lg
                                   bg-blue-100 px-2 text-sm
                                   font-semibold text-blue-700"
                        >
                            <?php echo e($questionNumber); ?>

                        </span>

                        <div>
                            <h3 class="font-semibold text-gray-900">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                <?php if($questionTypeId === 2): ?>
                                    Penilaian Kepentingan dan Kinerja
                                <?php elseif($questionTypeId === 3): ?>
                                    Penilaian Kepentingan dan Kinerja dengan alasan
                                <?php elseif($questionTypeId === 4): ?>
                                    Penilaian Kepentingan dan Kinerja dengan pilihan alasan
                                <?php elseif($questionTypeId === 5): ?>
                                    Penilaian satu indikator
                                <?php elseif($questionTypeId === 6): ?>
                                    Jawaban penilaian
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </header>

                <div class="space-y-5 bg-gray-50 p-5">
                    <?php $__currentLoopData = $activeSubunitIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunitId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $subunit = $subunits->firstWhere(
                                'id',
                                $subunitId
                            );

                            $storedAnswer = data_get(
                                $answerMap,
                                "{$question->id}.{$subunitId}.0",
                                []
                            );

                            $storedImportance = old(
                                "answers.{$question->id}.{$subunitId}.importance",
                                data_get(
                                    $storedAnswer,
                                    'importance'
                                )
                            );

                            $storedPerformance = old(
                                "answers.{$question->id}.{$subunitId}.performance",
                                data_get(
                                    $storedAnswer,
                                    'performance'
                                )
                            );

                            $storedReason = old(
                                "answers.{$question->id}.{$subunitId}.reason",
                                data_get(
                                    $storedAnswer,
                                    'reason'
                                )
                            );

                            $storedReasonOptions = old(
                                "answers.{$question->id}.{$subunitId}.reasons",
                                data_get(
                                    $storedAnswer,
                                    'reasons',
                                    []
                                )
                            );

                            $storedChildren = old(
                                "answers.{$question->id}.{$subunitId}.children",
                                data_get(
                                    $storedAnswer,
                                    'children',
                                    []
                                )
                            );

                            $storedValue = old(
                                "answers.{$question->id}.{$subunitId}.value",
                                data_get(
                                    $storedAnswer,
                                    'value'
                                )
                            );

                            $showReason =
                                filled($storedPerformance) &&
                                (int) $storedPerformance !== 0 &&
                                (int) $storedPerformance <=
                                    $reasonMaximum;
                        ?>

                        <?php if(!$subunit) continue; ?>

                        <div
                            data-question-container
                            data-customer-assessment
                            data-question-type="<?php echo e($questionTypeId); ?>"
                            data-reason-maximum="<?php echo e($reasonMaximum); ?>"
                            class="rounded-xl border
                                   border-gray-200 bg-white"
                        >
                            
                            <div
                                class="flex items-center gap-3
                                       border-b border-blue-200
                                       bg-blue-50 px-5 py-4"
                            >
                                <span
                                    class="inline-flex h-10 w-10
                                           items-center justify-center
                                           rounded-lg bg-blue-100
                                           text-blue-600"
                                >
                                    <i class="fa-solid fa-building"></i>
                                </span>

                                <div>
                                    <div
                                        class="text-xs font-semibold
                                               uppercase tracking-wide
                                               text-blue-600"
                                    >
                                        Sub Unit
                                    </div>

                                    <div class="font-bold text-gray-900">
                                        <?php echo e($subunit->name); ?>

                                    </div>
                                </div>
                            </div>

                            <div class="space-y-5 p-5">

                                
                                <?php if(
                                    in_array(
                                        $questionTypeId,
                                        [2, 3, 4],
                                        true
                                    )
                                ): ?>
                                    <div
                                        class="grid grid-cols-1
                                               gap-5 lg:grid-cols-2"
                                    >
                                        
                                        <div
                                            class="rounded-xl border
                                                   border-blue-200
                                                   bg-blue-50 p-5"
                                        >
                                            <div
                                                class="mb-4 text-center
                                                       font-semibold
                                                       text-blue-700"
                                            >
                                                Kepentingan
                                            </div>

                                            <div
                                                data-option-group
                                                class="flex flex-wrap
                                                       items-center
                                                       justify-center gap-3"
                                            >
                                                <?php $__currentLoopData = $scaleValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($value === 0): ?>
                                                        <div
                                                            class="mx-2 h-9
                                                                   border-l
                                                                   border-blue-300"
                                                        ></div>
                                                    <?php endif; ?>

                                                    <label class="cursor-pointer">
                                                        <input
                                                            type="radio"
                                                            name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][importance]"
                                                            value="<?php echo e($value); ?>"
                                                            <?php if(
                                                                (string) $storedImportance ===
                                                                (string) $value
                                                            ): echo 'checked'; endif; ?>
                                                            required
                                                            class="peer sr-only"
                                                        >

                                                        <span
                                                            class="inline-flex
                                                                   h-10 w-10
                                                                   items-center
                                                                   justify-center
                                                                   rounded-full
                                                                   border
                                                                   border-blue-300
                                                                   bg-white text-sm
                                                                   text-blue-700
                                                                   transition
                                                                   peer-checked:border-blue-600
                                                                   peer-checked:bg-blue-600
                                                                   peer-checked:text-white"
                                                        >
                                                            <?php echo e($value); ?>

                                                        </span>
                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>

                                        
                                        <div
                                            class="rounded-xl border
                                                   border-emerald-200
                                                   bg-emerald-50 p-5"
                                        >
                                            <div
                                                class="mb-4 text-center
                                                       font-semibold
                                                       text-emerald-700"
                                            >
                                                Kinerja
                                            </div>

                                            <div
                                                data-option-group
                                                class="flex flex-wrap
                                                       items-center
                                                       justify-center gap-3"
                                            >
                                                <?php $__currentLoopData = $scaleValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if($value === 0): ?>
                                                        <div
                                                            class="mx-2 h-9
                                                                   border-l
                                                                   border-emerald-300"
                                                        ></div>
                                                    <?php endif; ?>

                                                    <label class="cursor-pointer">
                                                        <input
                                                            type="radio"
                                                            name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][performance]"
                                                            value="<?php echo e($value); ?>"
                                                            data-performance-input
                                                            <?php if(
                                                                (string) $storedPerformance ===
                                                                (string) $value
                                                            ): echo 'checked'; endif; ?>
                                                            required
                                                            class="peer sr-only"
                                                        >

                                                        <span
                                                            class="inline-flex
                                                                   h-10 w-10
                                                                   items-center
                                                                   justify-center
                                                                   rounded-full
                                                                   border
                                                                   border-emerald-300
                                                                   bg-white text-sm
                                                                   text-emerald-700
                                                                   transition
                                                                   peer-checked:border-emerald-600
                                                                   peer-checked:bg-emerald-600
                                                                   peer-checked:text-white"
                                                        >
                                                            <?php echo e($value); ?>

                                                        </span>
                                                    </label>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                
                                <?php if($questionTypeId === 3): ?>
                                    <div
                                        data-performance-reason
                                        class="<?php echo e($showReason ? '' : 'hidden'); ?>

                                               rounded-xl border
                                               border-amber-200
                                               bg-amber-50 p-5"
                                    >
                                        <div class="mb-4">
                                            <h4
                                                class="font-semibold
                                                       text-gray-900"
                                            >
                                                Alasan Penilaian Kinerja
                                            </h4>

                                            <p
                                                class="mt-1 text-sm
                                                       text-gray-500"
                                            >
                                                Wajib diisi jika nilai
                                                Kinerja 1–<?php echo e($reasonMaximum); ?>.
                                            </p>
                                        </div>

                                        <textarea
                                            name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][reason]"
                                            rows="4"
                                            data-performance-reason-input
                                            <?php if($showReason): echo 'required'; endif; ?>
                                            <?php if(!$showReason): echo 'disabled'; endif; ?>
                                            placeholder="Tuliskan alasan penilaian Kinerja..."
                                            class="w-full rounded-lg
                                                   border border-gray-300
                                                   px-4 py-3 text-sm
                                                   outline-none
                                                   focus:border-amber-500
                                                   focus:ring-2
                                                   focus:ring-amber-100"
                                        ><?php echo e($storedReason); ?></textarea>
                                    </div>
                                <?php endif; ?>

                                
                                <?php if($questionTypeId === 4): ?>
                                    <div
                                        data-performance-reason
                                        class="<?php echo e($showReason ? '' : 'hidden'); ?>

                                               rounded-xl border
                                               border-amber-200
                                               bg-amber-50 p-5"
                                    >
                                        <div class="mb-4">
                                            <h4 class="font-semibold text-gray-900">
                                                Pilihan Alasan
                                            </h4>

                                            <p class="mt-1 text-sm text-gray-500">
                                                Pilih minimal satu alasan jika
                                                Kinerja 1–<?php echo e($reasonMaximum); ?>.
                                            </p>
                                        </div>

                                        <div
                                            data-reason-checkbox-group
                                            <?php if($showReason): ?>
                                                data-required-group
                                            <?php endif; ?>
                                            class="space-y-3"
                                        >
                                            <?php $__empty_2 = true; $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                                <?php
                                                    $optionChecked = in_array(
                                                        (string) $option->id,
                                                        array_map(
                                                            'strval',
                                                            (array) $storedReasonOptions
                                                        ),
                                                        true
                                                    );

                                                    $hasChild =
                                                        (int) $option->has_child === 1;

                                                    $childValue = data_get(
                                                        $storedChildren,
                                                        $option->id,
                                                        ''
                                                    );
                                                ?>

                                                <div
                                                    class="overflow-hidden
                                                           rounded-lg border
                                                           border-gray-200
                                                           bg-white"
                                                >
                                                    <label
                                                        class="flex cursor-pointer
                                                               items-start gap-3 p-4"
                                                    >
                                                        <input
                                                            type="checkbox"
                                                            name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][reasons][]"
                                                            value="<?php echo e($option->id); ?>"
                                                            data-option-input
                                                            data-has-child="<?php echo e($hasChild ? 1 : 0); ?>"
                                                            data-child-target="customer-child-<?php echo e($question->id); ?>-<?php echo e($subunitId); ?>-<?php echo e($option->id); ?>"
                                                            <?php if($optionChecked): echo 'checked'; endif; ?>
                                                            <?php if(!$showReason): echo 'disabled'; endif; ?>
                                                            class="mt-0.5 h-4 w-4
                                                                   rounded border-gray-300
                                                                   text-indigo-600
                                                                   focus:ring-indigo-500"
                                                        >

                                                        <span
                                                            class="text-sm
                                                                   font-medium
                                                                   text-gray-700"
                                                        >
                                                            <?php echo e($option->answer_text); ?>

                                                        </span>
                                                    </label>

                                                    <?php if($hasChild): ?>
                                                        <div
                                                            id="customer-child-<?php echo e($question->id); ?>-<?php echo e($subunitId); ?>-<?php echo e($option->id); ?>"
                                                            data-child-container
                                                            class="<?php echo e($showReason && $optionChecked ? '' : 'hidden'); ?>

                                                                   border-t
                                                                   border-gray-200 p-4"
                                                        >
                                                            <?php if(filled($option->answer_text2)): ?>
                                                                <label
                                                                    class="mb-2 block
                                                                           text-sm
                                                                           font-medium
                                                                           text-gray-700"
                                                                >
                                                                    <?php echo e($option->answer_text2); ?>

                                                                </label>
                                                            <?php endif; ?>

                                                            <textarea
                                                                name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][children][<?php echo e($option->id); ?>]"
                                                                rows="3"
                                                                data-child-input
                                                                <?php if(
                                                                    $showReason &&
                                                                    $optionChecked
                                                                ): echo 'required'; endif; ?>
                                                                <?php if(
                                                                    !$showReason ||
                                                                    !$optionChecked
                                                                ): echo 'disabled'; endif; ?>
                                                                placeholder="Tulis jawaban tambahan..."
                                                                class="w-full
                                                                       rounded-lg
                                                                       border
                                                                       border-gray-300
                                                                       px-4 py-3
                                                                       text-sm
                                                                       outline-none
                                                                       focus:border-indigo-500
                                                                       focus:ring-2
                                                                       focus:ring-indigo-100"
                                                            ><?php echo e($childValue); ?></textarea>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                                <div
                                                    class="rounded-lg
                                                           border border-dashed
                                                           border-gray-300
                                                           p-5 text-center
                                                           text-sm text-gray-500"
                                                >
                                                    Pilihan alasan belum tersedia.
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                
                                <?php if($questionTypeId === 5): ?>
                                    <div
                                        data-option-group
                                        class="flex flex-wrap
                                               items-center justify-center
                                               gap-3 rounded-xl border
                                               border-indigo-200
                                               bg-indigo-50 p-5"
                                    >
                                        <?php $__currentLoopData = $scaleValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($value === 0): ?>
                                                <div
                                                    class="mx-2 h-9
                                                           border-l
                                                           border-indigo-300"
                                                ></div>
                                            <?php endif; ?>

                                            <label class="cursor-pointer">
                                                <input
                                                    type="radio"
                                                    name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][value]"
                                                    value="<?php echo e($value); ?>"
                                                    <?php if(
                                                        (string) $storedValue ===
                                                        (string) $value
                                                    ): echo 'checked'; endif; ?>
                                                    required
                                                    class="peer sr-only"
                                                >

                                                <span
                                                    class="inline-flex h-10 w-10
                                                           items-center
                                                           justify-center
                                                           rounded-full border
                                                           border-indigo-300
                                                           bg-white text-sm
                                                           text-indigo-700
                                                           peer-checked:border-indigo-600
                                                           peer-checked:bg-indigo-600
                                                           peer-checked:text-white"
                                                >
                                                    <?php echo e($value); ?>

                                                </span>
                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php endif; ?>

                                
                                <?php if($questionTypeId === 6): ?>
                                    <textarea
                                        name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][value]"
                                        rows="4"
                                        required
                                        placeholder="Tulis jawaban..."
                                        class="w-full rounded-lg border
                                               border-gray-300 px-4 py-3
                                               text-sm outline-none
                                               focus:border-indigo-500
                                               focus:ring-2
                                               focus:ring-indigo-100"
                                    ><?php echo e($storedValue); ?></textarea>
                                <?php endif; ?>

                                <p
                                    data-question-error
                                    class="hidden text-sm
                                           font-medium text-red-600"
                                >
                                    Pertanyaan ini wajib diisi.
                                </p>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make('user.survey.partials.empty', [
            'message' =>
                'Form ini belum memiliki pertanyaan aktif.',
        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/partials/customer-assessment.blade.php ENDPATH**/ ?>