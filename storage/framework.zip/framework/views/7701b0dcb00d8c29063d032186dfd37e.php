<?php
    $perSubUnitFormTypes = [
        2,
        3,
        8,
        9,
        10,
    ];

    $globalFormTypes = [
        1,
        4,
        5,
        6,
        7,
        11,
        12,
        13,
    ];

    $totalVisibleForms = 0;
?>

<div
    id="showQuestionContent"
    class="space-y-6"
>
    
    <div class="rounded-lg border border-yellow-300 bg-yellow-50 p-4 text-sm text-yellow-800">
        <div>
            Jumlah Form:
            <strong><?php echo e(isset($forms) ? $forms->count() : 0); ?></strong>
        </div>

        <div>
            Jumlah Sub Unit:
            <strong><?php echo e(isset($allSubunits) ? $allSubunits->count() : 0); ?></strong>
        </div>

        <div>
            Jumlah Mapping Aktif:
            <strong><?php echo e(isset($activeMapSubUnit) ? count($activeMapSubUnit) : 0); ?></strong>
        </div>
    </div>

    <?php if(!isset($forms) || $forms->isEmpty()): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.partials.empty',
            [
                'icon' => 'fa-clipboard-question',
                'title' => 'Form belum tersedia',
                'message' => 'Belum ada Form untuk Unit ini.',
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php elseif(!isset($allSubunits) || $allSubunits->isEmpty()): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.partials.empty',
            [
                'icon' => 'fa-building-circle-xmark',
                'title' => 'Sub Unit belum tersedia',
                'message' => 'Tambahkan Sub Unit terlebih dahulu.',
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php else: ?>
        <?php $__currentLoopData = $forms->sortBy('no_urut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $form): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $formTypeId = (int) (
                    $form->formtype_id
                    ?? $form->id_formtype
                    ?? 0
                );

                $isPerSubUnit = in_array(
                    $formTypeId,
                    $perSubUnitFormTypes,
                    true
                );

                $isGlobal = in_array(
                    $formTypeId,
                    $globalFormTypes,
                    true
                );

                $activeQuestions = $form->questions
                    ->filter(function ($question) use (
                        $form,
                        $activeMapSubUnit
                    ) {
                        $key = (int) $form->id
                            . '-'
                            . (int) $question->id;

                        return count(
                            $activeMapSubUnit[$key] ?? []
                        ) > 0;
                    })
                    ->values();

                $hasDescription = (
                    $form->description
                    && !empty(
                        $form->description->content
                    )
                );

                $canShowForm =
                    $activeQuestions->isNotEmpty()
                    || (
                        $formTypeId === 12
                        && $hasDescription
                    );

                if ($canShowForm) {
                    $totalVisibleForms++;
                }
            ?>

            <?php if($canShowForm): ?>
                <?php echo $__env->make(
                    'admin.subunit.show-question.partials.form-card',
                    [
                        'form' => $form,
                        'formTypeId' => $formTypeId,
                        'isPerSubUnit' => $isPerSubUnit,
                        'isGlobal' => $isGlobal,
                        'activeQuestions' => $activeQuestions,
                        'allSubunits' => $allSubunits,
                        'activeMapSubUnit' => $activeMapSubUnit,
                        'competitors' => $competitors,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($totalVisibleForms === 0): ?>
            <?php echo $__env->make(
                'admin.subunit.show-question.partials.empty',
                [
                    'icon' => 'fa-eye-slash',
                    'title' => 'Belum ada pertanyaan aktif',
                    'message' => 'Aktifkan pertanyaan pada tab Hide and Show.',
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endif; ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/index.blade.php ENDPATH**/ ?>