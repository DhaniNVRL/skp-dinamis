<?php
    $scaleValues = range(
        1,
        $maximumScale
    );
?>

<div class="space-y-6">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $questionGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="space-y-5">
            <?php $__currentLoopData = $questionGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $questionTypeId =
                        (int) $question->questiontype_id;

                    $questionNumber = trim(
                        ($question->no_header ?? '') .
                        ($question->no ?? '')
                    );

                    $storedAnswer = data_get(
                        $answerMap,
                        "{$question->id}.0.0",
                        []
                    );

                    $storedValue = old(
                        "answers.{$question->id}.value",
                        data_get(
                            $storedAnswer,
                            'value'
                        )
                    );
                ?>

                
                <?php if($questionTypeId === 1): ?>
                    <div
                        class="overflow-hidden rounded-xl
                               border border-indigo-200
                               bg-indigo-50 shadow-sm"
                    >
                        <div
                            class="flex items-start gap-4
                                   px-6 py-5"
                        >
                            <span
                                class="inline-flex h-11 w-11
                                       shrink-0 items-center
                                       justify-center rounded-xl
                                       bg-indigo-100 text-indigo-600"
                            >
                                <i class="fa-solid fa-list-check"></i>
                            </span>

                            <div class="flex-1">
                                <div
                                    class="text-xs font-semibold
                                           uppercase tracking-wide
                                           text-indigo-500"
                                >
                                    Petunjuk Pertanyaan
                                </div>

                                <h2
                                    class="mt-1 text-lg
                                           font-bold text-gray-900"
                                >
                                    <?php echo e($question->name); ?>

                                </h2>
                            </div>
                        </div>
                    </div>

                    <?php continue; ?>
                <?php endif; ?>

                
                <?php if($questionTypeId === 2): ?>
                    <div
                        data-question-container
                        data-question-id="<?php echo e($question->id); ?>"
                        class="overflow-hidden rounded-xl
                               border border-gray-200
                               bg-white shadow-sm"
                    >
                        
                        <div
                            class="border-b border-gray-200
                                   px-5 py-4"
                        >
                            <div class="flex items-start gap-3">
                                <span
                                    class="inline-flex h-9 min-w-9
                                           shrink-0 items-center
                                           justify-center rounded-lg
                                           bg-purple-100 px-2
                                           text-sm font-semibold
                                           text-purple-700"
                                >
                                    <?php echo e($questionNumber); ?>

                                </span>

                                <div>
                                    <h3
                                        class="font-semibold
                                               leading-relaxed
                                               text-gray-900"
                                    >
                                        <?php echo e($question->name); ?>

                                    </h3>

                                    <p
                                        class="mt-1 text-xs
                                               text-gray-500"
                                    >
                                        Pilih satu nilai yang paling sesuai.
                                    </p>
                                </div>
                            </div>
                        </div>

                        
                        <div class="px-5 py-6">
                            <div
                                data-option-group
                                class="rounded-xl border
                                       border-purple-200
                                       bg-purple-50 px-5 py-6"
                            >
                                <div
                                    class="flex flex-wrap
                                           items-center justify-center
                                           gap-3 md:gap-4"
                                >
                                    <?php $__currentLoopData = $scaleValues; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <label
                                            for="engagement-<?php echo e($question->id); ?>-<?php echo e($value); ?>"
                                            class="cursor-pointer"
                                        >
                                            <input
                                                id="engagement-<?php echo e($question->id); ?>-<?php echo e($value); ?>"
                                                type="radio"
                                                name="answers[<?php echo e($question->id); ?>][value]"
                                                value="<?php echo e($value); ?>"
                                                <?php if(
                                                    (string) $storedValue ===
                                                    (string) $value
                                                ): echo 'checked'; endif; ?>
                                                required
                                                class="peer sr-only"
                                            >

                                            <span
                                                class="inline-flex h-11 w-11
                                                       items-center
                                                       justify-center
                                                       rounded-full border
                                                       border-purple-300
                                                       bg-white text-sm
                                                       font-medium
                                                       text-purple-700
                                                       transition
                                                       hover:border-purple-500
                                                       hover:bg-purple-100
                                                       peer-checked:border-purple-600
                                                       peer-checked:bg-purple-600
                                                       peer-checked:text-white
                                                       peer-focus:ring-2
                                                       peer-focus:ring-purple-200"
                                            >
                                                <?php echo e($value); ?>

                                            </span>
                                        </label>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                                
                                <div
                                    class="mx-auto mt-5 flex
                                           max-w-xl items-center
                                           justify-between gap-4
                                           text-xs text-gray-500"
                                >
                                    <span class="text-left">
                                        <?php echo e($minimumLabel); ?>

                                    </span>

                                    <div
                                        class="h-px flex-1
                                               bg-purple-200"
                                    ></div>

                                    <span class="text-right">
                                        <?php echo e($maximumLabel); ?>

                                    </span>
                                </div>
                            </div>

                            
                            <p
                                data-question-error
                                class="mt-3 hidden text-sm
                                       font-medium text-red-600"
                            >
                                Pilih salah satu nilai.
                            </p>
                        </div>
                    </div>

                    <?php continue; ?>
                <?php endif; ?>

                
                <div
                    class="rounded-xl border border-red-200
                           bg-red-50 px-5 py-4
                           text-sm text-red-600"
                >
                    Question Type <?php echo e($questionTypeId); ?>

                    belum didukung pada Form Keterikatan.
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make(
            'user.survey.partials.empty',
            [
                'message' =>
                    'Form Keterikatan belum memiliki pertanyaan aktif.',
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/partials/engagement-assessment.blade.php ENDPATH**/ ?>