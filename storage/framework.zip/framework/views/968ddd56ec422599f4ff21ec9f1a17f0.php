<div class="overflow-visible rounded-lg border border-gray-200 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table
            id="subUnitTable"
            class="min-w-full divide-y divide-gray-200"
        >
            <thead class="bg-gray-100">
                <tr>
                    <th class="w-12 px-4 py-3 text-center">
                        <input
                            id="selectAllSubUnit"
                            type="checkbox"
                            class="h-4 w-4 rounded border-gray-300 text-blue-600"
                        >
                    </th>

                    <th class="w-20 px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-gray-600">
                        No
                    </th>

                    <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wider text-gray-600">
                        Nama Sub Unit
                    </th>

                    <th class="w-36 px-4 py-3 text-center text-xs font-semibold uppercase tracking-wider text-gray-600">
                        Aksi
                    </th>
                </tr>
            </thead>

            <tbody class="divide-y divide-gray-200 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $subunits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="transition hover:bg-gray-50">
                        <td class="px-4 py-3 text-center">
                            <input
                                type="checkbox"
                                value="<?php echo e($subunit->id); ?>"
                                class="subunit-checkbox h-4 w-4 rounded border-gray-300 text-blue-600"
                            >
                        </td>

                        <td class="px-4 py-3 text-center text-sm text-gray-600">
                            <?php echo e($subunits->firstItem() + $loop->index); ?>

                        </td>

                        <td class="px-4 py-3 text-sm font-medium text-gray-800">
                            <?php echo e($subunit->name); ?>

                        </td>

                        <td class="px-4 py-3 text-center">
                            <?php echo $__env->make('admin.subunit.partials.row-action', [
                                'subunit' => $subunit,
                            ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td
                            colspan="4"
                            class="px-6 py-12 text-center"
                        >
                            <div class="text-4xl text-gray-300">
                                <i class="fa-solid fa-building-circle-xmark"></i>
                            </div>

                            <div class="mt-3 font-medium text-gray-600">
                                Sub Unit tidak ditemukan
                            </div>

                            <p class="mt-1 text-sm text-gray-400">
                                <?php if(request()->filled('search')): ?>
                                    Tidak ada Sub Unit yang cocok dengan pencarian.
                                <?php else: ?>
                                    Silakan tambahkan atau import data Sub Unit.
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/partials/table.blade.php ENDPATH**/ ?>