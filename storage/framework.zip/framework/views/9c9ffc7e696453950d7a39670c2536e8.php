<div class="space-y-5">

    <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.question-card',
            [
                'question' => $question
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <div class="rounded-xl border border-dashed border-gray-300 bg-white py-12 text-center">
            Belum ada pertanyaan
        </div>

    <?php endif; ?>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/question-list.blade.php ENDPATH**/ ?>