

<?php $__env->startSection('title', 'Sub Unit'); ?>

<?php $__env->startSection('content'); ?>
<div
    id="subUnitPage"
    data-active-tab="<?php echo e($activeTab ?? request('tab', 'subunit')); ?>"
    data-unit-id="<?php echo e($units->id); ?>"
    class="space-y-6"
>
    
    <?php echo $__env->make('admin.subunit.subunit.partials.page-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php if(session('success')): ?>
        <div
            data-alert
            class="flex items-start justify-between rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700"
        >
            <div>
                <i class="fa-solid fa-circle-check mr-2"></i>
                <?php echo e(session('success')); ?>

            </div>

            <button
                type="button"
                data-alert-close
                class="ml-4 text-green-500 hover:text-green-700"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    
    <?php if(session('successdelete')): ?>
        <div
            data-alert
            class="flex items-start justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
        >
            <div>
                <i class="fa-solid fa-trash mr-2"></i>
                <?php echo e(session('successdelete')); ?>

            </div>

            <button
                type="button"
                data-alert-close
                class="ml-4 text-red-500 hover:text-red-700"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    
    <?php if(session('error')): ?>
        <div
            data-alert
            class="flex items-start justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"
        >
            <div>
                <i class="fa-solid fa-circle-exclamation mr-2"></i>
                <?php echo e(session('error')); ?>

            </div>

            <button
                type="button"
                data-alert-close
                class="ml-4 text-red-500 hover:text-red-700"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    
    <?php if($errors->any()): ?>
        <div
            data-alert
            class="flex items-start justify-between rounded-lg border border-red-200 bg-red-50 p-4"
        >
            <div>
                <div class="font-semibold text-red-700">
                    Data belum dapat diproses:
                </div>

                <ul class="mt-2 list-disc space-y-1 pl-5 text-sm text-red-600">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

            <button
                type="button"
                data-alert-close
                class="ml-4 text-red-500 hover:text-red-700"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>
        </div>
    <?php endif; ?>

    
    <div
        id="subUnitTabContainer"
        class="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm"
    >
        
        <div
            id="subUnitTabNavigation"
            data-subunit-tabs
            class="flex overflow-x-auto border-b border-gray-200 bg-gray-50"
        >
            <button
                id="subUnitTabButton"
                type="button"
                data-subunit-tab="subunit"
                class="subunit-tab-button whitespace-nowrap border-b-2 border-transparent px-6 py-4 text-sm font-semibold text-gray-500 transition hover:text-gray-700"
            >
                <i class="fa-solid fa-building mr-2"></i>
                Sub Unit
            </button>

            <button
                id="hideShowTabButton"
                type="button"
                data-subunit-tab="hide-show"
                class="subunit-tab-button whitespace-nowrap border-b-2 border-transparent px-6 py-4 text-sm font-semibold text-gray-500 transition hover:text-gray-700"
            >
                <i class="fa-solid fa-eye mr-2"></i>
                Hide and Show
            </button>

            <button
                id="questionPreviewTabButton"
                type="button"
                data-subunit-tab="question-preview"
                class="subunit-tab-button whitespace-nowrap border-b-2 border-transparent px-6 py-4 text-sm font-semibold text-gray-500 transition hover:text-gray-700"
            >
                <i class="fa-solid fa-list-check mr-2"></i>
                Tampilan Pertanyaan
            </button>
        </div>

        
        <div class="p-5">
            
            <div
                id="subUnitTabContent"
                data-subunit-content="subunit"
                class="subunit-tab-content"
            >
                <?php echo $__env->make('admin.subunit.pages.subunit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            
            <div
                id="hideShowTabContent"
                data-subunit-content="hide-show"
                class="subunit-tab-content hidden"
            >
                <?php echo $__env->make('admin.subunit.pages.hide-show', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            
            <div
                id="questionPreviewTabContent"
                data-subunit-content="question-preview"
                class="subunit-tab-content hidden"
            >
                <?php echo $__env->make('admin.subunit.pages.question-preview', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
</div>


<?php echo $__env->make('admin.subunit.subunit.modals.create-subunit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.subunit.subunit.modals.edit-subunit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.subunit.subunit.modals.delete-subunit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.subunit.subunit.modals.bulk-delete-subunit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>


<?php echo $__env->make('admin.subunit.subunit.templates.create-row-subunit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/index.blade.php ENDPATH**/ ?>