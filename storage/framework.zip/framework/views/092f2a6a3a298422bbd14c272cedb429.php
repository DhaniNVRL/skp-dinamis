<?php ($content = $form->description->content ?? $form->description->description ?? $form->description->text ?? null); ?>
<article class="prose max-w-none rounded-xl border border-gray-200 bg-white p-6 text-gray-700">
    <?php if($content): ?>
        <?php echo $content; ?>

    <?php else: ?>
        <p>Konten deskripsi belum tersedia.</p>
    <?php endif; ?>
</article>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/description.blade.php ENDPATH**/ ?>