
<?php $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noHeader => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php
        $subunitList = $subunitIds->toArray();
        $questionType1 = $group->where('questiontype_id', 1)
            ->sortBy('no')
            ->filter(function ($question) use ($form, $activeMapSubUnit, $subunitList) {
                $key = $form->id.'-'.$question->id;

                return isset($activeMapSubUnit[$key]) &&
                    count(array_intersect($activeMapSubUnit[$key], $subunitList)) > 0;
            });
    ?>

    <?php if($questionType1->isNotEmpty()): ?>
        <div class="mb-6 p-4 rounded-xl bg-blue-100 border shadow-sm">
            <h4 class="text-center font-bold text-lg text-gray-800">
                <?php echo e($questionType1->first()->name); ?>

            </h4>
        </div>
    <?php endif; ?>


    
    <?php $__currentLoopData = $group->where('questiontype_id', 2)->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
            $key = $form->id . '-' . $question->id;
            $subQuestions = $activeMapSubUnit[$key] ?? [];
        ?>

        
        <?php if(empty($subQuestions)): ?>
            <?php continue; ?>
        <?php endif; ?>

        <div class="question-card mb-6 bg-white border rounded-xl shadow-sm p-5">

            <div class="flex items-start justify-between gap-4 mb-4">
                <div class="font-semibold text-gray-800">
                    <?php echo e($question->no_header); ?><?php echo e($question->no); ?>. <?php echo e($question->name); ?>

                </div>
            </div>

            <?php $__currentLoopData = $subQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunitId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $subunit = $subunits->firstWhere('id', $subunitId);
                    $answerKey = $question->id.'-'.$subunitId.'-0';
                    $current = $answerMap->get($answerKey, []);
                ?>

                <?php if(!$subunit) continue; ?>

                <div class="border rounded-lg p-4 mb-5" x-data="{
                        kinerja: '<?php echo e($current['kinerja'] ?? ''); ?>'
                    }">

                    <div class="text-lg font-bold text-center text-blue-700 mb-4">
                        <?php echo e($subunit->name); ?>

                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">

                        
                        <div class="rounded-lg p-4">
                            <div class="text-center font-semibold mb-3">
                                Kepentingan
                            </div>

                            <div class="flex flex-wrap justify-center gap-3">
                                <?php $__currentLoopData = [1,2,3,4,5,6,7,0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center gap-1 text-sm">
                                        <input
                                            type="radio"
                                            name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][kepentingan]"
                                            value="<?php echo e($value); ?>"
                                            <?php echo e((int)($current['kepentingan'] ?? -1) === $value ? 'checked' : ''); ?>

                                            class="kepentingan-radio text-blue-600 focus:ring-blue-500">
                                        <span><?php echo e($value); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                        
                        <div class="rounded-lg p-4">
                            <div class="text-center font-semibold mb-3">
                                Kinerja
                            </div>

                            <div class="flex flex-wrap justify-center gap-3">
                                <?php $__currentLoopData = [1,2,3,4,5,6,7,0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="flex items-center gap-1 text-sm">
                                        <input
                                            type="radio"
                                            name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][kinerja]"
                                            value="<?php echo e($value); ?>"
                                            x-model="kinerja"
                                            <?php echo e((int)($current['kinerja'] ?? -1) === $value ? 'checked' : ''); ?>

                                            class="kinerja-radio text-blue-600 focus:ring-blue-500">
                                        <span><?php echo e($value); ?></span>
                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>

                    </div>

                    

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    
    <?php $__currentLoopData = $type3Questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $key = $form->id . '-' . $question->id;
        $subQuestions = $activeMapSubUnit[$key] ?? [];
    ?>

    <?php if(empty($subQuestions)) continue; ?>

    <div class="question-card mb-6 bg-white border rounded-xl shadow-sm p-5">

        <div class="font-semibold text-gray-800 mb-4">
            <?php echo e($question->no_header); ?><?php echo e($question->no); ?>. <?php echo e($question->name); ?>

        </div>

        <?php $__currentLoopData = $subQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunitId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php
                $subunit = $subunits->firstWhere('id', $subunitId);
                $answerKey = $question->id . '-' . $subunitId . '-0';
                $current = $answerMap->get($answerKey, []);
            ?>

            <?php if(!$subunit) continue; ?>

            <div class="border rounded-lg p-4 mb-5">

                <div class="text-lg font-bold text-center text-blue-700 mb-4">
                    <?php echo e($subunit->name); ?>

                </div>

                <div class="flex flex-wrap justify-center gap-3">

                    <?php $__currentLoopData = [1,2,3,4,5,6,7,0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <label class="flex items-center gap-1 text-sm">

                            <input
                                type="radio"
                                name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][nilai]"
                                value="<?php echo e($value); ?>"
                                <?php if((int)($current['nilai'] ?? -1) === $value): echo 'checked'; endif; ?>
                                class="nilai-radio text-blue-600 focus:ring-blue-500">

                            <span><?php echo e($value); ?></span>

                        </label>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    
    <?php $__currentLoopData = $group->where('questiontype_id', 4)->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
            $key = $form->id . '-' . $question->id;
            $subQuestions = $activeMapSubUnit[$key] ?? [];
        ?>

        <?php if(empty($subQuestions)) continue; ?>

        <div class="question-card mb-6 bg-white border rounded-xl shadow-sm p-5">

            <div class="font-semibold text-gray-800 mb-4">
                <?php echo e($question->no_header); ?><?php echo e($question->no); ?>. <?php echo e($question->name); ?>

            </div>

            <?php $__currentLoopData = $subQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunitId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $subunit = $subunits->firstWhere('id', $subunitId);
                    $answerKey = $question->id.'-'.$subunitId.'-0';
                    $current = $answerMap->get($answerKey, []);
                ?>

                <?php if(!$subunit) continue; ?>

                <div class="border rounded-lg p-4 mb-4">

                    <div class="text-lg font-bold text-center text-blue-700 mb-3">
                        <?php echo e($subunit->name); ?>

                    </div>

                    <textarea
                        name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][essay]"
                        rows="4"
                        class="essay-textarea w-full border rounded-lg p-3"
                        placeholder="Tulis jawaban Anda di sini..."
                    ><?php echo e($current['essay'] ?? ''); ?></textarea>

                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    document.addEventListener('DOMContentLoaded', function () {

        document.querySelectorAll('.border.rounded-lg.p-4.mb-5').forEach(function(card){

            const radios = card.querySelectorAll('.kinerja-radio');
            const alasan = card.querySelector('.alasan-box');

            if (!alasan) return;

            function toggleAlasan() {

                const checked = card.querySelector('.kinerja-radio:checked');

                if (!checked) {
                    alasan.classList.add('hidden');
                    return;
                }

                const nilai = parseInt(checked.value);

                if (nilai < 5 && nilai > 0) {
                    alasan.classList.remove('hidden');
                } else {
                    alasan.classList.add('hidden');
                }

            }

            radios.forEach(function(radio){
                radio.addEventListener('change', toggleAlasan);
            });

            // Saat edit
            toggleAlasan();

        });

    });
    document.addEventListener("change", function(e){

        // ==========================
        // Clear Error Semua Radio
        // ==========================
        if(
            e.target.classList.contains("kinerja-radio") ||
            e.target.classList.contains("kepentingan-radio") ||
            e.target.classList.contains("nilai-radio")
        ){
            clearQuestionError(e.target);
        }

        // ==========================
        // Toggle hanya untuk Kinerja
        // ==========================
        if(!e.target.classList.contains("kinerja-radio")){
            return;
        }

        const card = e.target.closest(".border.rounded-lg.p-4");

            if(!card) return;

        const alasan = card.querySelector(".alasan-box");

            if(!alasan) return;

        

        const textarea = alasan.querySelector(".alasan-textarea");

    });
    const form = document.getElementById("surveyForm");
        form.addEventListener("submit",function(e){

            let valid = true;

            let firstError = null;

            //------------------------
            // Semua Radio Wajib
            //------------------------

            const groups = {};

            form.querySelectorAll("input[type=radio]").forEach(radio=>{

                if(!(radio.name in groups)){

                    groups[radio.name]=false;

                }

                if(radio.checked){

                    groups[radio.name]=true;

                }

            });

            Object.keys(groups).forEach(name=>{

                if(!groups[name]){

                    valid = false;

                    const radio = form.querySelector(`[name="${CSS.escape(name)}"]`);

                    setQuestionError(radio);

                    if(!firstError){
                        firstError = radio;
                    }

                }else{

                    const radio = form.querySelector(`[name="${CSS.escape(name)}"]`);

                    clearQuestionError(radio);

                }

            });

            //------------------------
            // Alasan wajib jika kinerja=3
            //------------------------

            form.querySelectorAll(".kinerja-radio:checked").forEach(radio=>{

                const nilai = parseInt(radio.value);

                if(!(nilai <5 && nilai > 0)) return;

                const card = radio.closest("[x-data]");
                const textarea = card.querySelector(".alasan-textarea");

                if(textarea.value.trim() === ""){
                    valid = false;
                    textarea.classList.add("border-red-500");
                    setQuestionError(textarea);

                    if(!firstError){
                        firstError = textarea;
                    }
                }

            });
            form.querySelectorAll(".essay-textarea").forEach(textarea => {

                if(textarea.value.trim() === ""){

                    valid = false;

                    textarea.classList.add("border-red-500");

                    setQuestionError(textarea);

                    if(!firstError){
                        firstError = textarea;
                    }

                }else{

                    textarea.classList.remove("border-red-500");

                    clearQuestionError(textarea);

                }

            });

            if(!valid){

                e.preventDefault();

                alert("Masih ada data yang belum diisi.");

                firstError.scrollIntoView({

                    behavior:"smooth",

                    block:"center"

                });

                firstError.focus();

            }

    });
    document.addEventListener("input",function(e){

        if(e.target.classList.contains("alasan-textarea")){

            if(e.target.value.trim() !== ""){

                e.target.classList.remove("border-red-500");
                clearQuestionError(e.target);

            }

        }
         if(
            e.target.classList.contains("alasan-textarea") ||
            e.target.classList.contains("essay-textarea")
        ){

            if(e.target.value.trim() !== ""){

                e.target.classList.remove("border-red-500");
                clearQuestionError(e.target);

            }

        }

    });
    function setQuestionError(element, error = true) {
        const card = element.closest(".question-card");
        if (!card) return;
        card.classList.toggle("border-red-500", error);
        card.classList.toggle("bg-red-50", error);
    }
    function clearQuestionError(element) {
        setQuestionError(element, false);
    }
</script>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/show/penilaian_pelanggan_1-7.blade.php ENDPATH**/ ?>