<div class="space-y-6">

    <?php echo $__env->make(
        'admin.units.question.partials.forms.description',
        ['form' => $form]
    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make(
        'admin.units.question.partials.forms.question-list',
        ['form' => $form]
    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->make(
        'admin.units.question.partials.forms.toolbar',
        [
            'form' => $form
        ]
    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/ranking-1-3/index.blade.php ENDPATH**/ ?>