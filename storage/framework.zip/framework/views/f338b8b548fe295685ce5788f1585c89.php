<template id="engagementAssessment17TypeOptions">

     <option
        value="1"
    >
        Judul Pertanyaan
    </option>

    <option
        value="2"
    >
        Pertanyaan
    </option>

</template><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/templates/forms/engagement-assessment-1-7.blade.php ENDPATH**/ ?>