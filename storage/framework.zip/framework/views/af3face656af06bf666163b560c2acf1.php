

<?php $__env->startSection('title', 'Unit & Input Pertanyaan'); ?>

<?php $__env->startSection('content'); ?>

<div
    id="unitMainPage"
    class="mx-auto max-w-[1600px] space-y-6"
>
    
    
    
    <div
        class="rounded-xl border border-gray-200
            bg-white p-6 shadow-sm"
    >
        <div
            class="flex flex-col gap-5
                lg:flex-row lg:items-center lg:justify-between"
        >
            <div>
                <a
                    href="<?php echo e(route('admin.groups', [
                        'id' => $groups->activity_id,
                    ])); ?>"
                    class="mb-3 inline-flex items-center gap-2
                        text-sm font-medium text-blue-600
                        transition hover:text-blue-700"
                >
                    <i class="fa-solid fa-arrow-left"></i>
                    Kembali Ke Group
                </a>

                <h1 class="text-2xl font-bold text-gray-900">
                    Unit & Pertanyaan
                </h1>

                <p class="mt-1 text-sm text-gray-500">
                    Pengaturan Unit dan Input Pertanyaan
                    dari Group

                    <span class="font-semibold text-gray-800">
                        <?php echo e($groups->name); ?>

                    </span>
                </p>
            </div>

            <div class="flex flex-wrap items-center gap-3">
                <div
                    class="min-w-[130px] rounded-xl
                        bg-indigo-50 px-5 py-4"
                >
                    <p
                        class="text-xs font-medium uppercase
                            tracking-wide text-indigo-500"
                    >
                        Group
                    </p>

                    <p class="mt-1 font-semibold text-indigo-700">
                        <?php echo e($groups->name); ?>

                    </p>
                </div>

                <div
                    class="min-w-[130px] rounded-xl
                        bg-blue-50 px-5 py-4"
                >
                    <p
                        class="text-xs font-medium uppercase
                            tracking-wide text-blue-500"
                    >
                        Jumlah Unit
                    </p>

                    <p class="mt-1 text-xl font-bold text-blue-700">
                        <?php echo e($units->count()); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>

    
    
    
    <div
        class="overflow-hidden rounded-xl
            border border-gray-200 bg-white shadow-sm"
    >
        
        <div class="border-b border-gray-200 bg-gray-50">
            <nav
                id="unitTabs"
                class="flex flex-wrap items-center"
                data-tabs
            >
                <button
                    type="button"
                    data-unit-tab="unit"
                    class="unit-tab-button inline-flex items-center gap-2
                        border-b-2 border-blue-600 px-6 py-4
                        text-sm font-semibold text-blue-600 transition"
                >
                    <i class="fa-solid fa-building"></i>
                    Data Unit
                </button>

                <button
                    type="button"
                    data-unit-tab="question"
                    class="unit-tab-button inline-flex items-center gap-2
                        border-b-2 border-transparent px-6 py-4
                        text-sm font-semibold text-gray-600 transition
                        hover:border-gray-300 hover:text-gray-800"
                >
                    <i class="fa-solid fa-list-check"></i>
                    Pertanyaan
                </button>
            </nav>
        </div>

        
        <div class="p-5">
            <div
                id="tab-unit"
                data-unit-tab-content="unit"
            >
                <?php echo $__env->make('admin.units.pages.units-data', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div
                id="tab-question"
                data-unit-tab-content="question"
                class="hidden"
            >
                <?php echo $__env->make('admin.units.pages.question', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </div>
</div>




<?php echo $__env->make('admin.units.units.modals.bulk-deleted', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.units.modals.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.units.modals.delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.units.modals.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<?php echo $__env->make('admin.units.question.modals.create-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.edit-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.delete-form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<?php echo $__env->make('admin.units.question.modals.create-question', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.edit-question', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.delete-question', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<?php echo $__env->make('admin.units.question.modals.create-option', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.edit-option', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.delete-option', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<?php echo $__env->make('admin.units.question.modals.create-description', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.edit-description', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.delete-description', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<?php echo $__env->make('admin.units.question.modals.create-competitor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.edit-competitor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.units.question.modals.delete-competitor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>




<?php echo $__env->make('admin.units.question.modals.import-question', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('templates'); ?>

    
    <?php echo $__env->make('admin.units.units.templates.create-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.units.question.templates.create-competitor-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.units.question.templates.create-form-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.units.question.templates.create-question-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.units.question.templates.create-option-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    
    <?php echo $__env->make('admin.units.question.templates.forms.general-questionnaire', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.customer-assessment-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.customer-assessment-1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.engagement-assessment-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.engagement-assessment-1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.ranking-1-3', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.ranking-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.strength-complaint-suggestion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.complaint-suggestion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.suggestion', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.competitor-1-5', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.units.question.templates.forms.competitor-1-7', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/index.blade.php ENDPATH**/ ?>