<div class="space-y-5">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $group->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionTypeId = (int) (
                    $question->questiontype_id
                    ?? $question->id_questiontypes
                    ?? 0
                );
            ?>

            <?php if($questionTypeId === 1): ?>
                <div class="rounded-lg border border-indigo-200 bg-indigo-50 p-4">
                    <div class="flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            compact('question')
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <h3 class="font-semibold text-gray-800">
                            <?php echo e($question->name); ?>

                        </h3>
                    </div>
                </div>
            <?php else: ?>
                <div class="rounded-lg border border-gray-200 bg-white p-5">
                    <div class="mb-4 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            compact('question')
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div class="font-medium text-gray-800">
                            <?php echo e($question->name); ?>

                        </div>
                    </div>

                    <textarea
                        rows="4"
                        class="w-full rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 text-sm"
                        placeholder="Tuliskan saran Anda..."
                    ></textarea>
                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make('admin.subunit.show-question.partials.empty', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/forms/suggestions.blade.php ENDPATH**/ ?>