<div class="flex flex-wrap items-center gap-3 border-t border-gray-200 pt-5">

    
    <?php if((int) $form->formtype_id !== 12): ?>

        <button
            type="button"
            data-modal-open="createQuestionModal"
            data-group-id="<?php echo e($form->group_id); ?>"
            data-form-id="<?php echo e($form->id); ?>"
            data-form-name="<?php echo e($form->name); ?>"
            data-form-type-id="<?php echo e($form->formtype_id); ?>"
            data-action="<?php echo e(route('question.store')); ?>"
            class="inline-flex items-center gap-2 rounded-lg
                   bg-green-600 px-4 py-2 text-sm font-medium
                   text-white transition hover:bg-green-700"
        >
            <i class="fa-solid fa-plus"></i>
            Tambah Pertanyaan
        </button>

        <a
            href="<?php echo e(route('question.template', [
                'formId' => $form->id,
            ])); ?>"
            class="inline-flex items-center gap-2 rounded-lg
                   bg-emerald-600 px-4 py-2 text-sm font-medium
                   text-white transition hover:bg-emerald-700"
        >
            <i class="fa-solid fa-file-excel"></i>
            Download Template
        </a>

        <button
            type="button"
            data-modal-open="importQuestionModal"
            data-group-id="<?php echo e($form->group_id); ?>"
            data-form-id="<?php echo e($form->id); ?>"
            data-form-name="<?php echo e($form->name); ?>"
            data-form-type-id="<?php echo e($form->formtype_id); ?>"
            data-action="<?php echo e(route('question.import', [
                'formId' => $form->id,
            ])); ?>"
            class="inline-flex items-center gap-2 rounded-lg
                bg-blue-600 px-4 py-2 text-sm font-medium
                text-white transition hover:bg-blue-700"
        >
            <i class="fa-solid fa-file-import"></i>
            Import Pertanyaan
        </button>

    <?php endif; ?>


    
    <?php if((int) $form->formtype_id === 11): ?>

        <button
            type="button"
            data-modal-open="createCompetitorModal"
            data-group-id="<?php echo e($form->group_id); ?>"
            data-form-id="<?php echo e($form->id); ?>"
            data-form-name="<?php echo e($form->name); ?>"
            data-action="<?php echo e(route('competitor.store')); ?>"
            class="inline-flex items-center gap-2 rounded-lg
                   bg-violet-600 px-4 py-2 text-sm font-medium
                   text-white transition hover:bg-violet-700"
        >
            <i class="fa-solid fa-building-circle-check"></i>
            Tambah Kompetitor
        </button>

    <?php endif; ?>


    
    <?php if(!$form->description): ?>

        <button
            type="button"
            data-modal-open="createDescriptionModal"
            data-group-id="<?php echo e($form->group_id); ?>"
            data-form-id="<?php echo e($form->id); ?>"
            data-form-name="<?php echo e($form->name); ?>"
            class="inline-flex items-center gap-2 rounded-lg
                   bg-emerald-600 px-4 py-2 text-sm font-medium
                   text-white transition hover:bg-emerald-700"
        >
            <i class="fa-solid fa-file-lines"></i>
            Tambah Description
        </button>

    <?php endif; ?>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/toolbar.blade.php ENDPATH**/ ?>