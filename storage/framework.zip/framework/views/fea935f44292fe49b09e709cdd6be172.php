<?php
    $feedbackColumnClass = match (
        count($feedbackFields)
    ) {
        3 => 'lg:grid-cols-3',
        2 => 'lg:grid-cols-2',
        default => 'grid-cols-1',
    };
?>

<div class="space-y-6">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $questionGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $questionGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionTypeId =
                    (int) $question->questiontype_id;

                $questionNumber = trim(
                    ($question->no_header ?? '') .
                    ($question->no ?? '')
                );

                $activeSubunitIds = collect(
                    $activeMapSubUnit[
                        $form->id . '-' . $question->id
                    ] ?? []
                )
                    ->map(fn ($id) => (int) $id)
                    ->unique()
                    ->values();
            ?>

            
            <?php if($questionTypeId === 1): ?>
                <div
                    class="rounded-xl border border-indigo-200
                           bg-indigo-50 px-6 py-5"
                >
                    <div class="flex items-start gap-4">
                        <span
                            class="inline-flex h-11 w-11
                                   shrink-0 items-center
                                   justify-center rounded-xl
                                   bg-indigo-100 text-indigo-600"
                        >
                            <i class="fa-solid fa-comments"></i>
                        </span>

                        <div>
                            <div
                                class="text-xs font-semibold
                                       uppercase tracking-wide
                                       text-indigo-500"
                            >
                                Petunjuk Pertanyaan
                            </div>

                            <h2
                                class="mt-1 text-lg font-bold
                                       text-gray-900"
                            >
                                <?php echo e($question->name); ?>

                            </h2>
                        </div>
                    </div>
                </div>

                <?php continue; ?>
            <?php endif; ?>

            
            <?php if($questionTypeId !== 2) continue; ?>
            <?php if($activeSubunitIds->isEmpty()) continue; ?>

            <section
                class="overflow-hidden rounded-xl
                       border border-gray-200
                       bg-white shadow-sm"
            >
                <?php $__currentLoopData = $activeSubunitIds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunitId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $subunit = $subunits->firstWhere(
                            'id',
                            $subunitId
                        );

                        $storedAnswer = data_get(
                            $answerMap,
                            "{$question->id}.{$subunitId}.0",
                            []
                        );
                    ?>

                    <?php if(!$subunit) continue; ?>

                    <div
                        data-question-container
                        data-question-id="<?php echo e($question->id); ?>"
                        data-subunit-id="<?php echo e($subunitId); ?>"
                        class="border border-gray-200 bg-white
                               first:border-0"
                    >
                        
                        <div
                            class="flex items-center gap-3
                                   border-b border-blue-200
                                   bg-blue-50 px-5 py-4"
                        >
                            <span
                                class="inline-flex h-10 w-10
                                       shrink-0 items-center
                                       justify-center rounded-lg
                                       bg-blue-100 text-blue-600"
                            >
                                <i class="fa-solid fa-building"></i>
                            </span>

                            <div>
                                <div
                                    class="text-xs font-semibold
                                           uppercase tracking-wide
                                           text-blue-600"
                                >
                                    Sub Unit
                                </div>

                                <div
                                    class="font-bold text-gray-900"
                                >
                                    <?php echo e($subunit->name); ?>

                                </div>
                            </div>
                        </div>

                        <div class="p-5">
                            
                            <div
                                class="mb-5 flex items-start gap-3
                                       rounded-xl border
                                       border-gray-200
                                       bg-white px-5 py-4"
                            >
                                <span
                                    class="inline-flex h-9 min-w-9
                                           shrink-0 items-center
                                           justify-center rounded-lg
                                           bg-indigo-100 px-2
                                           text-sm font-semibold
                                           text-indigo-700"
                                >
                                    <?php echo e($questionNumber); ?>

                                </span>

                                <div>
                                    <h3
                                        class="font-semibold
                                               leading-relaxed
                                               text-gray-900"
                                    >
                                        <?php echo e($question->name); ?>

                                    </h3>

                                    <p
                                        class="mt-1 text-xs
                                               text-gray-500"
                                    >
                                        Lengkapi seluruh bagian
                                        jawaban di bawah ini.
                                    </p>
                                </div>
                            </div>

                            
                            <div
                                class="grid grid-cols-1
                                       items-stretch gap-4
                                       <?php echo e($feedbackColumnClass); ?>"
                            >
                                <?php $__currentLoopData = $feedbackFields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $fieldKey =
                                            $field['key'];

                                        $fieldValue = old(
                                            "answers.{$question->id}.{$subunitId}.{$fieldKey}",
                                            data_get(
                                                $storedAnswer,
                                                $fieldKey
                                            )
                                        );
                                    ?>

                                    <div
                                        class="flex h-full flex-col
                                               rounded-xl border p-4
                                               <?php echo e($field['wrapperClass']); ?>"
                                    >
                                        <label
                                            for="feedback-<?php echo e($question->id); ?>-<?php echo e($subunitId); ?>-<?php echo e($fieldKey); ?>"
                                            class="mb-3 flex items-center
                                                   gap-2 font-semibold
                                                   <?php echo e($field['labelClass']); ?>"
                                        >
                                            <i
                                                class="<?php echo e($field['icon']); ?>"
                                            ></i>

                                            <?php echo e($field['label']); ?>

                                        </label>

                                        <textarea
                                            id="feedback-<?php echo e($question->id); ?>-<?php echo e($subunitId); ?>-<?php echo e($fieldKey); ?>"
                                            name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][<?php echo e($fieldKey); ?>]"
                                            rows="5"
                                            required
                                            maxlength="5000"
                                            placeholder="<?php echo e($field['placeholder']); ?>"
                                            class="min-h-32 w-full flex-1
                                                   resize-y rounded-lg
                                                   border border-gray-300
                                                   bg-white px-4 py-3
                                                   text-sm outline-none
                                                   transition
                                                   focus:ring-2
                                                   <?php echo e($field['focusClass']); ?>"
                                        ><?php echo e($fieldValue); ?></textarea>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>

                            
                            <p
                                data-question-error
                                class="mt-3 hidden text-sm
                                       font-medium text-red-600"
                            >
                                Seluruh bagian jawaban wajib diisi.
                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make(
            'user.survey.partials.empty',
            [
                'message' =>
                    'Form ini belum memiliki pertanyaan aktif.',
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/partials/feedback-assessment.blade.php ENDPATH**/ ?>