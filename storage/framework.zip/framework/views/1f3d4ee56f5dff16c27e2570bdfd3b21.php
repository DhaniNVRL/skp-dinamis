<?php
    $perSubUnitFormTypes = [
        2,
        3,
        8,
        9,
        10,
    ];

    $globalFormTypes = [
        1,
        4,
        5,
        6,
        7,
        11,
        12,
        13,
    ];

    $formTypeId = (int) (
        $form->formtype_id
        ?? $form->id_formtype
        ?? 0
    );

    $isPerSubUnit = in_array(
        $formTypeId,
        $perSubUnitFormTypes,
        true
    );

    $isGlobal = in_array(
        $formTypeId,
        $globalFormTypes,
        true
    );
?>

<div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
    
    <div class="border-b border-gray-200 bg-gray-50 px-5 py-4">
        <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
                <h3 class="text-lg font-semibold text-gray-800">
                    <?php echo e($form->name); ?>

                </h3>

                <p class="mt-1 text-sm text-gray-500">
                    <?php echo e($form->formtype->name ?? 'Tanpa tipe form'); ?>

                </p>
            </div>

            <span
                class="inline-flex w-fit items-center rounded-full px-3 py-1 text-xs font-semibold
                    <?php echo e($isPerSubUnit
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-purple-100 text-purple-700'); ?>"
            >
                <?php if($isPerSubUnit): ?>
                    <i class="fa-solid fa-building mr-2"></i>
                    Per Sub Unit
                <?php else: ?>
                    <i class="fa-solid fa-layer-group mr-2"></i>
                    Pertanyaan Global
                <?php endif; ?>
            </span>
        </div>
    </div>

    
    <div class="space-y-4 p-5">
        <?php $__empty_1 = true; $__currentLoopData = $form->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php echo $__env->make(
                'admin.subunit.hide-and-show.partials.question-card',
                [
                    'form' => $form,
                    'question' => $question,
                    'allSubunits' => $allSubunits,
                    'activeMapSubUnit' => $activeMapSubUnit,
                    'isPerSubUnit' => $isPerSubUnit,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="rounded-lg border border-dashed border-gray-300 px-5 py-8 text-center text-sm text-gray-500">
                Form ini belum memiliki pertanyaan.
            </div>
        <?php endif; ?>
    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/hide-and-show/partials/form-card.blade.php ENDPATH**/ ?>