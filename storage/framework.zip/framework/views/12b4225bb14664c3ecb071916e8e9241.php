<?php $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noHeader => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $group->where('questiontype_id',2)->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $key = $form->id.'-'.$question->id;
            $subQuestions = $activeMapSubUnit[$key] ?? [];
        ?>
        <?php if(empty($subQuestions)) continue; ?>
        <div class="question-card mb-6 bg-white border rounded-xl shadow-sm p-5">

            <div class="font-semibold text-gray-800 mb-4">
                <?php echo e($question->no_header); ?><?php echo e($question->no); ?>.
                <?php echo e($question->name); ?>

            </div><?php $__currentLoopData = $subQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunitId): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    $subunit = $subunits->firstWhere('id', $subunitId);
                ?>

                <?php if(!$subunit) continue; ?>

                <?php
                    $answerKey = $question->id.'-'.$subunitId.'-0';
                    $current = $answerMap->get($answerKey, []);
                ?>

                <div class="border rounded-lg p-4 mb-4">
                    <div class="font-bold text-blue-700 mb-3">
                        <?php echo e($subunit->name); ?>

                    </div>

                    <textarea
                        name="answers[<?php echo e($question->id); ?>][<?php echo e($subunitId); ?>][saran]"
                        rows="6"
                        class="survey-textarea w-full border rounded-lg p-3"
                        placeholder="Masukkan saran..."><?php echo e($current['saran'] ?? ''); ?></textarea>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
document.addEventListener("DOMContentLoaded", function () {

    const form = document.getElementById("surveyForm");

    if (!form) return;

    //-------------------------------------
    // VALIDASI SATU CARD
    //-------------------------------------
    function validateCard(card){

        let hasError = false;

        card.querySelectorAll(".survey-textarea").forEach(textarea=>{

            if(textarea.value.trim()===""){

                hasError = true;

            }

        });

        card.classList.toggle("border-red-500", hasError);
        card.classList.toggle("bg-red-50", hasError);

    }

    //-------------------------------------
    // SUBMIT
    //-------------------------------------
    form.addEventListener("submit",function(e){

        let valid = true;
        let firstError = null;

        document.querySelectorAll(".question-card").forEach(card=>{

            card.querySelectorAll(".survey-textarea").forEach(textarea=>{

                if(textarea.value.trim()===""){

                    valid = false;

                    textarea.classList.add("border-red-500");

                    if(!firstError){

                        firstError = textarea;

                    }

                }else{

                    textarea.classList.remove("border-red-500");

                }

            });

            validateCard(card);

        });

        if(!valid){

            e.preventDefault();

            alert("Masih ada data yang belum diisi.");

            firstError.scrollIntoView({

                behavior:"smooth",

                block:"center"

            });

            firstError.focus();

        }

    });

    //-------------------------------------
    // HILANGKAN MERAH SAAT MENGETIK
    //-------------------------------------
    document.addEventListener("input",function(e){

        if(!e.target.classList.contains("survey-textarea")) return;

        if(e.target.value.trim()!==""){

            e.target.classList.remove("border-red-500");

        }

        validateCard(e.target.closest(".question-card"));

    });

});
</script>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/show/saran.blade.php ENDPATH**/ ?>