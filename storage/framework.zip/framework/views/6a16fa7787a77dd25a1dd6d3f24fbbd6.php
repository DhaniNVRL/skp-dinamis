<?php echo $__env->make(
    'user.survey.forms.partials.ranking-assessment',
    [
        'maximumRank' => 3,
    ]
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/ranking-1-3.blade.php ENDPATH**/ ?>