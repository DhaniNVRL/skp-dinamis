<div class="space-y-6">
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header => $questionGroup): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $questionGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionTypeId =
                    (int) $question->questiontype_id;

                $questionNumber = trim(
                    ($question->no_header ?? '') .
                    ($question->no ?? '')
                );

                $storedAnswer = data_get(
                    $answerMap,
                    "{$question->id}.0.0",
                    []
                );

                $storedRankings = old(
                    "answers.{$question->id}.value",
                    data_get(
                        $storedAnswer,
                        'value',
                        []
                    )
                );
            ?>

            
            <?php if($questionTypeId === 1): ?>
                <div
                    class="rounded-xl border border-indigo-200
                           bg-indigo-50 px-6 py-5"
                >
                    <div class="flex items-start gap-4">
                        <span
                            class="inline-flex h-11 w-11
                                   shrink-0 items-center justify-center
                                   rounded-xl bg-indigo-100
                                   text-indigo-600"
                        >
                            <i class="fa-solid fa-ranking-star"></i>
                        </span>

                        <div>
                            <div
                                class="text-xs font-semibold uppercase
                                       tracking-wide text-indigo-500"
                            >
                                Petunjuk Ranking
                            </div>

                            <h2
                                class="mt-1 text-lg font-bold
                                       text-gray-900"
                            >
                                <?php echo e($question->name); ?>

                            </h2>
                        </div>
                    </div>
                </div>

                <?php continue; ?>
            <?php endif; ?>

            
            <?php if($questionTypeId === 2): ?>
                <div
                    data-question-container
                    data-ranking-container
                    data-question-id="<?php echo e($question->id); ?>"
                    class="overflow-hidden rounded-xl
                           border border-gray-200
                           bg-white shadow-sm"
                >
                    
                    <div
                        class="border-b border-gray-200
                               px-5 py-4"
                    >
                        <div class="flex items-start gap-3">
                            <span
                                class="inline-flex h-9 min-w-9
                                       shrink-0 items-center
                                       justify-center rounded-lg
                                       bg-indigo-100 px-2
                                       text-sm font-semibold
                                       text-indigo-700"
                            >
                                <?php echo e($questionNumber); ?>

                            </span>

                            <div>
                                <h3
                                    class="font-semibold leading-relaxed
                                           text-gray-900"
                                >
                                    <?php echo e($question->name); ?>

                                </h3>

                                <p class="mt-1 text-xs text-gray-500">
                                    Tentukan urutan Ranking 1 sampai
                                    Ranking <?php echo e($maximumRank); ?>.
                                </p>
                            </div>
                        </div>
                    </div>

                    
                    <div class="p-5">
                        <div
                            class="grid grid-cols-1 gap-4
                                   md:grid-cols-2
                                   xl:grid-cols-<?php echo e(min($maximumRank, 3)); ?>"
                        >
                            <?php for(
                                $rank = 1;
                                $rank <= $maximumRank;
                                $rank++
                            ): ?>
                                <?php
                                    $selectedOptionId = data_get(
                                        $storedRankings,
                                        "{$rank}.option_id"
                                    );

                                    $selectedChild = data_get(
                                        $storedRankings,
                                        "{$rank}.child",
                                        ''
                                    );

                                    $selectedOption = $question
                                        ->options
                                        ->firstWhere(
                                            'id',
                                            (int) $selectedOptionId
                                        );

                                    $selectedHasChild =
                                        $selectedOption &&
                                        (int) $selectedOption->has_child === 1;
                                ?>

                                <div
                                    data-ranking-row
                                    class="rounded-xl border
                                           border-gray-200
                                           bg-gray-50 p-4"
                                >
                                    <label
                                        for="ranking-<?php echo e($question->id); ?>-<?php echo e($rank); ?>"
                                        class="mb-2 block text-sm
                                               font-semibold text-gray-800"
                                    >
                                        Ranking <?php echo e($rank); ?>

                                    </label>

                                    <div class="relative">
                                        <select
                                            id="ranking-<?php echo e($question->id); ?>-<?php echo e($rank); ?>"
                                            name="answers[<?php echo e($question->id); ?>][value][<?php echo e($rank); ?>][option_id]"
                                            required
                                            data-ranking-select
                                            class="w-full appearance-none
                                                   rounded-lg border
                                                   border-gray-300 bg-white
                                                   px-4 py-3 pr-10
                                                   text-sm outline-none
                                                   focus:border-indigo-500
                                                   focus:ring-2
                                                   focus:ring-indigo-100"
                                        >
                                            <option value="">
                                                Pilih Ranking <?php echo e($rank); ?>

                                            </option>

                                            <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option
                                                    value="<?php echo e($option->id); ?>"
                                                    data-has-child="<?php echo e((int) $option->has_child === 1 ? '1' : '0'); ?>"
                                                    <?php if(
                                                        (string) $selectedOptionId ===
                                                        (string) $option->id
                                                    ): echo 'selected'; endif; ?>
                                                >
                                                    <?php echo e($option->answer_text); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                        <span
                                            class="pointer-events-none
                                                   absolute inset-y-0 right-0
                                                   flex items-center pr-4
                                                   text-gray-400"
                                        >
                                            <i class="fa-solid fa-chevron-down"></i>
                                        </span>
                                    </div>

                                    
                                    <div
                                        data-ranking-child
                                        class="<?php echo e($selectedHasChild ? '' : 'hidden'); ?>

                                               mt-4"
                                    >
                                        <?php if(
                                            filled(
                                                $selectedOption?->answer_text2
                                            )
                                        ): ?>
                                            <label
                                                data-ranking-child-label
                                                class="mb-2 block text-sm
                                                       font-medium text-gray-700"
                                            >
                                                <?php echo e($selectedOption->answer_text2); ?>

                                            </label>
                                        <?php else: ?>
                                            <label
                                                data-ranking-child-label
                                                class="mb-2 block text-sm
                                                       font-medium text-gray-700"
                                            >
                                                Jawaban tambahan
                                            </label>
                                        <?php endif; ?>

                                        <textarea
                                            name="answers[<?php echo e($question->id); ?>][value][<?php echo e($rank); ?>][child]"
                                            rows="3"
                                            data-ranking-child-input
                                            <?php if($selectedHasChild): echo 'required'; endif; ?>
                                            <?php if(!$selectedHasChild): echo 'disabled'; endif; ?>
                                            placeholder="Tulis jawaban tambahan..."
                                            class="w-full rounded-lg
                                                   border border-gray-300
                                                   bg-white px-4 py-3
                                                   text-sm outline-none
                                                   focus:border-indigo-500
                                                   focus:ring-2
                                                   focus:ring-indigo-100"
                                        ><?php echo e($selectedChild); ?></textarea>
                                    </div>
                                </div>
                            <?php endfor; ?>
                        </div>

                        <div
                            class="mt-5 rounded-lg border
                                   border-blue-200 bg-blue-50
                                   px-4 py-3 text-sm text-blue-700"
                        >
                            <div class="flex items-start gap-2">
                                <i
                                    class="fa-solid fa-circle-info
                                           mt-0.5"
                                ></i>

                                <div>
                                    Pilihan biasa hanya dapat digunakan
                                    satu kali. Pilihan yang memiliki
                                    jawaban tambahan dapat digunakan
                                    lebih dari satu kali.
                                </div>
                            </div>
                        </div>

                        <p
                            data-question-error
                            class="mt-3 hidden text-sm
                                   font-medium text-red-600"
                        >
                            Seluruh urutan Ranking wajib dipilih.
                        </p>
                    </div>
                </div>

                <?php continue; ?>
            <?php endif; ?>

            <div
                class="rounded-xl border border-red-200
                       bg-red-50 p-4 text-sm text-red-600"
            >
                Question Type <?php echo e($questionTypeId); ?>

                belum didukung pada Form Ranking.
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make(
            'user.survey.partials.empty',
            [
                'message' =>
                    'Form Ranking belum memiliki pertanyaan aktif.',
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/partials/ranking-assessment.blade.php ENDPATH**/ ?>