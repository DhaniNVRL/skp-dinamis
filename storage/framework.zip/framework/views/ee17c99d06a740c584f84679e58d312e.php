

<?php $__env->startSection('title', 'Dashboard Responden'); ?>

<?php $__env->startSection('content'); ?>
<?php
    $profile = $profile ?? null;
    $surveySession = $surveySession ?? null;
    $user = $user ?? auth()->user();

    $profileComplete = $profile
        && filled($profile->activity_id)
        && filled($profile->group_id)
        && filled($profile->unit_id);

    $status = $surveySession?->status ?? 'not_started';

    $statusLabel = match ($status) {
        'in_progress' => 'Sedang Berjalan',
        'completed' => 'Selesai',
        default => 'Belum Mulai',
    };

    $statusClass = match ($status) {
        'in_progress' => 'border-amber-200 bg-amber-50 text-amber-700',
        'completed' => 'border-green-200 bg-green-50 text-green-700',
        default => 'border-gray-200 bg-gray-100 text-gray-700',
    };
?>

<div class="mx-auto max-w-6xl space-y-6">

    
    <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">
        <div class="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">

            <div class="flex items-center gap-4">
                <div class="flex h-16 w-16 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                    <i class="fa-solid fa-user text-2xl"></i>
                </div>

                <div>
                    <h1 class="text-2xl font-bold text-gray-900">
                        Profil Responden
                    </h1>

                    <p class="mt-1 text-sm text-gray-500">
                        Informasi pekerjaan dan status survei Anda.
                    </p>
                </div>
            </div>

            <?php if(!$profileComplete): ?>
                <a
                    href="<?php echo e(route('profile.edit')); ?>"
                    class="inline-flex items-center justify-center gap-2 rounded-lg
                           bg-blue-600 px-5 py-2.5 text-sm font-semibold text-white
                           transition hover:bg-blue-700"
                >
                    <i class="fa-solid fa-pen-to-square"></i>
                    Lengkapi Profil
                </a>
            <?php else: ?>
                <button
                    type="button"
                    disabled
                    title="Profil sudah lengkap"
                    class="inline-flex cursor-not-allowed items-center justify-center gap-2
                           rounded-lg bg-gray-200 px-5 py-2.5 text-sm font-semibold
                           text-gray-400"
                >
                    <i class="fa-solid fa-circle-check"></i>
                    Profil Lengkap
                </button>
            <?php endif; ?>
        </div>
    </div>

    <?php if(session('success')): ?>
        <div class="rounded-xl border border-green-200 bg-green-50 px-5 py-4 text-sm text-green-700">
            <i class="fa-solid fa-circle-check mr-2"></i>
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="rounded-xl border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700">
            <i class="fa-solid fa-circle-exclamation mr-2"></i>
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="grid grid-cols-1 gap-6 lg:grid-cols-3">

        
        <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm lg:col-span-2">

            <div class="border-b border-gray-200 px-6 py-5">
                <h2 class="text-lg font-semibold text-gray-900">
                    Informasi Responden
                </h2>

                <p class="mt-1 text-sm text-gray-500">
                    Informasi aktivitas, bidang kerja, dan unit responden.
                </p>
            </div>

            <div class="divide-y divide-gray-200">

                
                <div class="flex items-center gap-4 px-6 py-5">
                    <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-purple-100 text-purple-600">
                        <i class="fa-solid fa-briefcase"></i>
                    </div>

                    <div>
                        <div class="text-sm text-gray-500">
                            Aktivitas
                        </div>

                        <div class="mt-1 font-semibold text-gray-900">
                            <?php echo e($profile?->activity?->name ?? '-'); ?>

                        </div>
                    </div>
                </div>

                
                <div class="flex items-center gap-4 px-6 py-5">
                    <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-indigo-100 text-indigo-600">
                        <i class="fa-solid fa-layer-group"></i>
                    </div>

                    <div>
                        <div class="text-sm text-gray-500">
                            Bidang Kerja / Group
                        </div>

                        <div class="mt-1 font-semibold text-gray-900">
                            <?php echo e($profile?->group?->name ?? '-'); ?>

                        </div>
                    </div>
                </div>

                
                <div class="flex items-center gap-4 px-6 py-5">
                    <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-blue-100 text-blue-600">
                        <i class="fa-solid fa-building"></i>
                    </div>

                    <div>
                        <div class="text-sm text-gray-500">
                            Unit / Jabatan
                        </div>

                        <div class="mt-1 font-semibold text-gray-900">
                            <?php echo e($profile?->unit?->name ?? '-'); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="rounded-xl border border-gray-200 bg-white p-6 shadow-sm">

            <div class="flex items-start justify-between gap-3">
                <h2 class="text-lg font-semibold text-gray-900">
                    Status Survei
                </h2>

                <span class="inline-flex items-center gap-2 rounded-full border px-3 py-1 text-xs font-semibold <?php echo e($statusClass); ?>">
                    <?php if($status === 'completed'): ?>
                        <i class="fa-solid fa-circle-check"></i>
                    <?php elseif($status === 'in_progress'): ?>
                        <i class="fa-solid fa-spinner"></i>
                    <?php else: ?>
                        <i class="fa-solid fa-clock"></i>
                    <?php endif; ?>

                    <?php echo e($statusLabel); ?>

                </span>
            </div>

            <p class="mt-5 text-sm text-gray-500">
                <?php if($status === 'completed'): ?>
                    Survei telah berhasil diselesaikan.
                <?php elseif($status === 'in_progress'): ?>
                    Pengisian survei belum selesai.
                <?php else: ?>
                    Responden belum memulai pengisian survei.
                <?php endif; ?>
            </p>

            <div class="my-6 border-t border-gray-200"></div>

            <div class="space-y-5">
                <div>
                    <div class="text-xs font-semibold uppercase tracking-wide text-gray-400">
                        Waktu Mulai
                    </div>

                    <div class="mt-1 text-sm font-medium text-gray-700">
                        <?php echo e($surveySession?->started_at?->format('d M Y H:i') ?? '-'); ?>

                    </div>
                </div>

                <div>
                    <div class="text-xs font-semibold uppercase tracking-wide text-gray-400">
                        Waktu Selesai
                    </div>

                    <div class="mt-1 text-sm font-medium text-gray-700">
                        <?php echo e($surveySession?->finished_at?->format('d M Y H:i') ?? '-'); ?>

                    </div>
                </div>
            </div>

            <div class="mt-7">
                <?php if(!$profileComplete): ?>
                    <button
                        type="button"
                        disabled
                        title="Lengkapi profil terlebih dahulu"
                        class="inline-flex w-full cursor-not-allowed items-center justify-center
                               gap-2 rounded-lg bg-gray-300 px-5 py-3 font-semibold
                               text-gray-500"
                    >
                        <i class="fa-solid fa-lock"></i>
                        Lengkapi Profil Dahulu
                    </button>

                    <p class="mt-2 text-center text-xs text-red-500">
                        Activity, group, dan unit wajib dilengkapi.
                    </p>
                <?php elseif($status === 'completed'): ?>
                    <button
                        type="button"
                        disabled
                        class="inline-flex w-full cursor-not-allowed items-center justify-center
                               gap-2 rounded-lg bg-green-100 px-5 py-3 font-semibold
                               text-green-600"
                    >
                        <i class="fa-solid fa-circle-check"></i>
                        Survei Selesai
                    </button>
                <?php elseif($status === 'in_progress'): ?>
                    <a
                        href="<?php echo e(route('survey.index')); ?>"
                        class="inline-flex w-full items-center justify-center gap-2
                               rounded-lg bg-amber-500 px-5 py-3 font-semibold
                               text-white transition hover:bg-amber-600"
                    >
                        <i class="fa-solid fa-arrow-right"></i>
                        Lanjutkan Survei
                    </a>
                <?php else: ?>
                    <a
                        href="<?php echo e(route('survey.index')); ?>"
                        class="inline-flex w-full items-center justify-center gap-2
                               rounded-lg bg-indigo-600 px-5 py-3 font-semibold
                               text-white transition hover:bg-indigo-700"
                    >
                        <i class="fa-solid fa-clipboard-list"></i>
                        Mulai Survei
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/dashboard.blade.php ENDPATH**/ ?>