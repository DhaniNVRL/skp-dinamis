

<?php $__env->startSection('title', 'Group & Complete Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="mx-auto max-w-[1600px] space-y-6">
    <?php echo $__env->make('admin.groups.groups.partials.page-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(session('success')): ?>
        <div data-alert class="flex items-center justify-between rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700"><span><i class="fa-solid fa-circle-check mr-2"></i><?php echo e(session('success')); ?></span><button type="button" data-alert-close><i class="fa-solid fa-xmark"></i></button></div>
    <?php endif; ?>
    <?php if(session('successdelete')): ?>
        <div data-alert class="flex items-center justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"><span><i class="fa-solid fa-trash mr-2"></i><?php echo e(session('successdelete')); ?></span><button type="button" data-alert-close><i class="fa-solid fa-xmark"></i></button></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div data-alert class="flex items-center justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700"><span><?php echo e(session('error')); ?></span><button type="button" data-alert-close><i class="fa-solid fa-xmark"></i></button></div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
        <div class="rounded-lg border border-red-200 bg-red-50 p-4 text-red-700"><p class="font-semibold">Data belum dapat diproses:</p><ul class="mt-2 list-disc pl-5 text-sm"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
    <?php endif; ?>

    <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="flex overflow-x-auto border-b border-gray-200 bg-gray-50">
            <button type="button" data-tab="group" class="tab-button whitespace-nowrap border-b-2 border-blue-600 bg-white px-6 py-4 text-sm font-semibold text-blue-600 transition"><i class="fa-solid fa-layer-group mr-2"></i>Data Group</button>
            <button type="button" data-tab="profile" class="tab-button whitespace-nowrap border-b-2 border-transparent px-6 py-4 text-sm font-semibold text-gray-500 transition hover:text-gray-700"><i class="fa-solid fa-clipboard-list mr-2"></i>Complete Profile</button>
        </div>
        <div class="p-5">
            <div id="tab-group"><?php echo $__env->make('admin.groups.pages.group-data', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
            <div id="tab-profile" class="hidden"><?php echo $__env->make('admin.groups.pages.complete-profile', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.groups.groups.modals.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.groups.groups.modals.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.groups.groups.modals.delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.groups.groups.modals.bulk-deleted', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.groups.complete-profile.modals.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.groups.complete-profile.modals.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.groups.complete-profile.modals.delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('templates'); ?>
    <?php echo $__env->make('admin.groups.groups.templates.create-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.groups.complete-profile.templates.create-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views//admin/groups/index.blade.php ENDPATH**/ ?>