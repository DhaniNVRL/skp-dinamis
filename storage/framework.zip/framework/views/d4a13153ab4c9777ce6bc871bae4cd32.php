<div class="space-y-6">
    <?php $__empty_1 = true; $__currentLoopData = $subunits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php ($subunitQuestions = $questions->filter(fn ($question) => in_array($subunit->id, $activeMapSubUnit[$form->id.'-'.$question->id] ?? [], true))); ?>
        <?php if($subunitQuestions->isNotEmpty()): ?>
            <section class="overflow-hidden rounded-xl border border-blue-200 bg-blue-50/40">
                <header class="border-b border-blue-200 bg-blue-50 px-5 py-4">
                    <div class="text-xs font-semibold uppercase tracking-wide text-blue-600">Sub Unit</div>
                    <h2 class="font-bold text-gray-900"><?php echo e($subunit->name); ?></h2>
                </header>
                <div class="space-y-4 p-5">
                    <?php $__currentLoopData = $subunitQuestions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if((int) $question->questiontype_id !== 1): ?>
                            <div class="rounded-xl border border-gray-200 bg-white p-5">
                                <div class="mb-4 flex items-start gap-3">
                                    <?php echo $__env->make('user.survey.partials.question-number', compact('question'), array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    <label for="answer-<?php echo e($question->id); ?>-<?php echo e($subunit->id); ?>" class="font-semibold text-gray-800"><?php echo e($question->name); ?></label>
                                </div>
                                <textarea id="answer-<?php echo e($question->id); ?>-<?php echo e($subunit->id); ?>" name="answers[<?php echo e($question->id); ?>][<?php echo e($subunit->id); ?>][value]" rows="3" required class="w-full rounded-lg border border-gray-300 px-4 py-3 outline-none focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100" placeholder="Tulis jawaban..."><?php echo e(old("answers.{$question->id}.{$subunit->id}.value", data_get($answerMap, $question->id.'.'.$subunit->id.'.0.value'))); ?></textarea>
                                <p data-field-error class="mt-2 hidden text-sm text-red-600">Pertanyaan ini wajib diisi.</p>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make('user.survey.partials.empty', ['message' => 'Unit Anda belum memiliki Sub Unit.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/partials/subunit-fields.blade.php ENDPATH**/ ?>