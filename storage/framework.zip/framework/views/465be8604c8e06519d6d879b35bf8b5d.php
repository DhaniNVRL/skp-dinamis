<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Login</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white rounded shadow-md w-full max-w-4xl flex flex-col md:flex-row overflow-hidden">

        <!-- Gambar (Hanya tampil di laptop/PC) -->
        <div class="hidden md:block md:w-1/2">
            <img src="<?php echo e(asset('images/login.png')); ?>"
                alt="Login Image"
                class="w-full h-full object-cover">
        </div>

        <!-- Form Login -->
        <div class="w-full md:w-1/2 p-8">
            <h2 class="text-2xl font-bold mb-6 text-center">Login</h2>

            <?php if(session('finish')): ?>
                <div
                    id="successAlert"
                    class="mb-6 flex items-start justify-between
                        rounded-lg border border-green-200
                        bg-green-50 px-4 py-3 text-green-700"
                >
                    <div class="flex items-start gap-3">
                        <div
                            class="mt-0.5 flex h-6 w-6
                                shrink-0 items-center
                                justify-center rounded-full
                                bg-green-100"
                        >
                            <svg
                                xmlns="http://www.w3.org/2000/svg"
                                viewBox="0 0 20 20"
                                fill="currentColor"
                                class="h-4 w-4"
                            >
                                <path
                                    fill-rule="evenodd"
                                    d="M16.704 4.153a.75.75 0 01.143 1.052l-8 10.5a.75.75 0 01-1.127.075l-4.5-4.5a.75.75 0 011.06-1.06l3.894 3.893 7.48-9.817a.75.75 0 011.05-.143z"
                                    clip-rule="evenodd"
                                />
                            </svg>
                        </div>

                        <div>
                            <div class="mt-1 text-sm">
                                <?php echo e(session('status')); ?>

                            </div>
                        </div>
                    </div>

                    <button
                        type="button"
                        onclick="document.getElementById('successAlert').remove()"
                        class="ml-4 text-green-500
                            transition hover:text-green-700"
                        aria-label="Tutup notifikasi"
                    >
                        <svg
                            xmlns="http://www.w3.org/2000/svg"
                            viewBox="0 0 20 20"
                            fill="currentColor"
                            class="h-5 w-5"
                        >
                            <path
                                d="M6.28 5.22a.75.75 0 00-1.06 1.06L8.94 10l-3.72 3.72a.75.75 0 101.06 1.06L10 11.06l3.72 3.72a.75.75 0 101.06-1.06L11.06 10l3.72-3.72a.75.75 0 00-1.06-1.06L10 8.94 6.28 5.22z"
                            />
                        </svg>
                    </button>
                </div>
            <?php endif; ?>

            <?php if(session('status')): ?>
                <div class="text-center mb-4 text-green-600">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

            <?php if($errors->any()): ?>
                <div class="text-center mb-4 text-red-600">
                    <ul class="list-disc pl-5">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <label class="block text-gray-700">Username</label>
                    <input type="username" name="username" value="<?php echo e(old('username')); ?>" required autofocus class="w-full px-4 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300">
                </div>

                <div class="mb-4">
                    <label class="block text-gray-700">Password</label>
                    <input type="password" name="password" required class="w-full px-4 py-2 border rounded focus:outline-none focus:ring focus:border-blue-300">
                </div>

                <div class="mb-4 flex items-center">
                    <input type="checkbox" name="remember" class="mr-2">
                    <label class="text-gray-700">Ingat saya</label>
                </div>

                <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600">
                    Login
                </button>

                <p class="mt-4 text-center text-sm text-gray-600">
                    Belum punya akun?
                    <a href="/register" class="text-blue-600 hover:underline font-semibold">Buat Akun</a>
                </p>
            </form>
        </div>
    </div>
</body>
</html>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/auth/login.blade.php ENDPATH**/ ?>