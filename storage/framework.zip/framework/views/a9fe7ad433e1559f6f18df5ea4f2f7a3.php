<div class="mb-6 overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">

    <div class="flex items-start justify-between gap-4 border-b border-gray-200 px-5 py-4">

        <div class="flex min-w-0 items-start gap-3">
            <span
                class="inline-flex min-w-10 shrink-0 items-center justify-center
                       rounded-lg bg-blue-100 px-2.5 py-1
                       text-sm font-semibold text-blue-700"
            >
                <?php echo e($question->no_header); ?><?php echo e($question->no); ?>

            </span>

            <div>
                <h4 class="font-semibold leading-6 text-gray-800">
                    <?php echo e($question->name); ?>

                </h4>

                <p class="mt-1 text-xs text-gray-500">
                    Penilaian Kepentingan & Kinerja
                </p>
            </div>
        </div>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.question-action',
            [
                'question' => $question,
                'form' => $form,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    </div>

    <div class="grid grid-cols-1 gap-5 p-5 lg:grid-cols-2">

        
        <div class="rounded-xl border border-blue-200 bg-blue-50/50 p-4">
            <h5 class="mb-4 text-center font-semibold text-blue-800">
                Kepentingan
            </h5>

            <div class="flex flex-wrap justify-center gap-3">
                <?php $__currentLoopData = [1, 2, 3, 4, 5, 6, 7, 0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label
                        class="inline-flex h-10 w-10 items-center justify-center
                               rounded-full border border-blue-300 bg-white
                               text-sm font-semibold text-blue-700"
                    >
                        <input
                            type="radio"
                            name="preview_kepentingan_<?php echo e($question->id); ?>"
                            value="<?php echo e($value); ?>"
                            class="sr-only"
                            disabled
                        >

                        <?php echo e($value); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        
        <div class="rounded-xl border border-emerald-200 bg-emerald-50/50 p-4">
            <h5 class="mb-4 text-center font-semibold text-emerald-800">
                Kinerja
            </h5>

            <div class="flex flex-wrap justify-center gap-3">
                <?php $__currentLoopData = [1, 2, 3, 4, 5, 6, 7, 0]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <label
                        class="inline-flex h-10 w-10 items-center justify-center
                               rounded-full border border-emerald-300 bg-white
                               text-sm font-semibold text-emerald-700"
                    >
                        <input
                            type="radio"
                            name="preview_kinerja_<?php echo e($question->id); ?>"
                            value="<?php echo e($value); ?>"
                            class="sr-only"
                            disabled
                        >

                        <?php echo e($value); ?>

                    </label>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/customer-assessment-1-7/options/importance-performance.blade.php ENDPATH**/ ?>