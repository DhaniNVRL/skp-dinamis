<div
    id="editDescriptionModal"
    data-modal
    class="fixed inset-0 z-50 hidden items-center justify-center bg-black/50 p-6"
>
    <div
        class="flex max-h-[90vh] w-full max-w-5xl
               flex-col overflow-hidden rounded-xl bg-white shadow-xl"
    >

        
        <div class="flex items-center justify-between border-b border-gray-200 px-6 py-4">

            <div>
                <h2 class="text-xl font-semibold text-gray-800">
                    Edit Description
                </h2>

                <p class="mt-1 text-sm text-gray-500">
                    Edit description form
                    <span
                        id="edit_description_form_name"
                        class="font-medium text-gray-700"
                    ></span>.
                </p>
            </div>

            <button
                type="button"
                data-modal-close="editDescriptionModal"
                class="text-gray-400 transition hover:text-red-600"
            >
                <i class="fa-solid fa-xmark text-xl"></i>
            </button>

        </div>

        
        <form
            id="editDescriptionForm"
            method="POST"
            class="flex min-h-0 flex-1 flex-col"
        >
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <div class="min-h-0 flex-1 overflow-y-auto p-6">

                <?php echo $__env->make(
                    'admin.units.question.partials.description-editor',
                    [
                        'editorId' => 'editDescriptionEditor',
                        'contentInputId' => 'editDescriptionContent'
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            </div>

            
            <div class="flex items-center justify-end gap-3 border-t border-gray-200 bg-gray-50 px-6 py-4">

                <button
                    type="button"
                    data-modal-close="editDescriptionModal"
                    class="rounded-lg border border-gray-300 px-4 py-2
                           text-gray-700 transition hover:bg-gray-100"
                >
                    Batal
                </button>

                <button
                    type="submit"
                    class="rounded-lg bg-blue-600 px-5 py-2
                           text-white transition hover:bg-blue-700"
                >
                    <i class="fa-solid fa-floppy-disk mr-1"></i>
                    Simpan Perubahan
                </button>

            </div>

        </form>

    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/modals/edit-description.blade.php ENDPATH**/ ?>