<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?></title>

    
    <script src="https://cdn.tailwindcss.com"></script>

    <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"
    >

    
    <script src="https://cdn.jsdelivr.net/npm/sortablejs@latest/Sortable.min.js"></script>

    <script
        defer
        src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"
    ></script>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

    <?php echo app('Illuminate\Foundation\Vite')([
        'resources/css/app.css',
        'resources/js/app.js',
    ]); ?>

    <style>
        [x-cloak] {
            display: none !important;
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>

<body class="h-screen overflow-hidden bg-gray-100">
    
    <?php echo $__env->make('layouts.partials.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="flex h-[calc(100vh-4rem)]">
        
        <?php if(auth()->guard()->check()): ?>
            <?php if(auth()->user()->hasRole('admin')): ?>
                <?php echo $__env->make(
                    'layouts.partials.sidebar-admin'
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php elseif(auth()->user()->hasRole('pm')): ?>
                <?php echo $__env->make(
                    'layouts.partials.sidebar-pm'
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php elseif(auth()->user()->hasRole('surveyor')): ?>
                <?php echo $__env->make(
                    'layouts.partials.sidebar-surveyor'
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <?php else: ?>
                <?php echo $__env->make(
                    'layouts.partials.sidebar-user'
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        <?php endif; ?>

        
        <main
            class="fixed bottom-12 left-64 right-0 top-16 overflow-y-auto bg-gray-100 px-6 py-6"
        >
            <?php echo $__env->renderWhen(
                view()->exists('layouts.partials.alert'),
                'layouts.partials.alert'
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1])); ?>

            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>

    
    <?php echo $__env->make('layouts.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php echo $__env->yieldPushContent('modals'); ?>
    <?php echo $__env->yieldPushContent('templates'); ?>
    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/layouts/app.blade.php ENDPATH**/ ?>