<?php $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noHeader => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <?php
        $questionType1 = $group->where('questiontype_id', 1)->sortBy('no');
    ?>

    <?php if($questionType1->isNotEmpty()): ?>
        <div class="mb-6 p-4 rounded-xl bg-blue-100 border shadow-sm">
            <h4 class="text-center font-bold text-lg text-gray-800">
                <?php echo e($questionType1->first()->name); ?>

            </h4>
        </div>
    <?php endif; ?>

    
    <?php
        $subunitList = $subunitIds->toArray();

        $type3Questions = $group->where('questiontype_id', 2)
            ->sortBy('no')
            ->filter(function ($question) use ($form, $activeMapSubUnit, $subunitList) {

                $key = $form->id.'-'.$question->id;

                return isset($activeMapSubUnit[$key]) &&
                    count(array_intersect($activeMapSubUnit[$key], $subunitList)) > 0;
            });
    ?>

    <?php if($type3Questions->isNotEmpty()): ?>
       <?php $__currentLoopData = $type3Questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $answerKey = $question->id.'-0-0';
                $current = $answerMap->get($answerKey);
            ?>

            <div class="question-card mb-4 bg-white rounded-xl shadow-sm p-5">

                <div class="question-block border rounded-lg p-4">

                    <div class="mb-3 font-semibold text-gray-700">
                        <?php echo e($question->no_header); ?><?php echo e($question->no); ?>.
                        <?php echo e($question->name); ?>

                    </div>

                    <div class="flex flex-wrap justify-center gap-4">

                        <?php $__currentLoopData = [1,2,3,4,5,6,7]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <label class="flex items-center gap-2">

                                <input
                                    type="radio"
                                    class="question-radio"
                                    name="answers[<?php echo e($question->id); ?>]"
                                    value="<?php echo e($value); ?>"
                                    <?php if((int)($current ?? -1) === $value): echo 'checked'; endif; ?>>

                                <span><?php echo e($value); ?></span>

                            </label>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                </div>

            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    const form = document.getElementById("surveyForm");

if(form){

    form.addEventListener("submit", function(e){

        let valid = true;
        let firstError = null;

        const groups = {};

        form.querySelectorAll(".question-radio").forEach(radio=>{

            if(!(radio.name in groups)){
                groups[radio.name] = false;
            }

            if(radio.checked){
                groups[radio.name] = true;
            }

        });

        Object.keys(groups).forEach(name=>{

            const radio = form.querySelector(`[name="${CSS.escape(name)}"]`);

            if(!groups[name]){

                valid = false;

                setQuestionError(radio);

                if(!firstError){
                    firstError = radio;
                }

            }else{

                clearQuestionError(radio);

            }

        });

        if(!valid){

            e.preventDefault();

            alert("Masih ada pertanyaan yang belum diisi.");

            firstError.scrollIntoView({
                behavior:"smooth",
                block:"center"
            });

        }

    });

}
document.addEventListener("change", function(e){

    if(e.target.classList.contains("question-radio")){

        clearQuestionError(e.target);

    }

});
function setQuestionError(element, error = true){

    const card = element.closest(".question-card");

    if(!card) return;

    card.classList.toggle("border-red-500", error);
    card.classList.toggle("bg-red-50", error);

}

function clearQuestionError(element){

    setQuestionError(element, false);

}
</script>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/show/penilaian_keterikatan_1-7.blade.php ENDPATH**/ ?>