<div class="space-y-3">

    <?php $__empty_1 = true; $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

        <?php echo $__env->make(
            'admin.units.question.partials.forms.general-questionnaire.options.option-item',
            [
                'question' => $question,
                'option' => $option,
                'inputType' => $inputType
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

        <div
            class="rounded-xl border border-dashed border-gray-300
                   bg-gray-50 px-5 py-8 text-center"
        >
            <div
                class="mx-auto flex h-11 w-11 items-center justify-center
                       rounded-full bg-white text-gray-400 shadow-sm"
            >
                <?php if($inputType === 'radio'): ?>
                    <i class="fa-regular fa-circle-dot"></i>
                <?php else: ?>
                    <i class="fa-regular fa-square-check"></i>
                <?php endif; ?>
            </div>

            <p class="mt-3 text-sm font-medium text-gray-600">
                Belum ada pilihan jawaban
            </p>

            <p class="mt-1 text-xs text-gray-400">
                Tambahkan option untuk pertanyaan ini.
            </p>
        </div>

    <?php endif; ?>


    <button
        type="button"
        data-modal-open="createOptionModal"
        data-question-id="<?php echo e($question->id); ?>"
        data-question-name="<?php echo e($question->name); ?>"
        data-action="<?php echo e(route('options.store')); ?>"
        class="inline-flex items-center gap-2 rounded-lg
            border border-dashed border-indigo-300
            bg-indigo-50 px-3.5 py-2
            text-sm font-medium text-indigo-700
            transition hover:border-indigo-400
            hover:bg-indigo-100"
    >
        <i class="fa-solid fa-plus text-xs"></i>

        Tambah Option
    </button>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/general-questionnaire/options/option-list.blade.php ENDPATH**/ ?>