<?php if($subunits->hasPages()): ?>
    <div class="rounded-lg border border-gray-200 bg-white px-4 py-3 shadow-sm">
        <?php echo e($subunits->links()); ?>

    </div>
<?php endif; ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/partials/pagination.blade.php ENDPATH**/ ?>