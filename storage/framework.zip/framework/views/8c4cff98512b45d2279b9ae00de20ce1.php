<div class="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table id="cprofileTable" class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100"><tr><th class="w-20 px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">No</th><th class="w-24 px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">ID</th><th class="px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">Pertanyaan Group</th><th class="px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">Pertanyaan Unit</th><th class="w-32 px-4 py-3 text-center text-xs font-semibold uppercase text-gray-600">Aksi</th></tr></thead>
            <tbody class="divide-y divide-gray-100 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $cprofiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cprofile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="transition hover:bg-gray-50" data-search="<?php echo e(strtolower($cprofile->id . ' ' . $cprofile->group_question . ' ' . $cprofile->unit_question)); ?>"><td class="px-4 py-3 text-sm text-gray-500"><?php echo e($loop->iteration); ?></td><td class="px-4 py-3 text-sm text-gray-500"><?php echo e($cprofile->id); ?></td><td class="px-4 py-3 text-sm font-medium text-gray-800"><?php echo e($cprofile->group_question); ?></td><td class="px-4 py-3 text-sm text-gray-700"><?php echo e($cprofile->unit_question); ?></td><td class="px-4 py-3 text-center"><?php echo $__env->make('admin.groups.complete-profile.partials.row-action', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td></tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-4 py-12 text-center text-sm text-gray-500"><i class="fa-solid fa-inbox mb-3 block text-3xl text-gray-300"></i>Data Complete Profile tidak ditemukan.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/groups/complete-profile/partials/table.blade.php ENDPATH**/ ?>