<?php switch((int) $formTypeId):
    
    case (1): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.general-questionnaire',
            [
                'form' => $form,
                'questions' => $questions,
                'subunits' => $subunits,
                'subunitIds' => $subunitIds,
                'activeMapSubUnit' => $activeMapSubUnit,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (2): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.customer-assessment-1-5',
            [
                'form' => $form,
                'questions' => $questions,
                'subunits' => $subunits,
                'subunitIds' => $subunitIds,
                'activeMapSubUnit' => $activeMapSubUnit,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (3): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.customer-assessment-1-7',
            [
                'form' => $form,
                'questions' => $questions,
                'subunits' => $subunits,
                'subunitIds' => $subunitIds,
                'activeMapSubUnit' => $activeMapSubUnit,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (4): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.engagement-assessment-1-5',
            [
                'form' => $form,
                'questions' => $questions,
                'subunits' => $subunits,
                'subunitIds' => $subunitIds,
                'activeMapSubUnit' => $activeMapSubUnit,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (5): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.engagement-assessment-1-7',
            [
                'form' => $form,
                'questions' => $questions,
                'subunits' => $subunits,
                'subunitIds' => $subunitIds,
                'activeMapSubUnit' => $activeMapSubUnit,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (6): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.ranking-1-3',
            [
                'form' => $form,
                'questions' => $questions,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (7): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.ranking-1-5',
            [
                'form' => $form,
                'questions' => $questions,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (8): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.strengths-complaints-suggestions',
            [
                'form' => $form,
                'questions' => $questions,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (9): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.complaints-suggestions-1-5',
            [
                'form' => $form,
                'questions' => $questions,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (10): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.suggestions',
            [
                'form' => $form,
                'questions' => $questions,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (11): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.competitor-assessment-1-5',
            [
                'form' => $form,
                'questions' => $questions,
                'competitors' => $competitors,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (12): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.description',
            [
                'form' => $form,
                'questions' => $questions,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (13): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.competitor-assessment-1-7',
            [
                'form' => $form,
                'questions' => $questions,
                'competitors' => $competitors,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php default: ?>
        <div class="rounded-lg border border-red-200 bg-red-50 p-4 text-sm font-medium text-red-600">
            Form type <?php echo e($formTypeId); ?> belum didukung.
        </div>
<?php endswitch; ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/partials/form-content.blade.php ENDPATH**/ ?>