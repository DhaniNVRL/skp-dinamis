<div class="overflow-hidden rounded-xl border border-gray-200 bg-white">
    
    <div class="p-6 md:p-8">
        <?php if($form->description): ?>
            <div class="prose max-w-none leading-7 text-gray-700">
                <?php echo $form->description->content; ?>

            </div>
        <?php else: ?>
            <div class="py-10 text-center">
                <div class="text-4xl text-gray-300">
                    <i class="fa-solid fa-file-lines"></i>
                </div>

                <h3 class="mt-4 font-semibold text-gray-700">
                    Deskripsi belum tersedia
                </h3>

                <p class="mt-1 text-sm text-gray-500">
                    Form ini belum memiliki isi deskripsi.
                </p>
            </div>
        <?php endif; ?>
    </div>

    
    <?php if($isLastForm): ?>
        <div class="border-t border-gray-200 bg-gray-50 px-6 py-5">
            <div class="flex flex-col items-center justify-between gap-4 md:flex-row">
                <div>
                    <h3 class="font-semibold text-gray-800">
                        Selesaikan Survei
                    </h3>

                    <p class="mt-1 text-sm text-gray-500">
                        Pastikan seluruh jawaban telah terisi sebelum mengakhiri survei.
                    </p>
                </div>

                <button
                    id="finishSurveyButton"
                    type="submit"
                    formaction="<?php echo e(route('survey.finish')); ?>"
                    formmethod="POST"
                    formnovalidate
                    class="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-green-600 px-6 py-3 font-semibold text-white transition hover:bg-green-700 disabled:cursor-not-allowed disabled:opacity-60 md:w-auto"
                >
                    <i class="fa-solid fa-flag-checkered"></i>
                    Akhiri Survei
                </button>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if($isLastForm): ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener(
                "DOMContentLoaded",
                function () {
                    const button =
                        document.getElementById(
                            "finishSurveyButton"
                        );

                    if (!button) {
                        return;
                    }

                    button.addEventListener(
                        "click",
                        function (event) {
                            const confirmed =
                                window.confirm(
                                    "Apakah Anda yakin ingin mengakhiri survei? Setelah selesai, jawaban tidak dapat diubah kembali."
                                );

                            if (!confirmed) {
                                event.preventDefault();
                                return;
                            }

                            button.disabled = true;

                            button.innerHTML = `
                                <i class="fa-solid fa-spinner fa-spin"></i>
                                Menyelesaikan...
                            `;
                        }
                    );
                }
            );
        </script>
    <?php $__env->stopPush(); ?>
<?php endif; ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/show/description.blade.php ENDPATH**/ ?>