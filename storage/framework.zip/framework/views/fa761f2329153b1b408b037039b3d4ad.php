<tr
    class="unit-row transition hover:bg-gray-50"
    data-unit-name="<?php echo e(strtolower($unit->name)); ?>"
>
    <td class="px-4 py-3 text-center">
        <input
            type="checkbox"
            name="unit_ids[]"
            value="<?php echo e($unit->id); ?>"
            class="unit-checkbox h-4 w-4 rounded
                border-gray-300 text-blue-600
                focus:ring-blue-500"
        >
    </td>

    <td class="unit-number px-4 py-3 text-sm text-gray-500">
        <?php echo e($number); ?>

    </td>

    <td class="px-4 py-3">
        <span class="text-sm font-medium text-gray-800">
            <?php echo e($unit->name); ?>

        </span>
    </td>

    <td class="px-4 py-3">
        <div class="flex items-center justify-center gap-3">

            <a
                href="<?php echo e(route('admin.subunit', [
                    'id' => $unit->id,
                    'tab' => 'subunit',
                ])); ?>"
                class="inline-flex items-center justify-center
                    text-sky-600 transition hover:text-sky-800"
                title="Buka Sub Unit"
                aria-label="Buka Sub Unit"
            >
                <i class="fa-solid fa-arrow-right-long"></i>
            </a>
            
            <button
                type="button"
                data-modal-open="editUnitModal"
                data-id="<?php echo e($unit->id); ?>"
                data-name="<?php echo e($unit->name); ?>"
                data-action="<?php echo e(route('units.update', [
                    'id' => $unit->id,
                ])); ?>"
                title="Edit Unit"
                class="text-amber-500 transition hover:text-amber-700"
            >
                <i class="fa-solid fa-pen-to-square"></i>
            </button>

            
            <button
                type="button"
                data-modal-open="deleteUnitModal"
                data-id="<?php echo e($unit->id); ?>"
                data-name="<?php echo e($unit->name); ?>"
                data-action="<?php echo e(route('units.destroy', [
                    'id' => $unit->id,
                ])); ?>"
                title="Hapus Unit"
                class="text-red-500 transition hover:text-red-700"
            >
                <i class="fa-solid fa-trash"></i>
            </button>
        </div>
    </td>
</tr><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/units/partials/row-action.blade.php ENDPATH**/ ?>