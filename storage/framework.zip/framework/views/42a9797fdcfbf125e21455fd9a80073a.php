

<?php $__env->startSection('title', 'Activity'); ?>

<?php $__env->startSection('content'); ?>
<div id="activityPage" class="mx-auto max-w-[1600px] space-y-6">
    <?php echo $__env->make('admin.activities.partials.page-header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <?php if(session('success')): ?>
        <div data-alert class="flex items-start justify-between rounded-lg border border-green-200 bg-green-50 px-4 py-3 text-sm text-green-700">
            <div><i class="fa-solid fa-circle-check mr-2"></i><?php echo e(session('success')); ?></div>
            <button type="button" data-alert-close class="ml-4 text-green-500 hover:text-green-700"><i class="fa-solid fa-xmark"></i></button>
        </div>
    <?php endif; ?>

    <?php if(session('successdelete')): ?>
        <div data-alert class="flex items-start justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <div><i class="fa-solid fa-trash mr-2"></i><?php echo e(session('successdelete')); ?></div>
            <button type="button" data-alert-close class="ml-4 text-red-500 hover:text-red-700"><i class="fa-solid fa-xmark"></i></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div data-alert class="flex items-start justify-between rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
            <div><i class="fa-solid fa-circle-exclamation mr-2"></i><?php echo e(session('error')); ?></div>
            <button type="button" data-alert-close class="ml-4 text-red-500 hover:text-red-700"><i class="fa-solid fa-xmark"></i></button>
        </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <div data-alert class="flex items-start justify-between rounded-lg border border-red-200 bg-red-50 p-4">
            <div>
                <p class="font-semibold text-red-700">Data belum dapat diproses:</p>
                <ul class="mt-2 list-disc space-y-1 pl-5 text-sm text-red-600">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <button type="button" data-alert-close class="ml-4 text-red-500 hover:text-red-700"><i class="fa-solid fa-xmark"></i></button>
        </div>
    <?php endif; ?>

    <div class="overflow-hidden rounded-xl border border-gray-200 bg-white shadow-sm">
        <div class="border-b border-gray-200 bg-gray-50">
            <div class="inline-flex items-center gap-2 border-b-2 border-blue-600 bg-white px-6 py-4 text-sm font-semibold text-blue-600">
                <i class="fa-solid fa-clipboard-list"></i>
                Data Activity
            </div>
        </div>

        <div class="space-y-4 p-5">
            <?php echo $__env->make('admin.activities.partials.toolbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('admin.activities.partials.filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('admin.activities.partials.bulk-action', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('admin.activities.partials.table', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php echo $__env->make('admin.activities.partials.pagination', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>

<?php echo $__env->make('admin.activities.modals.bulk-deleted', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.activities.modals.create', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.activities.modals.delete', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.activities.modals.edit', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('templates'); ?>
    <?php echo $__env->make('admin.activities.templates.create-row', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views//admin/activities/index.blade.php ENDPATH**/ ?>