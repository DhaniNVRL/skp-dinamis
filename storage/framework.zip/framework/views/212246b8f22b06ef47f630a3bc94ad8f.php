<?php
    $scopeId = isset($subunit)
        ? $subunit->id
        : 'global';

    /*
     * Customer Assessment 1-7.
     */
    $scaleMaximum = 7;

    /*
     * Alasan hanya muncul jika nilai Kinerja 1-4.
     */
    $reasonMaximumScore = 4;
?>

<div
    data-customer-assessment
    class="space-y-5"
>
    <?php $__empty_1 = true; $__currentLoopData = $questions->groupBy('no_header'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $noHeader => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php $__currentLoopData = $group->sortBy('no'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $questionTypeId = (int) (
                    $question->questiontype_id
                    ?? $question->id_questiontypes
                    ?? 0
                );

                $questionScope =
                    $question->id
                    . '_'
                    . $scopeId;
            ?>

            
            <?php if($questionTypeId === 1): ?>
                <div class="rounded-xl border border-blue-200 bg-blue-50 p-5">
                    <div class="flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Judul Pertanyaan
                            </p>
                        </div>
                    </div>
                </div>

            
            <?php elseif($questionTypeId === 2): ?>
                <div class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <div class="mb-5 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Penilaian Kepentingan dan Kinerja
                            </p>
                        </div>
                    </div>

                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.importance-performance',
                        [
                            'question' => $question,
                            'scopeId' => $scopeId,
                            'scaleMaximum' => $scaleMaximum,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

            
            <?php elseif($questionTypeId === 3): ?>
                <div
                    data-customer-question
                    data-reason-maximum-score="4"
                    class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
                >
                    <div class="mb-5 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Penilaian Kepentingan dan Kinerja dengan alasan
                            </p>
                        </div>
                    </div>

                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.importance-performance',
                        [
                            'question' => $question,
                            'scopeId' => $scopeId,
                            'scaleMaximum' => $scaleMaximum,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div
                        data-customer-reason-panel
                        class="mt-5 hidden rounded-xl border border-gray-200 bg-gray-50 p-4"
                    >
                        <label
                            for="reason_<?php echo e($questionScope); ?>"
                            class="mb-2 block text-sm font-semibold text-gray-700"
                        >
                            Alasan
                        </label>

                        <p class="mb-3 text-xs text-gray-500">
                            Alasan muncul karena nilai Kinerja berada pada rentang 1–4.
                        </p>

                        <textarea
                            id="reason_<?php echo e($questionScope); ?>"
                            name="reason[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>]"
                            rows="3"
                            data-customer-reason-input
                            disabled
                            class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
                            placeholder="Tuliskan alasan penilaian Anda..."
                        ></textarea>
                    </div>
                </div>

            
            <?php elseif($questionTypeId === 4): ?>
                <div
                    data-customer-question
                    data-reason-maximum-score="4"
                    class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm"
                >
                    <div class="mb-5 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Penilaian Kepentingan dan Kinerja dengan pilihan alasan
                            </p>
                        </div>
                    </div>

                    <?php echo $__env->make(
                        'admin.subunit.show-question.forms.partials.importance-performance',
                        [
                            'question' => $question,
                            'scopeId' => $scopeId,
                            'scaleMaximum' => $scaleMaximum,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                    <div
                        data-customer-reason-panel
                        class="mt-5 hidden rounded-xl border border-gray-200 bg-gray-50 p-4"
                    >
                        <div class="mb-4">
                            <h4 class="text-sm font-semibold text-gray-800">
                                Pilihan Alasan
                            </h4>

                            <p class="mt-1 text-xs text-gray-500">
                                Pilih satu atau beberapa alasan yang sesuai.
                            </p>
                        </div>

                        <div class="space-y-3">
                            <?php $__empty_2 = true; $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <?php
                                    $hasChild =
                                        (int) $option->has_child === 1;

                                    $optionId =
                                        'reason_'
                                        . $question->id
                                        . '_'
                                        . $scopeId
                                        . '_'
                                        . $option->id;
                                ?>

                                <div
                                    data-reason-option
                                    class="rounded-lg border border-gray-200 bg-white p-4"
                                >
                                    <div class="flex items-start gap-3">
                                        <input
                                            id="<?php echo e($optionId); ?>"
                                            type="checkbox"
                                            name="reason_options[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>][]"
                                            value="<?php echo e($option->id); ?>"
                                            data-reason-checkbox
                                            data-customer-reason-input
                                            disabled
                                            class="mt-1 h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                        >

                                        <label
                                            for="<?php echo e($optionId); ?>"
                                            class="cursor-pointer text-sm font-medium text-gray-700"
                                        >
                                            <?php echo e($option->answer_text); ?>

                                        </label>
                                    </div>

                                    <?php if($hasChild): ?>
                                        <div
                                            data-reason-child
                                            class="mt-3 hidden pl-7"
                                        >
                                            <?php if(!empty($option->child_label)): ?>
                                                <label
                                                    for="child_<?php echo e($optionId); ?>"
                                                    class="mb-2 block text-xs font-medium text-gray-600"
                                                >
                                                    <?php echo e($option->child_label); ?>

                                                </label>
                                            <?php endif; ?>

                                            <textarea
                                                id="child_<?php echo e($optionId); ?>"
                                                name="reason_children[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>][<?php echo e($option->id); ?>]"
                                                rows="2"
                                                data-customer-reason-child-input
                                                disabled
                                                class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
                                                placeholder="<?php echo e($option->child_placeholder ?? 'Tuliskan keterangan tambahan...'); ?>"
                                            ></textarea>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                <div class="rounded-lg border border-dashed border-gray-300 p-6 text-center text-sm text-gray-500">
                                    Pilihan alasan belum tersedia.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

            
            <?php elseif($questionTypeId === 5): ?>
                <div class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <div class="mb-5 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Penilaian Satu Indikator
                            </p>
                        </div>
                    </div>

                    <div class="flex justify-center rounded-xl border border-indigo-200 bg-indigo-50 p-5">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.scale',
                            [
                                'question' => $question,
                                'maximum' => $scaleMaximum,
                                'includeZero' => true,
                                'name' => "indicator_{$questionScope}",
                                'leftLabel' => null,
                                'rightLabel' => null,
                                'zeroLabel' => null,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                    </div>
                </div>

            
            <?php elseif($questionTypeId === 6): ?>
                <div class="rounded-xl border border-gray-200 bg-white p-5 shadow-sm">
                    <div class="mb-4 flex items-start gap-3">
                        <?php echo $__env->make(
                            'admin.subunit.show-question.forms.partials.question-number',
                            [
                                'question' => $question,
                            ]
                        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

                        <div>
                            <h3 class="font-semibold text-gray-800">
                                <?php echo e($question->name); ?>

                            </h3>

                            <p class="mt-1 text-xs text-gray-500">
                                Jawaban Teks
                            </p>
                        </div>
                    </div>

                    <textarea
                        name="text_answer[<?php echo e($question->id); ?>][<?php echo e($scopeId); ?>]"
                        rows="4"
                        class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
                        placeholder="Tulis jawaban Anda..."
                    ></textarea>
                </div>

            <?php else: ?>
                <div class="rounded-lg border border-yellow-200 bg-yellow-50 p-4 text-yellow-700">
                    Question Type <?php echo e($questionTypeId); ?> belum didukung:
                    <?php echo e($question->name); ?>

                </div>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <?php echo $__env->make(
            'admin.subunit.show-question.forms.partials.empty'
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/forms/customer-assessment-1-7.blade.php ENDPATH**/ ?>