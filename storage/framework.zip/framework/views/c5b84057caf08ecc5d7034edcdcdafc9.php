<?php
    $questionTypeId = (int) (
        $question->questiontype_id
        ?? $question->id_questiontypes
        ?? 0
    );
?>

<?php switch($questionTypeId):

    
    case (1): ?>
        <?php echo $__env->make(
            'admin.units.question.partials.forms.suggestion.options.title',
            [
                'question' => $question,
                'form' => $form,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    
    <?php case (2): ?>
        <?php echo $__env->make(
            'admin.units.question.partials.forms.suggestion.options.textarea',
            [
                'question' => $question,
                'form' => $form,
            ]
        , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php break; ?>

    <?php default: ?>
        <div class="mb-5 rounded-lg border border-dashed border-red-300 bg-red-50 p-4">

            <p class="text-sm font-medium text-red-700">
                Tipe pertanyaan tidak ditemukan.
            </p>

            <p class="mt-1 text-xs text-red-600">
                ID tipe: <?php echo e($questionTypeId ?: '-'); ?>

            </p>

        </div>

<?php endswitch; ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/suggestion/question-body.blade.php ENDPATH**/ ?>