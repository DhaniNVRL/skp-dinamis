<template id="createUserRowTemplate">

    <tr class="create-user-row">

        
        <td class="border-r border-gray-200 p-3 text-center">

            <span
                data-row-number
                class="text-sm font-medium text-gray-700"
            ></span>

        </td>


        
        <td class="border-r border-gray-200 p-3">

            <input
                type="text"
                name="username[]"
                required
                autocomplete="off"
                placeholder="Username"
                class="w-full rounded-lg border border-gray-300 px-3 py-2
                       focus:outline-none focus:ring-2 focus:ring-green-500"
            >

        </td>


        
        <td class="border-r border-gray-200 p-3">

            <input
                type="text"
                name="password[]"
                required
                autocomplete="off"
                placeholder="Password"
                class="w-full rounded-lg border border-gray-300 px-3 py-2
                       focus:outline-none focus:ring-2 focus:ring-green-500"
            >

        </td>


        
        <td class="border-r border-gray-200 p-3">

            <select
                name="role_id[]"
                required
                class="role-select w-full rounded-lg border border-gray-300 bg-white px-3 py-2
                       focus:outline-none focus:ring-2 focus:ring-green-500"
            >

                <option value="">
                    Pilih Role
                </option>

                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($role->id); ?>">
                        <?php echo e($role->name); ?>

                    </option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        </td>


        
        <td class="activity-column border-r border-gray-200 p-3">

            <select
                name="activity_id[]"
                required
                class="activity-select w-full rounded-lg border border-gray-300 bg-white px-3 py-2
                       focus:outline-none focus:ring-2 focus:ring-green-500"
            >

                <option value="">
                    Pilih Activity
                </option>

                <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <option value="<?php echo e($activity->id); ?>">
                        <?php echo e($activity->name); ?>

                    </option>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </select>

        </td>


        
        <td class="p-3 text-center">

            <button
                type="button"
                data-remove-row
                class="text-red-500 transition hover:text-red-700"
                title="Hapus baris"
            >
                <i class="fa-solid fa-trash"></i>
            </button>

        </td>

    </tr>

</template><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/users/templates/create-row.blade.php ENDPATH**/ ?>