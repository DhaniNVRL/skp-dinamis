<div class="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table id="activityTable" class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100">
                <tr>
                    <th class="w-12 px-4 py-3 text-center">
                        <input type="checkbox" class="bulk-select-all rounded border-gray-300 text-blue-600 focus:ring-blue-500">
                    </th>
                    <th class="w-20 px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">No</th>
                    <th class="w-24 px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">ID</th>
                    <th class="min-w-[220px] px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">Activity</th>
                    <th class="min-w-[320px] px-4 py-3 text-left text-xs font-semibold uppercase text-gray-600">Description</th>
                    <th class="w-36 px-4 py-3 text-center text-xs font-semibold uppercase text-gray-600">Aksi</th>
                </tr>
            </thead>

            <tbody class="divide-y divide-gray-100 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr
                        class="transition hover:bg-gray-50"
                        data-search="<?php echo e(strtolower($activity->id . ' ' . $activity->name . ' ' . $activity->description)); ?>"
                    >
                        <td class="px-4 py-3 text-center">
                            <input
                                form="bulkDeleteForm"
                                type="checkbox"
                                name="ids[]"
                                value="<?php echo e($activity->id); ?>"
                                data-label="<?php echo e($activity->name); ?>"
                                data-username="<?php echo e($activity->name); ?>"
                                class="bulk-checkbox rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            >
                        </td>
                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($loop->iteration); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($activity->id); ?></td>
                        <td class="px-4 py-3 text-sm font-medium text-gray-800"><?php echo e($activity->name); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-600"><?php echo e($activity->description ?: '-'); ?></td>
                        <td class="px-4 py-3 text-center">
                            <?php echo $__env->make('admin.activities.partials.row-action', ['activity' => $activity], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="6" class="px-4 py-12 text-center text-sm text-gray-500">
                            <i class="fa-regular fa-folder-open mb-2 block text-2xl text-gray-400"></i>
                            Belum ada data Activity.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/activities/partials/table.blade.php ENDPATH**/ ?>