<div
    id="bulkDeleteModal"
    data-modal
    class="fixed inset-0 hidden items-center justify-center bg-black/50">

    <div class="bg-white rounded-lg w-full max-w-md p-6">

        <h2 class="text-lg font-semibold">
            Hapus Data Unit
        </h2>

        <p class="mt-2">
            Akan dihapus
            <strong id="bulkDeleteCount">0</strong>
            Unit.
        </p>

        <ul
            id="bulkDeleteUnitList"
            class="mt-3 list-disc list-inside text-sm text-gray-700 max-h-48 overflow-y-auto">
        </ul>

        <form
            id="bulkDeleteForm"
            method="POST"
            action="<?php echo e(route('units.bulkDelete')); ?>">

            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>

            <div class="mt-6 flex justify-end gap-2">

                <button
                    type="button"
                    data-modal-close="bulkDeleteModal"
                    class="px-4 py-2 rounded border">
                    Cancel
                </button>

                <button
                    type="submit"
                    class="bg-red-600 text-white px-4 py-2 rounded">
                    Delete
                </button>

            </div>

        </form>

    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/units/modals/bulk-deleted.blade.php ENDPATH**/ ?>