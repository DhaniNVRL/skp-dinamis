<div class="flex items-center justify-between rounded-lg border border-gray-200 bg-white px-4 py-3 shadow-sm">
    <p class="text-sm text-gray-500">Total <?php echo e($groups->count()); ?> Group</p>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/groups/groups/partials/pagination.blade.php ENDPATH**/ ?>