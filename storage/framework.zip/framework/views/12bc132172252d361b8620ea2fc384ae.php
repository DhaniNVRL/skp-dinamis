<div class="overflow-hidden rounded-xl border border-gray-200 bg-white">

    <div class="px-5 py-4">

        <?php switch((int) $form->formtype_id):

            
            case (1): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.general-questionnaire.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (2): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.customer-assessment-1-5.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (3): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.customer-assessment-1-7.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (4): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.engagement-assessment-1-5.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (5): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.engagement-assessment-1-7.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (6): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.ranking-1-3.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (7): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.ranking-1-5.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (8): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.strength-complaint-suggestion.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (9): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.complaint-suggestion.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (10): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.suggestion.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (11): ?>
                <?php echo $__env->make(
                    'admin.units.question.partials.forms.competitor-1-7.question-body',
                    [
                        'question' => $question,
                        'form' => $form,
                    ]
                , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

            
            <?php case (12): ?>
                <div class="rounded-lg border border-gray-200 bg-gray-50 p-4">
                    <p class="text-sm italic text-gray-500">
                        Form description tidak memiliki pertanyaan.
                    </p>
                </div>
                <?php break; ?>

            <?php default: ?>
                <div class="rounded-lg border border-red-200 bg-red-50 p-4">
                    <p class="text-sm text-red-600">
                        Tampilan untuk tipe form ini belum tersedia.
                    </p>
                </div>

        <?php endswitch; ?>

    </div>

</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/partials/forms/question-card.blade.php ENDPATH**/ ?>