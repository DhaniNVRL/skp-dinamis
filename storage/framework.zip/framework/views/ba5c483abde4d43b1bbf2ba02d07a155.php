<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
   <div class="max-w-4xl mx-auto py-8 px-4 bg-white shadow rounded">
    <h1 class="text-3xl font-semibold mb-4">Dashboard Admin</h1>
    <p class="mb-2">Selamat datang, <strong><?php echo e(Auth::user()->name); ?></strong></p>
    <p class="mb-4">Role Anda:
        <span class="inline-block bg-yellow-400 text-black text-sm px-2 py-1 rounded">Admin</span>
    </p>

    <form method="POST" action="<?php echo e(route('logout')); ?>">
        <?php echo csrf_field(); ?>
        <button class="bg-red-600 hover:bg-red-700 text-white font-bold py-2 px-4 rounded">
            Logout
        </button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>