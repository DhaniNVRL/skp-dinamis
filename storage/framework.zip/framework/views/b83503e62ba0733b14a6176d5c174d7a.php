<?php echo $__env->make(
    'user.survey.forms.partials.customer-assessment',
    [
        'maximumScale' => 5,
        'reasonMaximum' => 3,
    ]
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/customer-assessment-1-5.blade.php ENDPATH**/ ?>