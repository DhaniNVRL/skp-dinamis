<?php
    $mapKey = $form->id . '-' . $question->id;

    $activeSubunitIds = collect(
        $activeMapSubUnit[$mapKey] ?? []
    )->map(fn ($id) => (int) $id);

    $allSubunitIds = $allSubunits
        ->pluck('id')
        ->map(fn ($id) => (int) $id);

    $allAreActive = $allSubunitIds->isNotEmpty()
        && $allSubunitIds->every(
            fn ($id) => $activeSubunitIds->contains($id)
        );

    $questionNumber = trim(
        ($question->no_header ?? '') .
        ($question->no ?? '')
    );

    $isHeader = (int) (
        $question->questiontype_id
        ?? $question->id_questiontypes
        ?? 0
    ) === 1;
?>

<div class="rounded-lg border border-gray-200">
    
    <div class="flex items-start gap-3 border-b border-gray-100 bg-gray-50 px-4 py-3">
        <div class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-blue-100 text-xs font-bold text-blue-700">
            <?php echo e($loop->iteration); ?>

        </div>

        <div class="min-w-0 flex-1">
            <?php if($questionNumber !== ''): ?>
                <div class="mb-1 text-xs font-semibold uppercase tracking-wide text-gray-400">
                    Pertanyaan <?php echo e($questionNumber); ?>

                </div>
            <?php endif; ?>

            <div class="font-medium text-gray-800">
                <?php echo e($question->name); ?>

            </div>
        </div>
    </div>

    <?php if($isPerSubUnit): ?>
        
        <div class="divide-y divide-gray-100">
            <?php $__currentLoopData = $allSubunits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subunit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $isActive = $activeSubunitIds->contains(
                        (int) $subunit->id
                    );
                ?>

                <div class="flex items-center justify-between gap-4 px-4 py-3">
                    <div class="flex min-w-0 items-center gap-3">
                        <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-gray-100 text-gray-500">
                            <i class="fa-solid fa-building"></i>
                        </div>

                        <div class="min-w-0">
                            <div class="truncate text-sm font-medium text-gray-700">
                                <?php echo e($subunit->name); ?>

                            </div>

                            <div
                                data-toggle-status
                                class="text-xs <?php echo e($isActive ? 'text-green-600' : 'text-red-500'); ?>"
                            >
                                <?php echo e($isActive ? 'Ditampilkan' : 'Disembunyikan'); ?>

                            </div>
                        </div>
                    </div>

                    <?php echo $__env->make(
                        'admin.subunit.hide-and-show.partials.toggle-button',
                        [
                            'formId' => $form->id,
                            'questionId' => $question->id,
                            'subunitIds' => [$subunit->id],
                            'isActive' => $isActive,
                        ]
                    , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    <?php else: ?>
        
        <div class="flex items-center justify-between gap-4 px-4 py-4">
            <div class="flex min-w-0 items-center gap-3">
                <div class="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-purple-100 text-purple-600">
                    <i class="fa-solid fa-layer-group"></i>
                </div>

                <div>
                    <div class="text-sm font-medium text-gray-700">
                        Berlaku untuk seluruh Sub Unit
                    </div>

                    <div
                        data-toggle-status
                        class="text-xs <?php echo e($allAreActive ? 'text-green-600' : 'text-red-500'); ?>"
                    >
                        <?php echo e($allAreActive ? 'Ditampilkan' : 'Disembunyikan'); ?>

                    </div>
                </div>
            </div>

            <?php echo $__env->make(
                'admin.subunit.hide-and-show.partials.toggle-button',
                [
                    'formId' => $form->id,
                    'questionId' => $question->id,
                    'subunitIds' => $allSubunitIds->all(),
                    'isActive' => $allAreActive,
                ]
            , array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    <?php endif; ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/hide-and-show/partials/question-card.blade.php ENDPATH**/ ?>