<?php
    $totalUsers = method_exists($userProfiles, 'total')
        ? $userProfiles->total()
        : $userProfiles->count();
?>

<div class="flex flex-col gap-3 rounded-lg border border-gray-200 bg-white px-4 py-3 sm:flex-row sm:items-center sm:justify-between">
    <p class="text-sm text-gray-500">Total <?php echo e($totalUsers); ?> User</p>

    <?php if($userProfiles instanceof \Illuminate\Pagination\AbstractPaginator): ?>
        <div><?php echo e($userProfiles->withQueryString()->links()); ?></div>
    <?php endif; ?>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/users/partials/pagination.blade.php ENDPATH**/ ?>