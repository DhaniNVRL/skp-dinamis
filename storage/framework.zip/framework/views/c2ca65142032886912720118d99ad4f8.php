<template id="ranking13TypeOptions">

    <option
        value="1"
        data-description="Judul atau pemisah kelompok pertanyaan ranking."
    >
        Judul Pertanyaan
    </option>

    <option
        value="2"
        data-description="Pertanyaan dengan pilihan ranking 1 sampai 5."
    >
        Pertanyaan
    </option>

</template><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/units/question/templates/forms/ranking-1-3.blade.php ENDPATH**/ ?>