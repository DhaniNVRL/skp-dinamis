<?php echo $__env->make(
    'user.survey.forms.partials.feedback-assessment',
    [
        'feedbackFields' => [
            [
                'key' => 'complaint',
                'label' => 'Keluhan',
                'placeholder' => 'Tuliskan keluhan...',
                'wrapperClass' =>
                    'border-red-200 bg-red-50',
                'labelClass' =>
                    'text-red-700',
                'focusClass' =>
                    'focus:border-red-500 focus:ring-red-100',
                'icon' =>
                    'fa-solid fa-comment-dots',
            ],
            [
                'key' => 'suggestion',
                'label' => 'Saran',
                'placeholder' => 'Tuliskan saran...',
                'wrapperClass' =>
                    'border-blue-200 bg-blue-50',
                'labelClass' =>
                    'text-blue-700',
                'focusClass' =>
                    'focus:border-blue-500 focus:ring-blue-100',
                'icon' =>
                    'fa-solid fa-lightbulb',
            ],
        ],
    ]
, array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/user/survey/forms/complaint-suggestion.blade.php ENDPATH**/ ?>