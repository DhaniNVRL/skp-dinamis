<div
    id="questionPreviewPage"
    class="w-full"
>
    
    <div class="mb-5 rounded-xl border border-indigo-200 bg-indigo-50 p-5">
        <div class="flex items-start gap-4">
            <div class="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-indigo-600">
                <i class="fa-solid fa-list-check"></i>
            </div>

            <div>
                <h2 class="text-lg font-semibold text-gray-800">
                    Tampilan Pertanyaan
                </h2>

                <p class="mt-1 text-sm text-gray-600">
                    Preview pertanyaan berdasarkan pengaturan Hide and Show.
                </p>
            </div>
        </div>
    </div>

    <?php echo $__env->make('admin.subunit.show-question.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/pages/question-preview.blade.php ENDPATH**/ ?>