

<?php $__env->startSection('title', 'Groups'); ?>

<?php $__env->startSection('content'); ?>

<div class="container mx-auto px-4 py-6">
    <div class="text-end">
      <input type="text" id="searchInput" placeholder="Search Activities...." class="border border-gray-300 rounded-md px-3 py-2 focus:outline-none focus:ring focus:ring-blue-200">
    </div>

    <div class="overflow-x-auto pt-2">
      <table class="min-w-full bg-white border border-gray-200">
        <thead>
          <tr class="bg-gray-100 text-center">
            <th class="py-2 px-4 border-b w-[50px] text-center">
              <input type="checkbox" id="selectAll" class="cursor-pointer">
            </th>
            <th class="py-2 px-4 border-b w-[50px] text-center">No</th>
            <th class="py-2 px-4 border-b w-[50px]">Group ID</th>
            <th class="py-2 px-4 border-b w-[50px]">Activity ID</th>
            <th class="py-2 px-4 border-b w-[200px]">Group Name</th>
            <th class="py-2 px-4 border-b w-[200px]">Update At</th>
          </tr>
        </thead>
        <tbody id="activityTable">
         <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="text-center">
                <td class="border py-2 px-4">
                    <input type="checkbox" name="selected[]" class="rowCheckbox" value="<?php echo e($group->id); ?>">
                </td>
                <td class="border py-2 px-4"><?php echo e($index + 1); ?></td>
                <td class="border py-2 px-4"><?php echo e($group->id); ?></td>
                <td class="border py-2 px-4"><?php echo e($group->id_activities); ?></td>
                <td class="border py-2 px-4 text-start"><?php echo e($group->name); ?></td>
                <td class="border py-2 px-4"><?php echo e($group->updated_at); ?>              
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </form>

<!-- Script -->
<script>
  document.getElementById('searchInput').addEventListener('keyup', function() {
    const searchValue = this.value.toLowerCase();
    const rows = document.querySelectorAll('#activityTable tr');

    rows.forEach(row => {
      const text = row.textContent.toLowerCase();
      row.style.display = text.includes(searchValue) ? '' : 'none';
    });
  });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views//admin/masterdata/group.blade.php ENDPATH**/ ?>