<div class="overflow-hidden rounded-lg border border-gray-200 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table id="GroupsTable" class="min-w-full divide-y divide-gray-200">
            <thead class="bg-gray-100">
                <tr>
                    <th class="w-12 px-4 py-3 text-center"><input type="checkbox" class="bulk-select-all rounded border-gray-300 text-blue-600" id="selectAllTable"></th>
                    <th class="w-20 px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">No</th>
                    <th class="w-24 px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">ID</th>
                    <th class="px-4 py-3 text-left text-xs font-semibold uppercase tracking-wide text-gray-600">Nama Group</th>
                    <th class="w-36 px-4 py-3 text-center text-xs font-semibold uppercase tracking-wide text-gray-600">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-100 bg-white">
                <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="transition hover:bg-gray-50" data-search="<?php echo e(strtolower($group->id . ' ' . $group->name)); ?>">
                        <td class="px-4 py-3 text-center"><input form="bulkDeleteForm" type="checkbox" name="ids[]" class="bulk-checkbox rounded border-gray-300 text-blue-600" value="<?php echo e($group->id); ?>" data-label="<?php echo e($group->name); ?>" data-username="<?php echo e($group->name); ?>"></td>
                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($loop->iteration); ?></td>
                        <td class="px-4 py-3 text-sm text-gray-500"><?php echo e($group->id); ?></td>
                        <td class="px-4 py-3 text-sm font-medium text-gray-800"><?php echo e($group->name); ?></td>
                        <td class="px-4 py-3 text-center"><?php echo $__env->make('admin.groups.groups.partials.row-action', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="5" class="px-4 py-12 text-center text-sm text-gray-500"><i class="fa-solid fa-inbox mb-3 block text-3xl text-gray-300"></i>Data Group tidak ditemukan.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/groups/groups/partials/table.blade.php ENDPATH**/ ?>