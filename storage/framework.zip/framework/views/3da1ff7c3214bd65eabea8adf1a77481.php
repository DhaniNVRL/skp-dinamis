<?php
    $rankingName = $name
        ?? 'ranking_' . $question->id;

    $rankingLabel = $label
        ?? 'Ranking';

    $rankingIndex = (int) (
        $rank ?? 1
    );
?>

<div
    data-ranking-block
    class="space-y-2"
>
    <label
        for="<?php echo e($rankingName); ?>"
        class="block text-sm font-medium text-gray-600"
    >
        <?php echo e($rankingLabel); ?>

    </label>

    <select
        id="<?php echo e($rankingName); ?>"
        name="<?php echo e($rankingName); ?>"
        data-ranking-select
        data-question-id="<?php echo e($question->id); ?>"
        data-ranking-index="<?php echo e($rankingIndex); ?>"
        class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
    >
        <option
            value=""
            data-has-child="0"
        >
            -- Pilih jawaban --
        </option>

        <?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
                value="<?php echo e($option->id); ?>"
                data-has-child="<?php echo e((int) $option->has_child); ?>"
            >
                <?php echo e($option->answer_text); ?>

            </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>

    
    <div
        data-ranking-child
        class="hidden rounded-lg border border-indigo-200 bg-indigo-50 p-3"
    >
        <label
            for="<?php echo e($rankingName); ?>_child"
            class="mb-2 block text-xs font-medium text-gray-600"
        >
            Jawaban tambahan
        </label>

        <textarea
            id="<?php echo e($rankingName); ?>_child"
            name="<?php echo e($rankingName); ?>_child"
            rows="3"
            data-ranking-child-input
            disabled
            class="w-full rounded-lg border border-gray-300 bg-white px-3 py-2 text-sm outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200"
            placeholder="Tulis jawaban tambahan..."
        ></textarea>
    </div>
</div><?php /**PATH G:\Aplikasi\skp-dinamis-2\resources\views/admin/subunit/show-question/partials/ranking-select.blade.php ENDPATH**/ ?>